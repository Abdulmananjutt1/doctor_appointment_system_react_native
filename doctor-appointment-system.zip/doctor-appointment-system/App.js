
import DoctorAppointmentSystem from './components/AppNavigator/UserRole';
export default function App() {
  return <DoctorAppointmentSystem />;
}