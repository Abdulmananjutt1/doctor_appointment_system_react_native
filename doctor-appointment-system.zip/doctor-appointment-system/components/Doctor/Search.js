import React, { useState, useEffect } from 'react';
import { View, Text, Button, StyleSheet, TouchableOpacity, TextInput, FlatList, ScrollView, Alert, Image, Animated } from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';

const Search = ({ navigation }) => {
  const [searchText, setSearchText] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [bloodPressure, setBloodPressure] = useState('');
  const [pulseRate, setPulseRate] = useState('');
  const [diagnosedWith, setDiagnosedWith] = useState('');
  const [drug, setDrug] = useState('');
  const [unit, setUnit] = useState('');
  const [dosage, setDosage] = useState('');
  const [thingsToFollow, setThingsToFollow] = useState('');
  const [physiciansName, setPhysiciansName] = useState('');
  const [patientName, setPatientName] = useState('');
  const [age, setAge] = useState('');
  const [contact, setContact] = useState('');
  const [dateOfBirth, setDateOfBirth] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [email, setEmail] = useState('');

  const animation = new Animated.Value(0);

  useEffect(() => {
    Animated.spring(animation, {
      toValue: 1,
      friction: 4,
      tension: 40,
    }).start();
  }, []);

  const handleBellPress = () => {
    Alert.alert('Notification', 'You have a new notification!');
  };

  const handleSearch = async (text) => {
    setSearchText(text);
    if (!text.trim()) {
      Alert.alert('Error', 'Please enter a search term');
      return;
    }

    try {
      const response = await fetch('https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/MedicalRecords.json');
      const data = await response.json();
      const searchTokenId = text.trim();
      const results = Object.values(data).filter(item => item.TokenID === searchTokenId);
    
      if (results.length > 0) {
        const tokenDetails = results[0];
        setPatientName(tokenDetails.patientName);
        setAge(tokenDetails.age);
        setContact(tokenDetails.contact);
        setDateOfBirth(tokenDetails.dateOfBirth);
        setDate(tokenDetails.date);
        setTime(tokenDetails.time);
        setEmail(tokenDetails.email);
        setBloodPressure(tokenDetails.bloodPressure);
        setPulseRate(tokenDetails.pulseRate);
        setDiagnosedWith(tokenDetails.diagnosedWith);
        setDrug(tokenDetails.drug);
        setUnit(tokenDetails.unit);
        setDosage(tokenDetails.dosage);
        setThingsToFollow(tokenDetails.thingsToFollow);
        setPhysiciansName(tokenDetails.physiciansName);
        setSearchResults(results);
      } else {
        Alert.alert('No matching found.');
        setSearchResults([]);
      }
    } catch (error) {
      console.error('Fetch error:', error);
      Alert.alert('Error', 'Something went wrong while fetching data');
      setSearchResults([]);
    }
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: '#FFFFFF' }}>
      <View style={[styles.container, { backgroundColor: '#FFFFFF' }]}>
        <Image
          style={styles.headerImage}
          source={{ uri: 'https://thumbs.dreamstime.com/b/healthcare-technology-doctor-using-digital-tablet-icon-medical-network-hospital-background-162019727.jpg' }}
          
        />
        
        <View style={styles.searchContainer}>
          <TextInput
            style={[styles.searchInput, { borderRadius: 20, backgroundColor: '#fff' }]}
            placeholder="  Search Medical Record"
            value={searchText}
            onChangeText={setSearchText}
            placeholderTextColor="#666"
          />
<TouchableOpacity style={styles.searchButton} onPress={() => handleSearch(searchText)}>
            <Text style={styles.searchButtonText}>Search</Text>
          </TouchableOpacity>
          <FlatList
            data={searchResults}
            renderItem={({ item }) => (
              <View style={styles.searchResult}>
                <Text style={styles.searchResultText}>{item.Name}</Text>
              </View>
            )}
            keyExtractor={(item) => item.TokenID.toString()}
          />
        </View>
        <View style={styles.formContainer}>
          <View style={styles.formRow}>
            <View style={{ flex: 1 }}>
              <Text style={styles.label}>Patient Name:</Text>
              <TextInput
                style={[styles.input, { borderRadius: 20, backgroundColor: '#fff' }]}
                placeholderTextColor="#666"
                value={patientName}
                editable={false}
              />
            </View>
            <View style={{ flex: 1, marginLeft: 10 }}>
              <Text style={styles.label}>Age:</Text>
              <Animated.View style={{ transform: [{ scale: animation }] }}>
                <TextInput
                  style={[styles.input, { borderRadius: 20, backgroundColor: '#fff' }]}
                  placeholderTextColor="#666"
                  value={age}
                  editable={false}
                />
              </Animated.View>
            </View>
          </View>
          <View style={styles.formRow}>
            <View style={{ flex: 1 }}>
              <Text style={styles.label}>Contact Detail:</Text>
              <Animated.View style={{ transform: [{ scale: animation }] }}>
                <TextInput
                  style={[styles.input, { borderRadius: 20, backgroundColor: '#fff' }]}
                  placeholderTextColor="#666"
                  value={contact}
                  editable={false}
                />
              </Animated.View>
            </View>
            <View style={{ flex: 1, marginLeft: 10 }}>
              <Text style={styles.label}>Date of birth:</Text>
              <Animated.View style={{ transform: [{ scale: animation }] }}>
                <TextInput
                  style={[styles.input, { borderRadius: 20, backgroundColor: '#fff' }]}
                  placeholderTextColor="#666"
                  value={dateOfBirth}
                  editable={false}
                />
              </Animated.View>
            </View>
          </View>
          <View style={styles.formRow}>
            <View style={{ flex: 1 }}>
              <Text style={styles.label}>Date:</Text>
              <Animated.View style={{ transform: [{ scale: animation }] }}>
                <TextInput
                  style={[styles.input, { borderRadius: 20, backgroundColor: '#fff' }]}
                  placeholderTextColor="#666"
                  value={date}
                  editable={false}
                />
              </Animated.View>
            </View>
            <View style={{ flex: 1, marginLeft: 10 }}>
              <Text style={styles.label}>Time:</Text>
              <Animated.View style={{ transform: [{ scale: animation }] }}>
                <TextInput
                  style={[styles.input, { borderRadius: 20, backgroundColor: '#fff' }]}
                  placeholderTextColor="#666"
                  value={time}
                  editable={false}
                />
              </Animated.View>
            </View>
          </View>
          <View style={styles.formRow}>
            <View style={{ flex: 1 }}>
              <Text style={styles.label}>Blood Pressure:</Text>
              <Animated.View style={{ transform: [{ scale: animation }] }}>
                <TextInput
                  style={[styles.input, { borderRadius: 20, backgroundColor: '#fff' }]}
                
                  value={bloodPressure}
                  placeholderTextColor="#666"
                />
              </Animated.View>
            </View>
            <View style={{ flex: 1, marginLeft: 10 }}>
              <Text style={styles.label}>Pulse Rate:</Text>
              <Animated.View style={{ transform: [{ scale: animation }] }}>
                <TextInput
                  style={[styles.input, { borderRadius: 20, backgroundColor: '#fff' }]}
                 
                  value={pulseRate}
                  placeholderTextColor="#666"
                />
              </Animated.View>
            </View>
          </View>

          <View style={styles.formRow}>
            <View style={{ flex: 1 }}>
              <Text style={styles.label}>Diagnosed With:</Text>
              <Animated.View style={{ transform: [{ scale: animation }] }}>
                <TextInput
                  style={[styles.input, { borderRadius: 20, backgroundColor: '#fff' }]}
                  
                  value={diagnosedWith}
                  placeholderTextColor="#666"
                />
              </Animated.View>
            </View>
            <View style={{ flex: 1, marginLeft: 10 }}>
              <Text style={styles.label}>Drug:</Text>
              <Animated.View style={{ transform: [{ scale: animation }] }}>
                <TextInput
                  style={[styles.input, { borderRadius: 20, backgroundColor: '#fff' }]}
                  
                  value={drug}
                  placeholderTextColor="#666"
                />
              </Animated.View>
            </View>
          </View>
          <View style={styles.formRow}>
            <View style={{ flex: 1 }}>
              <Text style={styles.label}>Unit:</Text>
              <Animated.View style={{ transform: [{ scale: animation }] }}>
                <TextInput
                  style={[styles.input, { borderRadius: 20, backgroundColor: '#fff' }]}
                
                  value={unit}
                  placeholderTextColor="#666"
                />
              </Animated.View>
            </View>
            <View style={{ flex: 1, marginLeft: 10 }}>
              <Text style={styles.label}>Dosage:</Text>
              <Animated.View style={{ transform: [{ scale: animation }] }}>
                <TextInput
                  style={[styles.input, { borderRadius: 20, backgroundColor: '#fff' }]}
                  
                  value={dosage}
                  placeholderTextColor="#666"
                />
              </Animated.View>
            </View>
          </View>
          <View style={styles.formRow}>
            <View style={{ flex: 1 }}>
              <Text style={styles.label}>Things to Follow:</Text>
              <Animated.View style={{ transform: [{ scale: animation }] }}>
                <TextInput
                  style={[styles.input, { borderRadius: 20, backgroundColor: '#fff' }]}
                  
                  value={thingsToFollow}
                  placeholderTextColor="#666"
                />
              </Animated.View>
            </View>
            <View style={{ flex: 1, marginLeft: 10 }}>
              <Text style={styles.label}>Physician's Name:</Text>
              <Animated.View style={{ transform: [{ scale: animation }] }}>
                <TextInput
                  style={[styles.input, { borderRadius: 20, backgroundColor: '#fff' }]}
                  
                  value={physiciansName}
                  placeholderTextColor="#666"
                />
              </Animated.View>
            </View>
          </View>
        </View>
        <TouchableOpacity style={styles.bellButton} onPress={handleBellPress}>
          <Icon name="notifications" size={24} color="#fff" />
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
     backgroundColor: '#FFFFFF',
  },
  searchContainer: {
    flex: 1,
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 10,
    marginBottom: 20,
  },
  searchInput: {
    height: 40,
    borderWidth: 1,
    borderColor: '#ccc',
    paddingHorizontal: 10,
    marginBottom: 10,
  },
  searchButton: {
    backgroundColor: '#007BFF',
    borderRadius: 10,
    paddingVertical: 10,
     height: 38, 
  width: 200,
    paddingHorizontal: 20,
    alignItems: 'center',
    justifyContent: 'center',
     alignSelf: 'center',
  },
  searchButtonText: {
    color: 'white',
    fontSize: 16,
  },
  searchResult: {
    backgroundColor: '#f9f9f9',
    padding: 10,
    marginBottom: 10,
    borderRadius: 5,
  },
  searchResultText: {
    fontSize: 16,
  },
  headerImage: {
    width: '100%',
    height: 200,
     
    marginBottom: 20,
         borderRadius: 10,
   
  },
  formContainer: {
    marginTop: 10,
  },
  formRow: {
    flexDirection: 'row',
    marginBottom: 10,
  },
  label: {
    fontSize: 16,
    marginBottom: 5,
  },
  input: {
    height: 40,
    borderWidth: 1,
    borderColor: '#ccc',
    paddingHorizontal: 10,
  },
  bellButton: {
    position: 'absolute',
    bottom: 20,
    right: 20,
    backgroundColor: '#007BFF',
    borderRadius: 30,
    padding: 10,
    elevation: 5,
  },
  backgroundImage: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    width: '100%',
    height: '100%',
    opacity: 0.3,
  },
});

export default Search;
