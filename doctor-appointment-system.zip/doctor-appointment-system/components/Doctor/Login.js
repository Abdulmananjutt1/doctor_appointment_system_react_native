import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Animated,
  ImageBackground,
  Alert,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const LoginScreen = ({ navigation }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [fadeAnim] = useState(new Animated.Value(0));
  const [slideAnim] = useState(new Animated.Value(30));
  const [formHighlightAnim] = useState(new Animated.Value(0));
  const [inputHighlightAnim] = useState(new Animated.Value(0));
  const [focusedField, setFocusedField] = useState(null);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  useEffect(() => {
    if (focusedField) {
      Animated.parallel([
        Animated.timing(formHighlightAnim, {
          toValue: 1,
          duration: 500,
          useNativeDriver: false,
        }).start(),
        Animated.timing(inputHighlightAnim, {
          toValue: 1,
          duration: 500,
          useNativeDriver: false,
        }).start(),
      ]);
    } else {
      Animated.parallel([
        Animated.timing(formHighlightAnim, {
          toValue: 0,
          duration: 500,
          useNativeDriver: false,
        }).start(),
        Animated.timing(inputHighlightAnim, {
          toValue: 0,
          duration: 500,
          useNativeDriver: false,
        }).start(),
      ]);
    }
  }, [focusedField]);

  const handleLogin = async () => {
    if (!username && !password) {
      Alert.alert('Validation Error', 'Please enter both username and password');
      return;
    }

    if (!username) {
      Alert.alert('Validation Error', 'Please enter your username');
      return;
    }

    if (!password) {
      Alert.alert('Validation Error', 'Please enter your password');
      return;
    }

    try {
      const response = await fetch("https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Doctors.json");
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      const data = await response.json();

      let userFound = false;

      for (const key in data) {
        if (key === username && data[key].Password === password) {
          userFound = true;
          await AsyncStorage.setItem('userId', key); 
          Alert.alert('Login Success', 'You have successfully logged in!');
          navigation.navigate("Dashboard");
          break;
        }
      }

      if (!userFound) {
        Alert.alert('Login Failed', 'Invalid username or password');
      }
    } catch (error) {
      Alert.alert("An error occurred. Please try again");
    }
  };

  return (
    <ImageBackground
      source={{ uri: 'https://www.shutterstock.com/shutterstock/videos/1061123998/thumb/9.jpg?ip=x480' }}
      style={styles.backgroundImage}
    >
      <View style={styles.container}>
        <Animated.View
          style={[
            styles.formContainer,
            {
              borderColor: formHighlightAnim.interpolate({
                inputRange: [0, 1],
                outputRange: ['#ccc', '#00BFFF'], // Blue color
              }),
              shadowColor: formHighlightAnim.interpolate({
                inputRange: [0, 1],
                outputRange: ['#333', '#00BFFF'], // Blue color
              }),
              shadowOpacity: formHighlightAnim.interpolate({
                inputRange: [0, 1],
                outputRange: [0.2, 0.8],
              }),
              shadowRadius: formHighlightAnim.interpolate({
                inputRange: [0, 1],
                outputRange: [10, 20],
              }),
            },
          ]}
        >
          <Text style={styles.title}>Login Form</Text>
          <View style={styles.line} />
          <View style={styles.formGroup}>
            <Text style={styles.label}>Username</Text>
            <Animated.View
              style={[
                styles.inputWrapper,
                {
                  borderColor: inputHighlightAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: ['#ccc', '#00BFFF'], // Blue color
                  }),
                  shadowColor: inputHighlightAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: ['#333', '#00BFFF'], // Blue color
                  }),
                  shadowOpacity: inputHighlightAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [0.1, 0.5],
                  }),
                  shadowRadius: inputHighlightAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [5, 10],
                  }),
                },
              ]}
            >
              <TextInput
                style={styles.input}
                placeholder="Enter your username"
                placeholderTextColor="#aaa"
                value={username}
                onChangeText={setUsername}
                onFocus={() => setFocusedField('username')}
                onBlur={() => setFocusedField(null)}
              />
            </Animated.View>
          </View>
          <View style={styles.formGroup}>
            <Text style={styles.label}>Password</Text>
            <Animated.View
              style={[
                styles.inputWrapper,
                {
                  borderColor: inputHighlightAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: ['#ccc', '#00BFFF'], // Blue color
                  }),
                  shadowColor: inputHighlightAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: ['#333', '#00BFFF'], // Blue color
                  }),
                  shadowOpacity: inputHighlightAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [0.1, 0.45],
                  }),
                  shadowRadius: inputHighlightAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [5, 10],
                  }),
                },
              ]}
            >
              <TextInput
                style={styles.input}
                placeholder="Enter your password"
                placeholderTextColor="#aaa"
                value={password}
                onChangeText={setPassword}
                secureTextEntry
                onFocus={() => setFocusedField('password')}
                onBlur={() => setFocusedField(null)}
              />
            </Animated.View>
          </View>
          <TouchableOpacity
            onPress={handleLogin}
            style={styles.button}
          >
            <Text style={styles.buttonText}>Login</Text>
          </TouchableOpacity>
        </Animated.View>
      </View>
    </ImageBackground>
  );
};
const styles = StyleSheet.create({
  backgroundImage: {
    flex: 1,
    resizeMode: 'cover',
    justifyContent: 'center',
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  formContainer: {
    width: '80%',
    maxWidth: 360,
    backgroundColor: 'rgba(225, 255, 240, 0.5)',
    padding: 20,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: 'rgba(0, 0, 0, 0.1)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 10,
    elevation: 5,
    alignItems: 'center',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 10,
    textAlign: 'center',
    color: '#0033A0',
  },
  line: {
    height: 3,
    backgroundColor: '#0033A0',
    marginBottom: 20,
    width: '100%',
  },
  formGroup: {
    marginBottom: 20,
    width: '100%',
  },
  label: {
    fontSize: 15,                 
    fontWeight: 'bold',           
    color: 'black',             
    marginBottom: 5,              
    textAlign: 'center',          
  },
  inputWrapper: {
    borderWidth: 3,
    borderRadius: 18,
    padding: 2,
    marginBottom: 10,
  },
  input: {
    width: '100%',
    padding: 10,
    borderWidth: 0,
    borderColor: '#ddd',
    borderRadius: 18,
    backgroundColor: '#fff',
    fontSize: 16,
    color: '#333',
    outline: 'none',
  },
  button: {
    width: '40%',
    padding: 12,
    backgroundColor: '#007bff', // Blue color
    borderRadius: 25,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 20,
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '600',
  },
});


export default LoginScreen;
