import React, { useState, useEffect } from 'react';
import { StyleSheet, View, Text, Image, TouchableOpacity, ScrollView, Modal, FlatList, Alert } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';

const DoctorProfile = () => {
  const [showModal, setShowModal] = useState(false);
  const [doctorData, setDoctorData] = useState(null);
  const [reviews] = useState([
    {
      name: 'Haroon',
      feedback: 'Dr. AbdulManan is an excellent doctor. He is very knowledgeable and caring.',
      rating: 5,
    },
    {
      name: 'Awais',
      feedback: 'I had a great experience with Dr. AbdulManan. He is very professional and friendly.',
      rating: 4,
    },
    {
      name: 'Suleman',
      feedback: 'Dr. AbdulManan is a great doctor. He took the time to explain everything to me and made me feel comfortable.',
      rating: 4,
    },
    {
      name: 'Zain',
      feedback: 'I was impressed with Dr. AbdulManan\'s bedside manner. He is very kind and compassionate.',
      rating: 4,
    },
    {
      name: 'Waqas',
      feedback: 'Dr. AbdulManan is a very skilled doctor. He diagnosed my condition quickly and accurately.',
      rating: 5,
    },
  ]);

useEffect(() => {
    const fetchDoctorData = async () => {
      try {
        const userID = await AsyncStorage.getItem('userId');
        
        if (userID) {
          const response = await fetch('https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Doctors.json');
          const data = await response.json();

          if (data && data[userID]) {
            const doctor = data[userID];
            setDoctorData(doctor);
          } else {
            Alert.alert('Doctor not found');
          }
        } else {
          Alert.alert('User ID not found in AsyncStorage');
        }
      } catch (error) {
        console.error('Error fetching doctor data:', error);
      }
    };

    fetchDoctorData();
  }, []);
  const handleReadReviewsPress = () => {
    setShowModal(true);
  };

  const handleModalClose = () => {
    setShowModal(false);
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Image
          source={{ uri: 'https://static.vecteezy.com/system/resources/previews/007/522/855/non_2x/flat-design-doctor-free-vector.jpg' }}
          style={styles.doctorImage}
        />
        <View style={styles.headerText}>
          <Text style={styles.doctorName}>{doctorData ? doctorData.Name : 'Loading...'}</Text>
          <Text style={styles.doctorTitle}>BDS Dentist, Dental Surgeon</Text>
        </View>
        <TouchableOpacity onPress={() => console.log('Edit Pressed')}>
          <MaterialIcons name="edit" size={24} color="#fff" />
        </TouchableOpacity>
      </View>
      <View style={styles.statsContainer}>
        <TouchableOpacity style={[styles.stat, styles.border]} onPress={() => console.log('Patients Pressed')}>
          <MaterialIcons name="people" size={24} color="#4A90E2" />
          <Text style={styles.statTitle}>Patients</Text>
          <Text style={styles.statValue}>{doctorData ? '1100+' : '1100+'}</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.stat, styles.border]} onPress={() => console.log('Experience Pressed')}>
          <MaterialIcons name="lock" size={24} color="#4A90E2" />
          <Text style={styles.statTitle}>Experience</Text>
          <Text style={styles.statValue}>{doctorData ? '13 Years' : '13 year'}</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.stat, styles.border]} onPress={() => console.log('Reviews Pressed')}>
          <MaterialIcons name="star" size={24} color="#4A90E2" />
          <Text style={styles.statTitle}>Reviews</Text>
          <Text style={styles.statValue}>{doctorData ? '4.00' : '4.0'}</Text>
        </TouchableOpacity>
      </View>
      <View style={[styles.biographyContainer, styles.border]}>
        <View style={styles.infoContainer}>
          <MaterialIcons name="info" size={24} color="#4A90E2" />
          <Text style={styles.biographyTitle}>Biography</Text>
        </View>
        <Text style={styles.biographyText}>
          {doctorData ? '54 yrs. female patient had cancer in her food pipe. Despite possible medical management with the help of oncosurgey, chemotherapy & radiation therapy there was progression of disease resulting in prolonged hospital stay' : '54 yrs. female patient had cancer in her food pipe. Despite possible medical management with the help of oncosurgey, chemotherapy & radiation therapy there was progression of disease resulting in prolonged hospital stay'}
        </Text>
        <View style={styles.divider} />
        <View style={styles.infoContainer}>
          <MaterialIcons name="email" size={24} color="#4A90E2" />
          <Text style={styles.infoLabel}>Email:</Text>
          <Text style={styles.infoValue}>{doctorData ? doctorData.Email : 'Loading...'}</Text>
        </View>
        <View style={styles.infoContainer}>
          <MaterialIcons name="phone" size={24} color="#4A90E2" />
          <Text style={styles.infoLabel}>Contact:</Text>
          <Text style={styles.infoValue}>{doctorData ? doctorData.Contact : 'Loading...'}</Text>
        </View>
        <View style={styles.infoContainer}>
          <MaterialIcons name="location-on" size={24} color="#4A90E2" />
          <Text style={styles.infoLabel}>Address:</Text>
          <Text style={styles.infoValue}>{doctorData ? 'Gift University,Grw,Pakistan' : 'Loading...'}</Text>
        </View>
        <View style={styles.infoContainer}>
          <MaterialIcons name="attach-money" size={24} color="#4A90E2" />
          <Text style={styles.infoLabel}>Salary:</Text>
          <Text style={styles.infoValue}>{doctorData ? doctorData.Fees : 'Loading...'}</Text>
        </View>
      </View>
      <View style={styles.actionsContainer}>
        <TouchableOpacity style={[styles.actionButton, { flex: 1 }]} onPress={handleReadReviewsPress}>
          <MaterialIcons name="star" size={24} color="#fff" />
          <Text style={styles.actionButtonText}>Read Reviews</Text>
        </TouchableOpacity>
        <Modal animationType="slide" transparent={true} visible={showModal}>
          <View style={styles.modalContainer}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Reviews</Text>
              <TouchableOpacity onPress={handleModalClose}>
                <MaterialIcons name="close" size={24} color="#fff" />
              </TouchableOpacity>
            </View>
            <View style={styles.modalContent}>
              <FlatList
                data={reviews}
                renderItem={({ item }) => (
                  <View style={styles.reviewContainer}>
                    <Text style={styles.reviewName}>{item.name}</Text>
                    <Text style={styles.reviewFeedback}>{item.feedback}</Text>
                    <View style={styles.reviewRating}>
                      {[...Array(item.rating)].map((_, i) => (
                        <MaterialIcons key={i} name="star" size={18} color="#ffd700" />
                      ))}
                      {[...Array(5 - item.rating)].map((_, i) => (
                        <MaterialIcons key={i} name="star" size={18} color="#ccc" />
                      ))}
                    </View>
                  </View>
                )}
                keyExtractor={(item) => item.name}
              />
            </View>
          </View>
        </Modal>
        <TouchableOpacity style={[styles.actionButton, { flex: 1, justifyContent: 'center' }]} onPress={() => console.log('Share With Friends Pressed')}>
          <MaterialIcons name="share" size={24} color="#fff" />
          <Text style={styles.actionButtonText}>Share With Friends</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.actionButton, { flex: 1 }]} onPress={() => console.log('Privacy Policy Pressed')}>
          <MaterialIcons name="lock" size={24} color="#fff" />
          <Text style={styles.actionButtonText}>Privacy Policy</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#4A90E2',
  },
  doctorImage: {
    width: 80,
    height: 80,
    borderRadius: 50,
    marginRight: 20,
  },
  headerText: {
    flex: 1,
  },
  doctorName: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#fff',
  },
  doctorTitle: {
    fontSize: 14,
    color: '#fff',
  },
  
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    padding: 20,
  },
  stat: {
    alignItems: 'center',
    padding: 20,
  },
  border: {
    borderWidth: 1,
    borderColor: '#D3D3D3', // Light gray color
    borderRadius: 10,
    padding: 10,
  },
  statTitle: {
    fontSize: 14,
    color: '#4A90E2',
    marginTop: 10,
  },
  statValue: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  biographyContainer: {
    padding: 20,
  },
  biographyTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  biographyText: {
    fontSize: 14,
    marginTop: 10,
  },
  divider: {
    borderBottomWidth: 1,
    borderBottomColor: '#D3D3D3', // Light gray color
    marginTop: 10,
    marginBottom: 10,
  },
  infoContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 10,
  },
  infoLabel: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  infoValue: {
    fontSize: 14,
    marginLeft: 10,
  },
  
  
 modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#4A90E2',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
  },
  modalContent: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  reviewContainer: {
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#D3D3D3',
  },
  reviewName: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  reviewFeedback: {
    fontSize: 14,
    marginTop: 10,
  },
  reviewRating: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 10,
  },
 actionsContainer: {
  padding: 20,
 
  justifyContent: 'center', // Center the buttons horizontally
  alignItems: 'center', // Center the buttons vertically
},
 actionButton: {
    backgroundColor: '#4A90E2',
    height: 60,
    width: 250,
    padding: 15,
    borderRadius: 5,
    marginBottom: 10,
        alignItems: 'center',
    justifyContent: 'center',
  },
  actionButtonText: {
    fontSize: 16,
    color: '#fff',
    textAlign: 'center',
    marginLeft: 10,
  },
});

export default DoctorProfile; 