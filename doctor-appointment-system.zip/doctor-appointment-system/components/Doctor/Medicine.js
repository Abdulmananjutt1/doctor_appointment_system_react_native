import React, { useState } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, ScrollView, TextInput } from 'react-native';

const Medicine = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [medicines, setMedicines] = useState([
    {
      name: 'Motrin',
      description: 'IB, Ibuprofen 200mg Tablets for Fever, Muscle Aches, Headache & Backache, 225',
      imageUrl: 'https://media.istockphoto.com/id/635948926/photo/3d-rendering-of-antibiotic-pills-in-blister-pack.jpg?s=612x612&w=0&k=20&c=5dSgDQojTp0hR6VfdPNm5VYmXHZNobOhf3XT17YKc3s=',
      rating: 4.5,
      ratingCount: 12790,
    },
    {
      name: 'Lorem',
      description: 'IB, Ibuprofen 200mg Tablets for Fever, Muscle Aches, Headache & Backache, 225',
      imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQMvGeFawRma5xfHU00MoIiCfH6Yq5ertbQteu0QcdgaJA0qfjqKr_PX90J7WJ4FXBTti0&usqp=CAU',
      rating: 4.2,
      ratingCount: 11000,
    },
    {
      name: 'Panadol',
      description: 'IB, Ibuprofen 200mg Tablets for Fever, Muscle Aches, Headache & Backache, 225',
      imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT9DEMvfTN1gyaFCuF0MApkYGenWekA9ep9p1sfXeI_qKVxx3UDuwP6Fq_vrojoNFk8IZQ&usqp=CAU',
      rating: 4,
      ratingCount: 10000,
    },
    {
      name: 'Tylenol',
      description: 'Acetaminophen 500mg Tablets for Pain Relief, Fever Reduction, 100 Count',
      imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRwH2u_bLPqpBVrK5K7PzFuLnRdx2TjqPFbAfA8sMRytawwlceEBec9mlHlo3xmEl5JSmw&usqp=CAU',
      rating: 4.3,
      ratingCount: 9500,
    },
    {
      name: 'Advil',
      description: 'Ibuprofen 200mg Tablets for Pain Relief, Fever Reduction, 100 Count',
      imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSNwk04UoRC5y21SZw3nhElj7yiRLNU7oKRaQ&s',
      rating: 4.6,
      ratingCount: 11200,
    },
    {
      name: 'Aleve',
      description: 'Naproxen Sodium 220mg Tablets for Pain Relief, Arthritis, 100 Count',
      imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQLqzJPgywP482y60Q5NhglWJX61jqWUiKXy4NA6nvTpyD_EK0rxg7Fhz9ovIAc_C0te8Q&usqp=CAU',
      rating: 4.1,
      ratingCount: 7800,
    },
    {
      name: 'Aspirin',
      description: 'Aspirin 325mg Tablets for Pain Relief, Fever Reduction, 100 Count',
      imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQOHSyRlaRlnbM53HvmdK2r4t6IFDUJeuAVE6WoiaxLPzsp4oCd0nmJvBKzYEzApqMf5Mk&usqp=CAUg',
      rating: 3.8,
      ratingCount: 6500,
    },
    {
      name: 'Pepto-Bismol',
      description: 'Liquid for Upset Stomach, Heartburn, Diarrhea, 12 oz',
      imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQPRZ7OJLFc6xnOAtowHLTSPtSTxsz3zP8lHw&s',
      rating: 4.4,
      ratingCount: 8900,
    },
    {
      name: 'Benadryl',
      description: 'Diphenhydramine 25mg Tablets for Allergies, Sleep Aid, 24 Count',
      imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRV5zdksZSED_rept2CwCxaDlHmjYY9qUIhBg&s',
      rating: 4,
      ratingCount: 7200,
    },
    {
      name: 'Zyrtec',
      description: 'Cetirizine 10mg Tablets for Allergies, 30 Count',
      imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS8Xmbc-LkAatsYDaG6VziHhPaelXrlhlT8voLYaXLi06jVcg0AkTpfBsXn9ys6qRCHKQA&usqp=CAU',
      rating: 4.7,
      ratingCount: 10500,
    },
    {
      name: 'Claritin',
      description: 'Loratadine 10mg Tablets for Allergies, 30 Count',
      imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTLpJ3xVC0nGhklfwtZwH97Hbcyn5MSnrk7WQ&s',
      rating: 4.2,
      ratingCount: 8400,
    },
    {
      name: 'Prilosec OTC',
      description: 'Omeprazole 20mg Capsules for Heartburn, Acid Reflux, 14 Count',
      imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRN96qXKmWpIVhRwgFM1OGGa_uGA-JZ7axMMw&s',
      rating: 4.5,
      ratingCount: 9800,
    },
    {
      name: 'Tums',
      description: 'Antacids for Heartburn, Indigestion, 100 Count',
      imageUrl: 'https://i-cf65.ch-static.com/content/dam/cf-consumer-healthcare/bp-anadin-v2/en_GB/redesign/product-images/Anadin-Paracetamol-16s_600.jpg?auto=format',
      rating: 4,
      ratingCount: 6800,
    },
    {
      name: 'Nexium 24HR',
      description: 'Esomeprazole 20mg Capsules for Heartburn, Acid Reflux, 14 Count',
      imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR6GtoeGPgBtLyFRTuJc3MyFFr17szE9r0U3A&s',
      rating: 4.6,
      ratingCount: 10200,
    },
    {
      name: 'Rolaids',
      description: 'Antacids for Heartburn, Indigestion, 100 Count',
      imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQeR2Sgd8j_ZR3qMg3_LzzmtiPayvf9qof7nQSYkzM1czJxWufdQPx7yvXI8wqT3nSLDOE&usqp=CAU',
      rating: 4.2,
      ratingCount: 7500,
    },
  ]);

  const handleSearch = (text) => {
    setSearchQuery(text);
  };

  // Filtering logic: Show only medicines that start with the search query
  const filteredMedicines = medicines.filter((medicine) => {
    if (searchQuery === '') {
      return true;
    } else {
      return medicine.name.toLowerCase().startsWith(searchQuery.toLowerCase());
    }
  });

  return (
    <View style={styles.container}>
      <View style={styles.searchContainer}>
        <Text style={styles.allText}>All</Text>
        <View style={styles.searchInput}>
          <TextInput
            style={styles.searchText}
            placeholder="Search for medicine"
            value={searchQuery}
            onChangeText={handleSearch}
          />
          <Image
            source={{ uri: 'https://cdn3.iconfinder.com/data/icons/feather-5/24/search-512.png' }}
            style={styles.searchIcon}
          />
        </View>
      </View>

      <ScrollView style={styles.scrollView}>
        {filteredMedicines.length > 0 ? (
          <View style={styles.productContainer}>
            {filteredMedicines.map((medicine, index) => (
              <TouchableOpacity key={index} style={styles.product}>
                <Image
                  source={{ uri: medicine.imageUrl }}
                  style={styles.productImage}
                />
                <Text style={styles.productName}>{medicine.name}</Text>
                <Text style={styles.productDescription}>{medicine.description}</Text>
                <View style={styles.productRating}>
                  <Image
                    source={{ uri: 'https://static.vecteezy.com/system/resources/thumbnails/012/488/033/small_2x/star-3d-illustration-png.png' }}
                    style={styles.starIcon}
                  />
                  <Text style={styles.ratingCount}>{medicine.rating}</Text>
                  <Text style={styles.ratingCount}>({medicine.ratingCount})</Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        ) : (
          <View style={styles.noResultsContainer}>
            <Text style={styles.noResultsText}>Medicine not found. Out of stock.</Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#F5F5F5',
  },
  starIcon: {
    width: 16,
    height: 16,
    resizeMode: 'contain',
    tintColor: '#F7DC6F', // yellow color for the star icon
  },
  allText: {
    fontSize: 16,
    fontWeight: 'bold',
    marginRight: 8,
    color: '#007bff' // blue color for "All" text
  },
  searchInput: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    flex: 1,
  },
  searchText: {
    fontSize: 14,
    color: '#000',
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  noResultsContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  noResultsText: {
    fontSize: 18,
    color: '#999',
    textAlign: 'center',
  },
  productContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: 16,
    marginTop: 16,
    justifyContent: 'space-between',
  },
  product: {
    width: '48%',
    marginBottom: 16,
    backgroundColor: '#f8f9fa', // light gray background for the product card
    padding: 10,
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  searchIcon: {
    width: 20,
    height: 20,
    tintColor: '#333',
    marginRight: 8,
  },
  productImage: {
    width: '100%',
    height: 150,
    borderRadius: 8,
  },
  productName: {
    fontSize: 16,
    fontWeight: 'bold',
    marginTop: 8,
    color: '#333', // dark gray color for product name
  },
  productDescription: {
    fontSize: 12,
    color: '#666',
    marginTop: 4,
  },
  productRating: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
  },
  ratingCount: {
    fontSize: 14,
    color: '#000',
  },
});

export default Medicine;
