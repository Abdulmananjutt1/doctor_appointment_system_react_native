import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Dimensions,
  TouchableOpacity,
  Modal,
  ScrollView,
  Animated,
  TextInput,
  Image,
  Alert,
  ImageBackground,
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { LineChart } from 'react-native-chart-kit';
import { Calendar } from 'react-native-calendars';

const Dashboard = () => {
  const [chartModalVisible, setChartModalVisible] = useState(false);
  const [dateModalVisible, setDateModalVisible] = useState(false);
  const [selectedDate, setSelectedDate] = useState(null);
   const [loadingUsers, setLoadingUsers] = useState(true);
   const [totalAppointments, setTotalAppointments] = useState(null);
  const [applicationModalVisible, setApplicationModalVisible] = useState(false);
  const [animatedValue, setAnimatedValue] = useState(new Animated.Value(0));
  const [inputValues, setInputValues] = useState({
    application: '',
    response: '',
  });
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [applicationId, setApplicationId] = useState(null);

  const handleDatePress = (date) => {
    setSelectedDate(date);
    setDateModalVisible(true);
  };

  const handleChartPress = () => {
    setChartModalVisible(true);
  };
  const handleHeartRatePress = () => {
    console.log('Heart Rate Pressed');
  };
  const handleStepsPress = () => {
    console.log('Steps Pressed');
  };
  const handleBloodPressurePress = () => {
    console.log('Blood Pressure Pressed');
  };
  const handleSleepConditionPress = () => {
    console.log('Sleep Condition Pressed');
  };
  const handleOverallHealthPress = () => {
    console.log('Overall Health Pressed');
  };

  const handleInputChange = (inputName, value) => {
    setInputValues((prevInputValues) => ({
      ...prevInputValues,
      [inputName]: value,
    }));
  };
   fetch('https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Appointments.json')
      .then(response => response.json())
      .then(data => {
        const appointmentCount = Array.isArray(data) ? data.length : Object.keys(data).length;
        setTotalAppointments(appointmentCount);
        setLoadingUsers(false);
      })
      .catch(error => {
        console.error('Error fetching total appointments:', error);
        setLoadingUsers(false);
      });
  const handleSubmit = async () => {
    try {
      const response = await fetch(
        'https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Applications.json',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            date: selectedDate,
            application: inputValues.application,
          }),
        }
      );

      if (!response.ok) {
        throw new Error('Failed to submit the application');
      }

      const data = await response.json();
      setApplicationId(data.name);
      setIsSubmitted(true);

      console.log('Application submitted successfully');
      setDateModalVisible(false);

      // Show alert
      Alert.alert(
        'Success',
        'Your application has been submitted successfully',
        [
          {
            text: 'OK',
            onPress: () => console.log('OK Pressed'),
          },
        ],
        { cancelable: false }
      );
    } catch (error) {
      console.error(error);

      // Show alert
      Alert.alert(
        'Error',
        'Failed to submit the application',
        [
          {
            text: 'OK',
            onPress: () => console.log('OK Pressed'),
          },
        ],
        { cancelable: false }
      );
    }
  };

  const handleUnsubmit = async () => {
    try {
      await fetch(
        `https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Applications/${applicationId}.json`,
        {
          method: 'DELETE',
        }
      );

      setIsSubmitted(false);
      setApplicationId(null);

      console.log('Application unsubmitted successfully');

      // Show alert
      Alert.alert(
        'Success',
        'Your application has been unsubmitted successfully',
        [
          {
            text: 'OK',
            onPress: () => console.log('OK Pressed'),
          },
        ],
        { cancelable: false }
      );
    } catch (error) {
      console.error(error);

      // Show alert
      Alert.alert(
        'Error',
        'Failed to unsubmit the application',
        [
          {
            text: 'OK',
            onPress: () => console.log('OK Pressed'),
          },
        ],
        { cancelable: false }
      );
    }
  };
  // const handlePress = () => {
  //   setModalVisible(true);
  // };

  useEffect(() => {
    Animated.timing(animatedValue, {
      toValue: 1,
      duration: 2000,
      useNativeDriver: true,
    }).start();
  }, []);

  return (
    // <ImageBackground
    //   source={{ uri: 'https://t3.ftcdn.net/jpg/06/61/06/74/240_F_661067435_cdi1wpytl4pvfzBYYDryTfcscE1ZpYRB.jpg' }}
    //   style={{ flex: 1, resizeMode: 'cover' }}
    // >
    <ScrollView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerText}>Device Connected</Text>
      </View>

      {/* User Section */}
      <View style={styles.userSection}>
        <Text style={styles.userGreeting}>Hello, AbdulManan</Text>
        <Text style={styles.userSubText}>
          It looks like you have not completed your exercise today.
        </Text>
      </View>

      {/* Stats Container */}
      <View style={styles.statsContainer}>
        <TouchableOpacity
          style={styles.statCard}
          onPress={handleHeartRatePress}>
          <Icon
            name="heart-pulse"
            size={24}
            color="red"
            style={styles.statIcon}
          />
          <Text style={styles.statTitle}>Heart Rate</Text>
          <Text style={styles.statValue}>104 bpm</Text>
          <Text style={styles.statSubText}>Your heart rate is normal.</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.statCard} onPress={handleStepsPress}>
          <Icon name="walk" size={24} color="yellow" style={styles.statIcon} />
          <Text style={styles.statTitle}>Steps</Text>
          <Text style={styles.statValue}>2,011 steps</Text>
          <Text style={styles.statSubText}>
            Need 7,989 more steps to complete 10,000 steps.
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.statCard}
          onPress={handleBloodPressurePress}>
          <Icon name="gauge" size={24} color="blue" style={styles.statIcon} />
          <Text style={styles.statTitle}>Blood Pressure</Text>
          <Text style={styles.statValue}>98 mmHg</Text>
          <Text style={styles.statSubText}>Your blood pressure is normal.</Text>
        </TouchableOpacity>
      </View>
      {/* Sleep Section */}
      <View style={styles.sleepSection}>
        <TouchableOpacity
          style={styles.statCard}
          onPress={handleSleepConditionPress}>
          <View style={{ display: 'flex', flexDirection: 'row' }}>
            <Icon
              name="sleep"
              size={24}
              color="black"
              style={styles.statIcon}
            />
            <Text style={styles.statTitle}>Sleep Condition</Text>
          </View>
          <Text style={styles.statValue}>104 bpm</Text>
          <Text style={styles.statSubText}>
            Take a break from work and take rest
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.overallHealthCard}
          onPress={handleOverallHealthPress}>
          <Icon
            name="heart-circle"
            size={24}
            color="red"
            style={styles.statIcon}
          />
          <Text style={styles.statTitle}>Overall Health</Text>
          <Text style={styles.statSubText}>2% greater than last week</Text>
          <View style={styles.healthProgress}>
            <Text style={styles.healthProgressText}>69%</Text>
          </View>
        </TouchableOpacity>
      </View>
      {/* New Section for Patients and Income */}
      <View style={styles.header}>
        <Text style={styles.headerText}>Appoinments</Text>
      </View>
      <View style={styles.statsContainer}>
        <View style={styles.statCard}>
          <Icon
            name="account-multiple"
            size={24}
            color="black"
            style={styles.statIcon}
          />
          <Text style={styles.statTitle}>Patients</Text>
          <Text style={styles.statSubText}>20</Text>
        </View>
        <View style={styles.statCard}>
          <Icon name="cash" size={24} color="green" style={styles.statIcon} />
          <Text style={styles.statTitle}>Income</Text>
          <Text style={styles.statSubText}>$70</Text>
        </View>
      </View>

      {/* Section for Appointments and Treatments */}

      <View style={styles.statsContainer}>
        <View style={styles.statCard}>
          <Icon
            name="calendar-month"
            size={24}
            color="#2196F3"
            style={styles.statIcon}
          />
           
                    <Text style={styles.statText}>Appointments</Text>
                    <Text style={styles.statText1}>{loadingUsers ? 'Loading...' : totalAppointments}</Text>
                  
        </View>
        <View style={styles.statCard}>
          <Icon name="heart" size={24} color="red" style={styles.statIcon} />
          <Text style={styles.statTitle}>Treatments</Text>
          <Text style={styles.statSubText}>1</Text>
        </View>
      </View>

      {/* Chart Section */}
      <TouchableOpacity style={styles.chartSection} onPress={handleChartPress}>
        <View style={{ display: 'flex', flexDirection: 'row' }}>
          <Icon
            name="chart-bar"
            size={24}
            color="#2196F3"
            style={styles.statIcon}
          />
          <Text style={styles.chartTitle}>Activity Chart</Text>
        </View>

        <View style={styles.chartContainer}>
          <View style={styles.chartBar} />
          <View style={styles.chartBar} />
          <View style={styles.chartBar} />
          <View style={styles.chartBar} />
          <View style={styles.chartBar} />
          <View style={styles.chartBar} />
          <View style={styles.chartBar} />
        </View>
        <View style={styles.chartLabels}>
          <Text>Sun</Text>
          <Text>Mon</Text>
          <Text>Tue</Text>
          <Text>Wed</Text>
          <Text>Thu</Text>
          <Text>Fri</Text>
          <Text>Sat</Text>
        </View>
      </TouchableOpacity>

      {/* Profile Section */}

      <View style={styles.profileSection}>
        <View style={styles.profileCard}>
          <Image
            style={styles.profileImage}
            source={{
              uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTJqwavrJ1E4PXdSSShqcvMjxjmuwVZnfzMZQ&s',
            }}
          />
          <Text style={styles.profileName}>AbdulManan</Text>
          <Text style={styles.profileAge}>20 years</Text>
        </View>

        <View style={styles.profileStatsContainer}>
          <View style={styles.profileStatCard}>
            <Icon
              name="weight-kilogram"
              size={20}
              color="#2196F3"
              style={styles.profileStatIcon}
            />
            <Text style={styles.profileStatTitle}>Weight</Text>
            <Text style={styles.profileStatValue}>62 kg</Text>
          </View>

          <View style={styles.profileStatCard}>
            <Icon
              name="human-male-height"
              size={20}
              color="#2196F3"
              style={styles.profileStatIcon}
            />
            <Text style={styles.profileStatTitle}>Height</Text>
            <Text style={styles.profileStatValue}>160 cm</Text>
          </View>
        </View>
      </View>
      {/* Calendar Section */}
      <View style={styles.calendarWrapper}>
        <View style={styles.calendarCard}>
          <Icon
            name="calendar-month"
            size={24}
            color="#2196F3"
            style={styles.statIcon}
          />
          <Text style={styles.yearLabel}>2024</Text>
          <Text style={styles.monthLabel}>August</Text>
          <View style={styles.weekdaysRow}>
            <Text>Mon</Text>
            <Text>Tue</Text>
            <Text>Wed</Text>
            <Text>Thu</Text>
            <Text>Fri</Text>
            <Text>Sat</Text>
            <Text>Sun</Text>
          </View>
          <View style={styles.datesGrid}>
            {Array.from({ length: 31 }, (_, i) => i + 1).map((date) => (
              <TouchableOpacity
                key={date}
                onPress={() => handleDatePress(date)}>
                <Text style={styles.dateCell}>{date}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      </View>

      {/* Modal for input fields */}
      <Modal
        visible={dateModalVisible}
        animationType="fade"
        transparent={true}
        onRequestClose={() => setDateModalVisible(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalDialog}>
            <Text style={styles.modalTitleText}>
              Enter details for {selectedDate}
            </Text>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Application:</Text>
              <TextInput
                style={styles.applicationInput}
                value={inputValues.application}
                onChangeText={(text) => handleInputChange('application', text)}
              />
            </View>
            {inputValues.response ? (
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Response:</Text>
                <TextInput
                  style={styles.responseInput}
                  value={inputValues.response}
                  onChangeText={(text) => handleInputChange('response', text)}
                />
              </View>
            ) : null}
            {isSubmitted ? (
              <TouchableOpacity
                style={styles.unsubmitBtn}
                onPress={handleUnsubmit}>
                <Text style={styles.unsubmitBtnText}>Unsubmit</Text>
              </TouchableOpacity>
            ) : (
              <TouchableOpacity
                style={styles.submitButton}
                onPress={handleSubmit}>
                <Text style={styles.submitButtonText}>Submit</Text>
              </TouchableOpacity>
            )}
          </View>
        </View>
      </Modal>
      {/* Modal for Animated Graph */}
      <Modal
        visible={chartModalVisible}
        animationType="fade"
        transparent={true}
        onRequestClose={() => setChartModalVisible(false)}>
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <View
              style={{
                flex: 1,
                justifyContent: 'center',
                alignItems: 'center',
              }}>
              <LineChart
                data={{
                  labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                  datasets: [{ data: [20, 45, 28, 80, 99, 43] }],
                }}
                width={400}
                height={180}
                chartConfig={{
                  backgroundColor: '#e26a00',
                  backgroundGradientFrom: '#fb8c00',
                  backgroundGradientTo: '#ffa726',
                  decimalPlaces: 2,
                  color: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`,
                  style: { borderRadius: 16 },
                }}
                style={styles.chart}
              />
            </View>
            <TouchableOpacity
              style={styles.closeButton}
              onPress={() => setChartModalVisible(false)}>
              <Text style={styles.closeButtonText}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </ScrollView>
    // </ImageBackground>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
    padding: 20,
  },

  header: {
    backgroundColor: '#f2f2f2',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  headerText: {
    fontSize: 18,
    fontWeight: 'bold',
    // color: '#333',
    color: 'blue',
  },

  userSection: {
    marginBottom: 20,
  },
  userGreeting: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  userSubText: {
    color: '#888',
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  statCard: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 10,
    flex: 1,
    marginRight: 10,
  },
  statTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  statSubText: {
    color: '#888',
  },
  //    animatedGraph: {
  // position: 'absolute',
  //     left: 0,
  //     right: 0,
  //     top: 0,
  //     bottom: 0,
  //     justifyContent: 'center',
  //     alignItems: 'center',
  //   },
  sleepSection: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  overallHealthCard: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 10,
    flex: 1,
    marginLeft: 10,
  },
  healthProgress: {
    backgroundColor: '#e0f2f7',
    padding: 10,
    borderRadius: 50,
    marginTop: 10,
    alignItems: 'center',
  },
  healthProgressText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#2196F3',
  },
  chartSection: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 10,
    marginBottom: 20,
  },
  chartTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  chartContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  chartBar: {
    backgroundColor: '#2196F3',
    width: 20,
    height: 60,
    borderRadius: 5,
    marginBottom: 10,
  },
  statIcon: {
    display: 'flex',
  },

  chartLabels: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  profileSection: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  profileCard: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 10,
    flex: 1,
    marginRight: 10,
    alignItems: 'center',
  },
  profileImage: {
    width: 80,
    height: 80,
    borderRadius: 50,
    marginBottom: 10,
  },
  profileName: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  profileAge: {
    color: '#888',
  },
  profileStatsContainer: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 10,
    flex: 1,
    marginLeft: 10,
    alignItems: 'center',
  },
  profileStatCard: {
    marginBottom: 10,
  },
  profileStatTitle: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  profileStatValue: {
    fontSize: 16,
  },

  calendarCard: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 10,
  },
  //   dashboardContainer: {
  //   flex: 1,
  //   backgroundColor: '#f2f2f2',
  //   padding: 20,
  // },
  calendarWrapper: {
    marginBottom: 20,
  },

  yearLabel: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  monthLabel: {
    fontSize: 16,
    marginBottom: 10,
  },
  weekdaysRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 10,
  },
  datesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-around',
  },
  dateCell: {
    fontSize: 16,
    padding: 10,
  },
  modalOverlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalDialog: {
    width: '90%',
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 20,
    alignItems: 'center',
  },
  modalTitleText: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  inputGroup: {
    marginBottom: 10,
  },
  inputLabel: {
    fontSize: 16,
    marginBottom: 5,
  },

  // submitButtonText: {
  //   color: '#fff',
  //   fontSize: 16,
  //   fontWeight: 'bold',
  // },
  applicationInput: {
    height: 100,
    borderColor: 'gray',
    borderWidth: 1,
    padding: 10,
    width: '300',
    borderRadius: 5,
    backgroundColor: '#fff',
    marginBottom: 10,
  },
  submitButton: {
    backgroundColor: '#2196F3',
    padding: 10,
    borderRadius: 5,
    marginTop: 10,
  },
  submitButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  unsubmitBtn: {
    backgroundColor: '#FF0000',
    padding: 10,
    borderRadius: 5,
    marginTop: 10,
  },
  unsubmitBtnText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  responseInput: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    padding: 10,
    width: '120',
    borderRadius: 5,
    backgroundColor: '#fff',
    marginBottom: 10,
  },
  submitBtn: {
    backgroundColor: '#2196F3',
    padding: 10,
    borderRadius: 5,
    marginTop: 10,
  },
  submitBtnText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },

  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    width: '100%',
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 20,
    alignItems: 'center',
    height: '40%',
    justifyContent: 'space-between',
  },

  closeButton: {
    backgroundColor: '#2196F3',
    padding: 10,
    borderRadius: 5,
  },
  closeButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  chart: {
    borderRadius: 16,
  },
});

export default Dashboard;
