import React, { useState, useEffect } from 'react';
import { View, Text, Button, StyleSheet, TouchableOpacity, TextInput, FlatList, ScrollView, Alert, Image, Animated } from 'react-native';

const Write = ({ navigation }) => {
  const [searchText, setSearchText] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [bloodPressure, setBloodPressure] = useState('');
  const [pulseRate, setPulseRate] = useState('');
  const [diagnosedWith, setDiagnosedWith] = useState('');
  const [drug, setDrug] = useState('');
  const [unit, setUnit] = useState('');
  const [dosage, setDosage] = useState('');
  const [thingsToFollow, setThingsToFollow] = useState('');
  const [physiciansName, setPhysiciansName] = useState('');
  const [patientName, setPatientName] = useState('');
  const [age, setAge] = useState('');
  const [contact, setContact] = useState('');
  const [dateOfBirth, setDateOfBirth] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');

  // Animation
  const [bloodPressureFocused, setBloodPressureFocused] = useState(false);
  const [pulseRateFocused, setPulseRateFocused] = useState(false);
  const [diagnosedWithFocused, setDiagnosedWithFocused] = useState(false);
  const [drugFocused, setDrugFocused] = useState(false);
  const [unitFocused, setUnitFocused] = useState(false);
  const [dosageFocused, setDosageFocused] = useState(false);
  const [thingsToFollowFocused, setThingsToFollowFocused] = useState(false);
  const [physiciansNameFocused, setPhysiciansNameFocused] = useState(false);
  const animation = new Animated.Value(0);
const [email,setEmail]=useState('')
  useEffect(() => {
    Animated.spring(animation, {
      toValue: 1,
      friction: 4,
      tension: 40,
    }).start();
  }, []);

  const handleSearch = async (text) => {
    setSearchText(text);
    try {
      const response = await fetch('https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Appointments.json');
      const data = await response.json();
      console.log('Fetched data:', data); 
      const searchTokenId = text.trim(); 
      console.log('Searching for TokenId:', searchTokenId);
      const results = Object.values(data).filter(item => item.Name === searchTokenId);
    
      if (results.length > 0) {
        const tokenDetails = results[0]; 
        setPatientName(tokenDetails.Name);
        setAge(tokenDetails.Age);
        setContact(tokenDetails.Contact);
        setDateOfBirth(tokenDetails.Birth);
        setDate(tokenDetails.AppointmentDate);
        setTime(tokenDetails.AppointmentTime);
        setEmail(tokenDetails.Email)
        setSearchResults(results); // Update search results state
      } else {
        Alert.alert('No matching found.');
        setSearchResults([]); // Clear search results if no match
      }
    } catch (error) {
      console.error('Fetch error:', error);
      Alert.alert('Error', 'Something went wrong while fetching data');
      setSearchResults([]); // Clear search results on error
    }
  };

  const storeData = async () => {
    if (
      !patientName ||
      !age ||
      !contact ||
      !dateOfBirth ||
      !date ||
      !bloodPressure ||
      !pulseRate ||
      !diagnosedWith ||
      !drug ||
      !unit ||
      !dosage ||
      !thingsToFollow ||
      !physiciansName
    ) {
      Alert.alert('Error', 'Please fill all fields before submitting');
      return;
    }
const tokenID = `${patientName}`;
    try {
      await fetch('https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/MedicalRecords.json', {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          TokenID:tokenID,
          patientName,
          age,
          contact,
          dateOfBirth,
          date,
          bloodPressure,
          pulseRate,
          diagnosedWith,
          drug,
          unit,
          dosage,
          thingsToFollow,
          physiciansName,
          time,
          email,
        }),
      });
      Alert.alert('Success', 'Data submitted successfully!');
    } catch (error) {
      console.error('Submission error:', error);
      Alert.alert('Error', 'Failed to submit data');
    }
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: '#f0f0f0' }}>
      <View style={[styles.container, { backgroundColor: 'black ' }]}>
        <Image
          style={styles.backgroundImage}
          source={{ uri: 'https://media.phillyvoice.com/media/images/051019_doctors_order_cancer_screen.2e16d0ba.fill-735x490.jpg' }} // Replace with the URL of your image
        />
        <View style={styles.searchContainer}>
          <TextInput
            style={[styles.searchInput, { borderRadius: 20, backgroundColor: '#fff' }]}
            placeholder="Search by Name"
            
            onChangeText={setSearchText}
            placeholderTextColor="#666"
          />
          
<TouchableOpacity style={styles.searchButton} onPress={() => handleSearch(searchText)}>
            <Text style={styles.searchButtonText}>Search</Text>
          </TouchableOpacity>
          <FlatList
            data={searchResults}
            renderItem={({ item }) => (
              <View style={styles.searchResult}>
                
              </View>
            )}
            keyExtractor={(item) => item.TokenId.toString()} 
          />
        </View>
        <View style={styles.formContainer}>
          <View style={styles.formRow}>
            <View style={{ flex: 1 }}>
              <Text style={styles.label}>Patient Name:</Text>
              <Animated.View style={{ transform: [{ scale: animation }] }}>
                <TextInput
                  style={[styles.input, { borderRadius: 20, backgroundColor: '#fff' }]}
                  placeholderTextColor="#666"
                  value={patientName}
                  onChangeText={setPatientName}
                />
              </Animated.View>
            </View>
            <View style={{ flex: 1, marginLeft: 10 }}>
              <Text style={styles.label}>Age:</Text>
              <Animated.View style={{ transform: [{ scale: animation }] }}>
                <TextInput
                  style={[styles.input, { borderRadius: 20, backgroundColor: '#fff' }]}
                  placeholderTextColor="#666"
                  value={age}
                  onChangeText={setAge}
                />
              </Animated.View>
            </View>
          </View>
          <View style={styles.formRow}>
            <View style={{ flex: 1 }}>
              <Text style={styles.label}>Contact Detail:</Text>
              <Animated.View style={{ transform: [{ scale: animation }] }}>
                <TextInput
                  style={[styles.input, { borderRadius: 20, backgroundColor: '#fff' }]}
                  placeholderTextColor="#666"
                  value={contact}
                  onChangeText={setContact}
                />
              </Animated.View>
            </View>
            <View style={{ flex: 1, marginLeft: 10 }}>
              <Text style={styles.label}>Date of Birth:</Text>
              <Animated.View style={{ transform: [{ scale: animation }] }}>
                <TextInput
                  style={[styles.input, { borderRadius: 20, backgroundColor: '#fff' }]}
                  placeholderTextColor="#666"
                  value={dateOfBirth}
                  onChangeText={setDateOfBirth}
                />
              </Animated.View>
            </View>
          </View>
          <View style={styles.formRow}>
            <View style={{ flex: 1 }}>
              <Text style={styles.label}>Date:</Text>
              <Animated.View style={{ transform: [{ scale: animation }] }}>
                <TextInput
                  style={[styles.input, { borderRadius: 20, backgroundColor: '#fff' }]}
                  placeholderTextColor="#666"
                  value={date}
                  onChangeText={setDate}
                />
              </Animated.View>
            </View>
            <View style={{ flex: 1, marginLeft: 10 }}>
              <Text style={styles.label}>Time:</Text>
              <Animated.View style={{ transform: [{ scale: animation }] }}>
                <TextInput
                  style={[styles.input, { borderRadius: 20, backgroundColor: '#fff' }]}
                  placeholderTextColor="#666"
                  value={time}
                  onChangeText={setTime}
                />
              </Animated.View>
            </View>
          </View>
          <View style={styles.formRow}>
            <View style={{ flex: 1 }}>
              <Text style={styles.label}>Blood Pressure:</Text>
              <Animated.View style={{ transform: [{ scale: animation }] }}>
                <TextInput
                  style={[
                    styles.input,
                    {
                      borderRadius: 20,
                      backgroundColor: bloodPressureFocused ? '#d3d3d3' : '#fff',
                    },
                  ]}
                  onFocus={() => setBloodPressureFocused(true)}
                  onBlur={() => setBloodPressureFocused(false)}
                  placeholderTextColor="#666"
                  value={bloodPressure}
                  onChangeText={setBloodPressure}
                />
              </Animated.View>
            </View>
            <View style={{ flex: 1, marginLeft: 10 }}>
              <Text style={styles.label}>Pulse Rate:</Text>
              <Animated.View style={{ transform: [{ scale: animation }] }}>
                <TextInput
                  style={[
                    styles.input,
                    {
                      borderRadius: 20,
                      backgroundColor: pulseRateFocused ? '#d3d3d3' : '#fff',
                    },
                  ]}
                  onFocus={() => setPulseRateFocused(true)}
                  onBlur={() => setPulseRateFocused(false)}
                  placeholderTextColor="#666"
                  value={pulseRate}
                  onChangeText={setPulseRate}
                />
              </Animated.View>
            </View>
          </View>
          <View style={styles.formRow}>
            <View style={{ flex: 1 }}>
              <Text style={styles.label}>Diagnosed With:</Text>
              <Animated.View style={{ transform: [{ scale: animation }] }}>
                <TextInput
                  style={[
                    styles.input,
                    {
                      borderRadius: 20,
                      backgroundColor: diagnosedWithFocused ? '#d3d3d3' : '#fff',
                    },
                  ]}
                  onFocus={() => setDiagnosedWithFocused(true)}
                  onBlur={() => setDiagnosedWithFocused(false)}
                  placeholderTextColor="#666"
                  value={diagnosedWith}
                  onChangeText={setDiagnosedWith}
                />
              </Animated.View>
            </View>
            <View style={{ flex: 1, marginLeft: 10 }}>
              <Text style={styles.label}>Drug:</Text>
              <Animated.View style={{ transform: [{ scale: animation }] }}>
                <TextInput
                  style={[
                    styles.input,
                    {
                      borderRadius: 20,
                      backgroundColor: drugFocused ? '#d3d3d3' : '#fff',
                    },
                  ]}
                  onFocus={() => setDrugFocused(true)}
                  onBlur={() => setDrugFocused(false)}
                  placeholderTextColor="#666"
                  value={drug}
                  onChangeText={setDrug}
                />
              </Animated.View>
            </View>
          </View>
          <View style={styles.formRow}>
            <View style={{ flex: 1 }}>
              <Text style={styles.label}>Unit:</Text>
              <Animated.View style={{ transform: [{ scale: animation }] }}>
                <TextInput
                  style={[
                    styles.input,
                    {
                      borderRadius: 20,
                      backgroundColor: unitFocused ? '#d3d3d3' : '#fff',
                    },
                  ]}
                  onFocus={() => setUnitFocused(true)}
                  onBlur={() => setUnitFocused(false)}
                  placeholderTextColor="#666"
                  value={unit}
                  onChangeText={setUnit}
                />
              </Animated.View>
            </View>
            <View style={{ flex: 1, marginLeft: 10 }}>
              <Text style={styles.label}>Dosage:</Text>
              <Animated.View style={{ transform: [{ scale: animation }] }}>
                <TextInput
                  style={[
                    styles.input,
                    {
                      borderRadius: 20,
                      backgroundColor: dosageFocused ? '#d3d3d3' : '#fff',
                    },
                  ]}
                  onFocus={() => setDosageFocused(true)}
                  onBlur={() => setDosageFocused(false)}
                  placeholderTextColor="#666"
                  value={dosage}
                  onChangeText={setDosage}
                />
              </Animated.View>
            </View>
          </View>
          <View style={styles.formRow}>
            <Text style={styles.label}>Things to Follow:</Text>
            <Animated.View style={{ transform: [{ scale: animation }] }}>
              <TextInput
                style={[
                  styles.input,
                  {
                    borderRadius: 20,
                    backgroundColor: thingsToFollowFocused ? '#d3d3d3' : '#fff',
                  },
                ]}
                onFocus={() => setThingsToFollowFocused(true)}
                onBlur={() => setThingsToFollowFocused(false)}
                placeholderTextColor="#666"
                value={thingsToFollow}
                onChangeText={setThingsToFollow}
              />
            </Animated.View>
          </View>
          <View style={styles.formRow}>
            <Text style={styles.label}>Physician's Name:</Text>
            <Animated.View style={{ transform: [{ scale: animation }] }}>
              <TextInput
                style={[
                  styles.input,
                  {
                    borderRadius: 20,
                    backgroundColor: physiciansNameFocused ? '#d3d3d3' : '#fff',
                  },
                ]}
                onFocus={() => setPhysiciansNameFocused(true)}
                onBlur={() => setPhysiciansNameFocused(false)}
                placeholderTextColor="#666"
                value={physiciansName}
                onChangeText={setPhysiciansName}
              />
            </Animated.View>
          </View>
          <TouchableOpacity style={styles.submitButton} onPress={storeData}>
            <Text style={styles.submitButtonText}>Submit</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
            <Text style={styles.backButtonText}>Back</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  backgroundImage: {
    width: '100%',
    height: 200,
    borderRadius: 10,
    marginBottom: 20,
  },
  searchContainer: {
    marginBottom: 20,
  },
  searchInput: {
    padding: 10,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 20,
    backgroundColor: '#fff',
  },
  searchButton: {
    backgroundColor: '#007BFF',
    borderRadius: 20,
    padding: 10,
    alignItems: 'center',
    marginTop: 10,
  },
  searchButtonText: {
    color: '#fff',
    fontSize: 16,
  },
  searchResult: {
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
  },
  searchResultText: {
    fontSize: 16,
  },
  formContainer: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 10,
    elevation: 3,
  },
  formRow: {
    flexDirection: 'row',
    marginBottom: 10,
  },
  label: {
    fontSize: 16,
    marginBottom: 5,
  },
  input: {
    height: 40,
    borderColor: '#ddd',
    borderWidth: 1,
    padding: 10,
  },
  submitButton: {
    backgroundColor: '#28a745',
    borderRadius: 20,
    padding: 10,
    alignItems: 'center',
    marginTop: 10,
  },
  submitButtonText: {
    color: '#fff',
    fontSize: 16,
  },
  backButton: {
    backgroundColor: '#6c757d',
    borderRadius: 20,
    padding: 10,
    alignItems: 'center',
    marginTop: 10,
  },
  backButtonText: {
    color: '#fff',
    fontSize: 16,
  },
});

export default Write;
