import React from 'react';
import { SafeAreaView, View, TouchableOpacity, Text, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { Ionicons } from '@expo/vector-icons';
import Login from './Login';
import Dashboard from './Dashboard';
import Profile from './Profile';
import Search from './Search';
import Write from './Write';
import Medicine from './Medicine'; 

const Stack = createStackNavigator();
const Drawer = createDrawerNavigator();

const ProfileStack = () => (
  <Stack.Navigator>
    <Stack.Screen
      name="Doctor Profile"
      component={Profile}
      options={({ navigation }) => ({
        headerLeft: () => (
          <TouchableOpacity onPress={() => navigation.navigate('Dashboard')}>
            <Ionicons name="chevron-back" size={24} color="#black" />
          </TouchableOpacity>
        ),
        headerRight: () => (
          <View style={styles.headerRightContainer}>
            <TouchableOpacity onPress={() => {
              /* Handle notification press */
            }}>
              <Ionicons name="notifications" size={24} color="#007BFF" />
            </TouchableOpacity>
            <TouchableOpacity style={styles.button} onPress={() => {
              /* Handle button press */
            }}>
              <Text style={styles.buttonText}>Today</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => navigation.navigate('Login')}>
              <Ionicons name="log-out" size={24} color="#007BFF" />
            </TouchableOpacity>
          </View>
        ),
      })}
    />
  </Stack.Navigator>
);

const SearchStack = () => (
  <Stack.Navigator>
    <Stack.Screen
      name="Search"
      component={Search}
      options={({ navigation }) => ({
        headerLeft: () => (
          <TouchableOpacity onPress={() => navigation.navigate('Dashboard')}>
            <Ionicons name="chevron-back" size={24} color="black" />
          </TouchableOpacity>
        ),
        headerRight: () => (
          <View style={styles.headerRightContainer}>
            <TouchableOpacity onPress={() => {
              /* Handle notification press */
            }}>
              <Ionicons name="notifications" size={24} color="#007BFF" />
            </TouchableOpacity>
            <TouchableOpacity style={styles.button} onPress={() => {
              /* Handle button press */
            }}>
              <Text style={styles.buttonText}>Today</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => navigation.navigate('Login')}>
              <Ionicons name="log-out" size={24} color="#007BFF" />
            </TouchableOpacity>
          </View>
        ),
      })}
    />
  </Stack.Navigator>
);

const WriteStack = () => (
  <Stack.Navigator>
    <Stack.Screen
      name="Write"
      component={Write}
      options={({ navigation }) => ({
        headerLeft: () => (
          <TouchableOpacity onPress={() => navigation.navigate('Dashboard')}>
            <Ionicons name="chevron-back" size={24} color="black" />
          </TouchableOpacity>
        ),
        headerRight: () => (
          <View style={styles.headerRightContainer}>
            <TouchableOpacity onPress={() => {
              /* Handle notification press */
            }}>
              <Ionicons name="notifications" size={24} color="#007BFF" />
            </TouchableOpacity>
            <TouchableOpacity style={styles.button} onPress={() => {
              /* Handle button press */
            }}>
              <Text style={styles.buttonText}>Today</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => navigation.navigate('Login')}>
              <Ionicons name="log-out" size={24} color="#007BFF" />
            </TouchableOpacity>
          </View>
        ),
      })}
    />
  </Stack.Navigator>
);

const MedicineStack = () => (
  <Stack.Navigator>
    <Stack.Screen
      name="Medicine"
      component={Medicine}
      options={({ navigation }) => ({
        headerLeft: () => (
          <TouchableOpacity onPress={() => navigation.navigate('Dashboard')}>
            <Ionicons name="chevron-back" size={24} color="black" />
          </TouchableOpacity>
        ),
        headerRight: () => (
          <View style={styles.headerRightContainer}>
            <TouchableOpacity onPress={() => {
              /* Handle notification press */
            }}>
              <Ionicons name="notifications" size={24} color="#007BFF" />
            </TouchableOpacity>
            <TouchableOpacity style={styles.button} onPress={() => {
              /* Handle button press */
            }}>
              <Text style={styles.buttonText}>Today</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => navigation.navigate('Login')}>
              <Ionicons name="log-out" size={24} color="#007BFF" />
            </TouchableOpacity>
          </View>
        ),
      })}
    />
  </Stack.Navigator>
);

const DashboardDrawer = () => (
  <Drawer.Navigator initialRouteName="Dashboard">
    <Drawer.Screen
      name="Dashboard"
      component={Dashboard}
      options={({ navigation }) => ({
        headerRight: () => (
          <View style={styles.headerRightContainer}>
            <TouchableOpacity onPress={() => {
              /* Handle notification press */
            }}>
              <Ionicons name="notifications" size={24} color="#007BFF" />
            </TouchableOpacity>
            <TouchableOpacity style={styles.button} onPress={() => {
              /* Handle button press */
            }}>
              <Text style={styles.buttonText}>Today</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => navigation.navigate('Login')}>
              <Ionicons name="log-out" size={24} color="#007BFF" />
            </TouchableOpacity>
          </View>
        ),
        drawerIcon: ({ focused, size }) => (
          <Ionicons name="home" size={size} color={focused ? '#007aff' : '#ccc'} />
        ),
      })}
    />
    <Drawer.Screen
      name="Profile"
      component={ProfileStack}
      options={{
        headerShown: false,
        drawerIcon: () => <Ionicons name="person" size={24} color="black" />,
      }}
    />
    <Drawer.Screen
      name="Search"
      component={SearchStack}
      options={{
        headerShown: false,
        drawerIcon: () => <Ionicons name="search" size={24} color="black" />,
      }}
    />
    <Drawer.Screen
      name="Write"
      component={WriteStack}
      options={{
        headerShown: false,
        drawerIcon: () => <Ionicons name="create" size={24} color="black" />,
      }}
    />
    <Drawer.Screen
      name="Medicine"
      component={MedicineStack}
      options={{
        headerShown: false,
        drawerIcon: () => <Ionicons name="medkit" size={24} color="black" />,
      }}
    />
  </Drawer.Navigator>
);

const MainStackNavigator = () => (
  <Stack.Navigator>
    <Stack.Screen name="Login" component={Login} options={{ headerShown: false }} />
    <Stack.Screen name="Dashboard" component={DashboardDrawer} options={{ headerShown: false }} />
  </Stack.Navigator>
);

const App = () => (
  <SafeAreaView style={{ flex: 1 }}>
    <NavigationContainer>
      <MainStackNavigator />
    </NavigationContainer>
  </SafeAreaView>
);

const styles = StyleSheet.create({
  headerRightContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 10,
    color: '#007BFF',
  },
  button: {
    marginLeft: 10,
    paddingVertical: 5,
    paddingHorizontal: 10,
    backgroundColor: '#007BFF',
    borderRadius: 5,
  },
  buttonText: {
    color: '#FFF',
    fontSize: 16,
  },
});

export default App;