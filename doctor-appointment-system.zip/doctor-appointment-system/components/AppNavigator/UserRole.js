import React, { useState } from 'react';
import { View, Text, Platform, StyleSheet, ImageBackground, TouchableOpacity } from 'react-native';
import AppNavigator from '../Patient/Navigator/AppNavigator';
import DoctorAppNavigator from '../Doctor/DoctorAppNavigator';
import AdminDoctorNavigator from '../Admin/Naviagte/AppNavigator';
const backgroundImage = require('../../assets/pic6.jpg'); 
const StyledButton = ({ title, onPress }) => (
  <TouchableOpacity style={styles.button} onPress={onPress}>
    <Text style={styles.buttonText}>{title}</Text>
  </TouchableOpacity>
);


const UserTypeSelector = ({ setUserType }) => (
  <View style={styles.innerContainer}>
    <View style={styles.buttonContainer}>
      <StyledButton title="Patient" onPress={() => setUserType('patient')} />
      <StyledButton title="Doctor" onPress={() => setUserType('doctor')} />
      <StyledButton title="Admin" onPress={() => setUserType('admin')} />
    </View>
  </View>
);

export default function App() {
  const [userType, setUserType] = useState(null);

  if (userType === null) {
    
    return (
      <ImageBackground source={backgroundImage} style={styles.backgroundImage}>
        <UserTypeSelector setUserType={setUserType} />
      </ImageBackground>
    );
  }

  if (userType === 'admin') {
    
    if (Platform.OS === 'android' || Platform.OS === 'ios') {
      return (  <ImageBackground source={backgroundImage} style={styles.backgroundImage}>
          <View style={styles.innerContainer}>
            <Text style={styles.text}>The admin view is not available on this platform.</Text>
          </View>
        </ImageBackground>);
    } else {    
         return <AdminDoctorNavigator />;
    }
  }

  switch (userType) {
    case 'doctor':
      return <DoctorAppNavigator />;
    case 'patient':
      return <AppNavigator />;
    default:
      return (
        <ImageBackground source={backgroundImage} style={styles.backgroundImage}>
          <View style={styles.innerContainer}>
            <Text style={styles.text}>Invalid user type</Text>
          </View>
        </ImageBackground>
      );
  }
}

const styles = StyleSheet.create({
  backgroundImage: {
    flex: 1,
    height:900,
    resizeMode: 'cover', 
    justifyContent: 'center',
  },
  innerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
    backgroundColor: 'rgba(0, 0, 0, 0.4)', 
  },
  buttonContainer: {
    width: '50%',
  },
  button: {
    backgroundColor: '#007bff',
    padding: 10,
    borderRadius: 5,
    marginVertical: 8,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.5,
    shadowRadius: 5,
    elevation: 5,
  },
  buttonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
    textShadowColor: '#000', 
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 5,
  },
  text: {
    fontSize: 18,
    color: '#ffffff',
    textShadowColor: '#000',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 5,
  },
});
