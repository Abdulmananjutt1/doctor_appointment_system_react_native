import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Modal,
  Pressable,
  Animated,
  ImageBackground,
  Image,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const LoginScreen = ({ navigation }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showPopup, setShowPopup] = useState(false);
  const [fadeAnim] = useState(new Animated.Value(0));
  const [slideAnim] = useState(new Animated.Value(30));
  const [formHighlightAnim] = useState(new Animated.Value(0));
  const [inputHighlightAnim] = useState(new Animated.Value(0));
  const [focusedField, setFocusedField] = useState(null);
  const [titleColors] = useState([
    '#FF5733', '#FFBD33', '#DBFF33', '#75FF33', '#33FF57', '#33FFBD',
    '#33DBFF', '#3375FF', '#5733FF', '#BD33FF', '#FF33DB', '#FF3375',
  ]);
  const [currentTitleColor, setCurrentTitleColor] = useState(0);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  useEffect(() => {
    if (focusedField) {
      Animated.parallel([
        Animated.timing(formHighlightAnim, {
          toValue: 1,
          duration: 500,
          useNativeDriver: false,
        }).start(),
        Animated.timing(inputHighlightAnim, {
          toValue: 1,
          duration: 500,
          useNativeDriver: false,
        }).start(),
      ]);
    } else {
      Animated.parallel([
        Animated.timing(formHighlightAnim, {
          toValue: 0,
          duration: 500,
          useNativeDriver: false,
        }).start(),
        Animated.timing(inputHighlightAnim, {
          toValue: 0,
          duration: 500,
          useNativeDriver: false,
        }).start(),
      ]);
    }
  }, [focusedField]);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTitleColor((prev) => (prev + 1) % titleColors.length);
    }, 500); // Change color every 500ms
    return () => clearInterval(interval);
  }, [titleColors]);

  const handleLogin = async () => {
    console.log('Login button pressed');
    if (username === 'admin' && password === 'admin123') {
      await AsyncStorage.setItem('userToken', 'dummy-auth-token');
      console.log('Login successful, navigating to Dashboard');
      setUsername(''); 
      setPassword(''); 
      navigation.navigate('Dashboard');
    } else {
      console.log('Login failed, showing popup');
      setShowPopup(true);
    }
  };

  const handleClosePopup = () => {
    setShowPopup(false);
  };

  const renderTitle = () => {
    return "Login Form".split('').map((char, index) => (
      <Text
        key={index}
        style={[
          styles.titleChar,
          { color: titleColors[(currentTitleColor + index) % titleColors.length] },
        ]}
      >
        {char}
      </Text>
    ));
  };

  return (
    <ImageBackground
      source={{ uri: 'https://ddi-dev.com/uploads/medical-appointment-system.jpg' }}
      style={styles.backgroundImage}
    >
      <View style={styles.container}>
        <Animated.View
          style={[
            styles.formContainer,
            {
              borderColor: formHighlightAnim.interpolate({
                inputRange: [0, 1],
                outputRange: ['#ccc', '#00BFFF'],
              }),
              shadowColor: formHighlightAnim.interpolate({
                inputRange: [0, 1],
                outputRange: ['#333', '#00BFFF'],
              }),
              shadowOpacity: formHighlightAnim.interpolate({
                inputRange: [0, 1],
                outputRange: [0.2, 0.8],
              }),
              shadowRadius: formHighlightAnim.interpolate({
                inputRange: [0, 1],
                outputRange: [10, 20],
              }),
            },
          ]}
        >
          <View style={styles.titleContainer}>
            {renderTitle()}
          </View>
          <View style={styles.line} />
          <View style={styles.formGroup}>
            <Text style={styles.label}>Username</Text>
            <Animated.View
              style={[
                styles.inputWrapper,
                {
                  borderColor: inputHighlightAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: ['#ccc', '#00BFFF'], 
                  }),
                  shadowColor: inputHighlightAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: ['#333', '#00BFFF'], 
                  }),
                  shadowOpacity: inputHighlightAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [0.1, 0.5],
                  }),
                  shadowRadius: inputHighlightAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [5, 10],
                  }),
                },
              ]}
            >
              <TextInput
                style={styles.input}
                placeholder="Enter your username"
                placeholderTextColor="#aaa"
                value={username}
                onChangeText={setUsername}
                onFocus={() => setFocusedField('username')}
                onBlur={() => setFocusedField(null)}
              />
            </Animated.View>
          </View>
          <View style={styles.formGroup}>
            <Text style={styles.label}>Password</Text>
            <Animated.View
              style={[
                styles.inputWrapper,
                {
                  borderColor: inputHighlightAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: ['#ccc', '#00BFFF'], 
                  }),
                  shadowColor: inputHighlightAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: ['#333', '#00BFFF'], 
                  }),
                  shadowOpacity: inputHighlightAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [0.1, 0.45],
                  }),
                  shadowRadius: inputHighlightAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [5, 10],
                  }),
                },
              ]}
            >
              <TextInput
                style={styles.input}
                placeholder="Enter your password"
                placeholderTextColor="#aaa"
                value={password}
                onChangeText={setPassword}
                secureTextEntry={!showPassword}
                onFocus={() => setFocusedField('password')}
                onBlur={() => setFocusedField(null)}
              />
              <TouchableOpacity
                style={styles.eyeIcon}
                onPress={() => setShowPassword(!showPassword)}
              >
                <Image
                  source={{
                    uri: showPassword
                      ? 'https://cdn-icons-png.flaticon.com/512/4660/4660386.png' 
                      : 'https://cdn-icons-png.flaticon.com/512/4660/4660344.png', 
                  }}
                  style={styles.eyeIconImage}
                />
              </TouchableOpacity>
            </Animated.View>
          </View>
          <View style={styles.buttonContainer}>
            <TouchableOpacity onPress={handleLogin} style={styles.button}>
              <Text style={styles.buttonText}>Login</Text>
            </TouchableOpacity>
          </View>
        </Animated.View>
        <Modal
          transparent={true}
          visible={showPopup}
          animationType="fade"
          onRequestClose={handleClosePopup}
        >
          <View style={styles.modalBackground}>
            <View style={styles.modalContainer}>
              <Text style={styles.modalText}>Login failed. Please try again.</Text>
              <Pressable style={styles.modalButton} onPress={handleClosePopup}>
                <Text style={styles.modalButtonText}>OK</Text>
              </Pressable>
            </View>
          </View>
        </Modal>
      </View>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  backgroundImage: {
    flex: 1,
    resizeMode: 'cover',
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  backButton: {
    position: 'absolute',
    top: 20,
    left: 20,
    backgroundColor: '#00BFFF',
    padding: 10,
    borderRadius: 8,
  },
  backButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  formContainer: {
    width: '90%',
    maxWidth: 400,
    padding: 20,
    backgroundColor: '#fff',
    borderRadius: 12,
    elevation: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    borderWidth: 1,
  },
  titleContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginBottom: 16,
  },
  titleChar: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  line: {
    height: 2,
    backgroundColor: '#ccc',
    marginVertical: 16,
  },
  formGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: 16,
    marginBottom: 4,
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 20,
    paddingHorizontal: 8,
    paddingVertical: 4,
    backgroundColor: '#fff',
    elevation: 4,
    shadowOffset: { width: 0, height: 2 },
  },
  input: {
    flex: 1,
    height: 40,
    textAlign: 'center',
    fontSize: 16,
  },
  eyeIcon: {
    marginLeft: 8,
  },
  eyeIconImage: {
    width: 24,
    height: 24,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
  },
  button: {
    width: '35%',
    backgroundColor: '#00BFFF',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  buttonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#fff',
  },
  modalBackground: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContainer: {
    width: 300,
    padding: 20,
    backgroundColor: '#fff',
    borderRadius: 8,
    alignItems: 'center',
  },
  modalText: {
    fontSize: 18,
    marginBottom: 16,
  },
  modalButton: {
    backgroundColor: '#00BFFF',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
  },
  modalButtonText: {
    color: '#fff',
    fontSize: 16,
  },
});

export default LoginScreen;
