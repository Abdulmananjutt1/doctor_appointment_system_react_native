import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, Image, TouchableOpacity, Modal, Pressable, ImageBackground } from 'react-native';

const ViewClinic = () => {
  const [clinics, setClinics] = useState([]);
  const [error, setError] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);
  const [modalImage, setModalImage] = useState(null);

  useEffect(() => {
    const fetchClinics = async () => {
      try {
        const response = await fetch('https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Clinics.json');
        if (!response.ok) {
          throw new Error('Failed to fetch clinics.');
        }
        const data = await response.json();
        const clinicsArray = Object.keys(data).map(key => ({
          id: key,
          ...data[key]
        }));
        setClinics(clinicsArray);
      } catch (error) {
        setError(error.message);
      }
    };

    fetchClinics();
  }, []);

  const renderClinicItem = ({ item }) => (
    <View style={styles.clinicItem}>
      <TouchableOpacity
        style={styles.imageContainer}
        onPress={() => {
          setModalImage(item.Image);
          setModalVisible(true);
        }}
      >
        {item.Image ? (
          <Image source={{ uri: item.Image }} style={styles.image} />
        ) : (
          <View style={styles.imagePlaceholder} />
        )}
      </TouchableOpacity>
      <View style={styles.detailsContainer}>
        <View style={styles.detailItem}>
          <Text style={styles.label}>Name:</Text>
          <Text style={styles.value}>{item.Name}</Text>
        </View>
        <View style={styles.detailItem}>
          <Text style={styles.label}>Location:</Text>
          <Text style={styles.value}>{item.Location}</Text>
        </View>
        <View style={styles.detailItem}>
          <Text style={styles.label}>Contact:</Text>
          <Text style={styles.value}>{item.Contact}</Text>
        </View>
      </View>
    </View>
  );

  return (
    <View style={styles.contentContainer}>
      <ImageBackground
        source={{ uri: 'https://engage.healthtrustjobs.com/hubfs/Images/Blog/MCCHildrens-exterior.jpg' }}
        style={styles.backgroundImage}
      >
        <View style={styles.div}>
          <Text style={styles.title}>Clinic Information</Text>
          {error ? (
            <Text style={styles.error}>{error}</Text>
          ) : (
            <FlatList
              data={clinics}
              renderItem={renderClinicItem}
              keyExtractor={item => item.id}
            />
          )}
          <Modal
            transparent={true}
            visible={modalVisible}
            onRequestClose={() => setModalVisible(false)}
          >
            <View style={styles.modalBackground}>
              <View style={styles.modalContainer}>
                {modalImage && (
                  <Image source={{ uri: modalImage }} style={styles.modalImage} />
                )}
                <Pressable
                  style={styles.buttonClose}
                  onPress={() => setModalVisible(false)}
                >
                  <Text style={styles.textStyle}>Close</Text>
                </Pressable>
              </View>
            </View>
          </Modal>
        </View>
      </ImageBackground>
    </View>
  );
};

const styles = StyleSheet.create({
  backgroundImage: {
height:630,
  },
  contentContainer: {
    flex: 1,
    padding: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 16,
    textAlign: 'center',
    color: '#333',
  },
  error: {
    color: 'red',
    textAlign: 'center',
    marginBottom: 16,
  },
  div: {
    height: 400,
    width: 800,
    padding: 16,
    borderRadius: 8,
    alignSelf: 'center',
    marginTop: 30,
    backgroundColor: '#f0f0f0',
    borderBlockColor:'#007bff',
    borderWidth:4,
    borderEndColor:'#ffc107'
  },
  clinicItem: {
    marginBottom: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
    paddingBottom: 10,
  },
  image: {
    width: 100,
    height: 100,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: '#ddd',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 4,
    elevation: 5,
  },
  imageContainer: {
    marginBottom: 10,
    alignItems: 'center',
  },
  detailsContainer: {
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 5,
  },
  detailItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
    paddingVertical: 10,
  },
  label: {
    fontWeight: 'bold',
    fontSize: 16,
  },
  value: {
    fontSize: 16,
    color: '#555',
  },
  buttonClose: {
    backgroundColor: '#007bff',
    borderRadius: 4,
    padding: 10,
    marginTop: 20,
  },
  textStyle: {
    color: '#fff',
    textAlign: 'center',
  },
  modalBackground: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContainer: {
    width: '80%',
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 10,
    alignItems: 'center',
  },
  modalImage: {
    width: '100%',
    height: 400,
    resizeMode: 'contain',
  },
});

export default ViewClinic;
