import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, Image, TouchableOpacity, Modal, Pressable, TextInput, ImageBackground } from 'react-native';

const ViewClinic = () => {
  const [clinics, setClinics] = useState([]);
  const [error, setError] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);
  const [modalImage, setModalImage] = useState(null);
  const [editingClinic, setEditingClinic] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [confirmCancelVisible, setConfirmCancelVisible] = useState(false);
  const [successVisible, setSuccessVisible] = useState(false);
  const [editedClinic, setEditedClinic] = useState({
    Name: '',
    Location: '',
    Contact: '',
    Image: ''
  });

  useEffect(() => {
    const fetchClinics = async () => {
      try {
        const response = await fetch('https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Clinics.json');
        if (!response.ok) {
          throw new Error('Failed to fetch clinics.');
        }
        const data = await response.json();
        const clinicsArray = Object.keys(data).map(key => ({
          id: key,
          ...data[key]
        }));
        setClinics(clinicsArray);
      } catch (error) {
        setError(error.message);
      }
    };

    fetchClinics();
  }, []);

  const handleEdit = (clinic) => {
    setEditingClinic(clinic);
    setEditedClinic(clinic);
    setIsEditing(true);
  };

  const handleSave = async () => {
    try {
      const response = await fetch(`https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Clinics/${editingClinic.id}.json`, {
        method: 'PUT',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(editedClinic),
      });

      if (response.ok) {
        setClinics(clinics.map(clinic => clinic.id === editingClinic.id ? editedClinic : clinic));
        setIsEditing(false);
        setSuccessVisible(true);
      } else {
        setError('Failed to update clinic. Please try again.');
      }
    } catch (error) {
      setError('An error occurred. Please try again.');
    }
  };

  const handleCancel = () => {
    if (isEditing) {
      setConfirmCancelVisible(true);
    } else {
      setEditingClinic(null);
      setEditedClinic({
        Name: '',
        Location: '',
        Contact: '',
        Image: ''
      });
      setIsEditing(false);
    }
  };

  const handleConfirmCancel = (confirm) => {
    if (confirm) {
      setEditingClinic(null);
      setEditedClinic({
        Name: '',
        Location: '',
        Contact: '',
        Image: ''
      });
    }
    setConfirmCancelVisible(false);
    setIsEditing(false);
  };

  const renderClinicItem = ({ item }) => (
    <View style={styles.clinicItem}>
      <TouchableOpacity
        style={styles.imageContainer}
        onPress={() => {
          setModalImage(item.Image);
          setModalVisible(true);
        }}
      >
        {item.Image ? (
          <Image source={{ uri: item.Image }} style={styles.image} />
        ) : (
          <View style={styles.imagePlaceholder} />
        )}
      </TouchableOpacity>
      <View style={styles.detailsContainer}>
        {isEditing && editingClinic.id === item.id ? (
          <View>
            <TextInput
              style={styles.input}
              value={editedClinic.Name}
              onChangeText={(text) => setEditedClinic({ ...editedClinic, Name: text })}
            />
            <TextInput
              style={styles.input}
              value={editedClinic.Location}
              onChangeText={(text) => setEditedClinic({ ...editedClinic, Location: text })}
            />
            <TextInput
              style={styles.input}
              value={editedClinic.Contact}
              onChangeText={(text) => setEditedClinic({ ...editedClinic, Contact: text })}
              keyboardType="numeric"
            />
            <TouchableOpacity onPress={handleSave} style={styles.button}>
              <Text style={styles.textStyle}>Save</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={handleCancel} style={styles.button}>
              <Text style={styles.textStyle}>Cancel</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <View>
            <View style={styles.detailItem}>
              <Text style={styles.label}>Name:</Text>
              <Text style={styles.value}>{item.Name}</Text>
            </View>
            <View style={styles.detailItem}>
              <Text style={styles.label}>Location:</Text>
              <Text style={styles.value}>{item.Location}</Text>
            </View>
            <View style={styles.detailItem}>
              <Text style={styles.label}>Contact:</Text>
              <Text style={styles.value}>{item.Contact}</Text>
            </View>
            <TouchableOpacity onPress={() => handleEdit(item)} style={styles.button}>
              <Text style={styles.textStyle}>Edit</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>
    </View>
  );

  return (
    <View style={styles.contentContainer}>
      <ImageBackground
        source={{ uri: 'https://engage.healthtrustjobs.com/hubfs/Images/Blog/MCCHildrens-exterior.jpg' }}
        style={styles.backgroundImage}
      >
        <View style={styles.div}>
          <Text style={styles.title}>Clinic Information</Text>
          {error ? (
            <Text style={styles.error}>{error}</Text>
          ) : (
            <FlatList
              data={clinics}
              renderItem={renderClinicItem}
              keyExtractor={item => item.id}
            />
          )}
          <Modal
            transparent={true}
            visible={modalVisible}
            onRequestClose={() => setModalVisible(false)}
          >
            <View style={styles.modalBackground}>
              <View style={styles.modalContainer}>
                {modalImage && (
                  <Image source={{ uri: modalImage }} style={styles.modalImage} />
                )}
                <Pressable
                  style={styles.buttonClose}
                  onPress={() => setModalVisible(false)}
                >
                  <Text style={styles.textStyle}>Close</Text>
                </Pressable>
              </View>
            </View>
          </Modal>
          <Modal
            transparent={true}
            visible={confirmCancelVisible}
            onRequestClose={() => setConfirmCancelVisible(false)}
          >
            <View style={styles.modalBackground}>
              <View style={styles.modalContainer}>
                <Text style={styles.modalTitle}>Are you sure you want to cancel?</Text>
                <View style={styles.modalButtonContainer}>
                  <Pressable
                    style={[styles.buttonClose, { backgroundColor: '#007bff' }]}
                    onPress={() => handleConfirmCancel(true)}
                  >
                    <Text style={styles.textStyle}>Yes</Text>
                  </Pressable>
                  <Pressable
                    style={[styles.buttonClose, { backgroundColor: '#dc3545' }]}
                    onPress={() => handleConfirmCancel(false)}
                  >
                    <Text style={styles.textStyle}>No</Text>
                  </Pressable>
                </View>
              </View>
            </View>
          </Modal>
          <Modal
            transparent={true}
            visible={successVisible}
            onRequestClose={() => setSuccessVisible(false)}
          >
            <View style={styles.modalBackground}>
              <View style={styles.modalContainer}>
                <Text style={styles.modalTitle}>Clinic updated successfully!</Text>
                <Pressable
                  style={[styles.buttonClose, { backgroundColor: '#28a745' }]}
                  onPress={() => setSuccessVisible(false)}
                >
                  <Text style={styles.textStyle}>OK</Text>
                </Pressable>
              </View>
            </View>
          </Modal>
        </View>
      </ImageBackground>
    </View>
  );
};

const styles = StyleSheet.create({
  backgroundImage: {
height:630,
  },
  contentContainer: {
    flex: 1,
    padding: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 16,
    textAlign: 'center',
    color: '#333',
  },
  error: {
    color: 'red',
    textAlign: 'center',
    marginBottom: 16,
  },
  div: {
    height: 450,
    width: 800,
    padding: 16,
    borderRadius: 8,
    alignSelf: 'center', // Center the div horizontally
    marginTop: 30,
    backgroundColor: '#f0f0f0',
    borderBlockColor:'#007bff',
    borderWidth:4,
    borderEndColor:'#ffc107'
  },
  clinicItem: {
    marginBottom: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
    paddingBottom: 10,
  },
  image: {
    width: 100,
    height: 100,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: '#ddd',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 4,
    elevation: 5,
  },
  imageContainer: {
    marginBottom: 10,
    alignItems: 'center',
  },
  detailsContainer: {
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 5,
  },
  detailItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
    paddingVertical: 10,
  },
  label: {
    fontWeight: 'bold',
    fontSize: 16,
  },
  value: {
    fontSize: 16,
    color: '#555',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 5,
    padding: 8,
    marginBottom: 10,
    backgroundColor: '#fff',
  },
  button: {
    backgroundColor: '#007bff',
    borderRadius: 5,
    padding: 10,
    marginVertical: 5,
    alignItems: 'center',
  },
  buttonClose: {
    backgroundColor: '#007bff',
    borderRadius: 4,
    padding: 10,
    marginTop: 20,
  },
  textStyle: {
    color: '#fff',
    textAlign: 'center',
  },
  modalBackground: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContainer: {
    width: '80%',
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 10,
    alignItems: 'center',
  },
  modalImage: {
    width: '100%',
    height: 400,
    resizeMode: 'contain',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  modalButtonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
  },
});

export default ViewClinic;
