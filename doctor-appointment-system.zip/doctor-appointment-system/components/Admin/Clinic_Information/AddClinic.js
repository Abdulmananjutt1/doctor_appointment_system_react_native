import React, { useState, useEffect, useRef } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Modal, Pressable, Image, Animated, ImageBackground } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import Ionicons from 'react-native-vector-icons/Ionicons';

const AddClinic = () => {
  const [clinicName, setClinicName] = useState('');
  const [clinicLocation, setClinicLocation] = useState('');
  const [clinicContact, setClinicContact] = useState('');
  const [clinicImage, setClinicImage] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);
  const [modalMessage, setModalMessage] = useState('');
  const [modalImage, setModalImage] = useState(null);
  const [clinicExists, setClinicExists] = useState(false); // State to track if clinic exists
  const [isHovered, setIsHovered] = useState(false); // State to track hover effect

  // Color animation for the background
  const colorAnim = useRef(new Animated.Value(0)).current;
  const colorArray = ['#d3d3d3', '#a9a9a9', '#696969', '#2f4f4f']; // Light to dark shades of gray

  useEffect(() => {
    const colorAnimation = Animated.loop(
      Animated.sequence([
        Animated.timing(colorAnim, {
          toValue: colorArray.length - 1,
          duration: 10000,
          useNativeDriver: false,
        }),
        Animated.timing(colorAnim, {
          toValue: 0,
          duration: 0,
          useNativeDriver: false,
        }),
      ])
    );
    colorAnimation.start();

    return () => {
      colorAnimation.stop();
    };
  }, [colorAnim]);

  const interpolatedColor = colorAnim.interpolate({
    inputRange: colorArray.map((_, i) => i),
    outputRange: colorArray,
  });

  // Check if clinic exists
  useEffect(() => {
    const checkClinicExists = async () => {
      try {
        const response = await fetch('https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Clinics.json');
        const data = await response.json();
        if (data) {
          // Check if any clinic data exists
          const clinicData = Object.values(data);
          if (clinicData.length > 0) {
            setClinicExists(true); // Clinic information already exists
            setModalMessage('Clinic information has already been added.');
            setModalImage(null);
            setModalVisible(true);
          }
        }
      } catch (error) {
        setModalMessage('An error occurred while checking clinic information.');
        setModalImage(null);
        setModalVisible(true);
      }
    };

    checkClinicExists();
  }, []);

  const pickImage = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });
    if (!result.canceled) {
      setClinicImage(result.assets[0].uri);
    }
  };

  const handleAddClinic = async () => {
    if (clinicExists) {
      setModalMessage('Clinic information has already been added.');
      setModalImage(null);
      setModalVisible(true);
      return;
    }

    if (!clinicName || !clinicLocation || !clinicContact || !clinicImage) {
      setModalMessage('Please fill all fields and upload an image.');
      setModalImage(null);
      setModalVisible(true);
      return;
    }

    try {
      const response = await fetch('https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Clinics.json', {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          Name: clinicName,
          Location: clinicLocation,
          Contact: clinicContact,
          Image: clinicImage,
        }),
      });

      if (response.ok) {
        setModalImage({ uri: 'https://openclipart.org/image/2400px/svg_to_png/167549/Kliponious-green-tick.png' });
        setModalMessage('Clinic added successfully!');
        setClinicName('');
        setClinicLocation('');
        setClinicContact('');
        setClinicImage(null);
      } else {
        setModalMessage('Failed to add clinic. Please try again.');
        setModalImage(null);
      }
    } catch (error) {
      setModalMessage('An error occurred. Please try again.');
      setModalImage(null);
    } finally {
      setModalVisible(true);
    }
  };

  return (
    <ImageBackground
      source={{ uri: 'https://engage.healthtrustjobs.com/hubfs/Images/Blog/MCCHildrens-exterior.jpg' }}
      style={styles.backgroundImage}
    >
      <View style={styles.container}>
        <Animated.View style={[styles.div, { backgroundColor: interpolatedColor }]}>
          <Text style={styles.title}>
            {clinicExists ? 'Clinic Information Already Added' : 'Add New Clinic'}
          </Text>
          {!clinicExists && (
            <>
              <TouchableOpacity
                onPress={pickImage}
                style={[styles.imagePicker, !clinicImage && styles.imagePickerError]}
              >
                {clinicImage ? (
                  <Image source={{ uri: clinicImage }} style={styles.image} />
                ) : (
                  <Ionicons name="image-outline" size={40} color="#fff" />
                )}
              </TouchableOpacity>
              <TextInput
                style={styles.input}
                placeholder="Clinic Name"
                value={clinicName}
                onChangeText={setClinicName}
              />
              <TextInput
                style={styles.input}
                placeholder="Location"
                value={clinicLocation}
                onChangeText={setClinicLocation}
              />
              <TextInput
                style={styles.input}
                placeholder="Contact"
                value={clinicContact}
                onChangeText={setClinicContact}
                keyboardType="numeric"
              />
              <TouchableOpacity
                style={[styles.button, { width: '35%', alignSelf: 'center', backgroundColor: isHovered ? '#0056b3' : '#007bff' }]} // Apply hover color
                onPressIn={() => setIsHovered(true)} // Set hover state
                onPressOut={() => setIsHovered(false)} // Reset hover state
                onPress={handleAddClinic}
              >
                <Text style={styles.textStyle}>Add Clinic</Text>
              </TouchableOpacity>
            </>
          )}
        </Animated.View>
        <Modal
          transparent={true}
          visible={modalVisible}
          onRequestClose={() => setModalVisible(false)}
        >
          <View style={styles.modalContainer}>
            <View style={styles.modalContent}>
              <Text style={styles.modalTitle}>{modalMessage}</Text>
              {modalImage ? <Image source={modalImage} style={styles.modalImage} /> : null}
              <Pressable
                style={[styles.button, styles.buttonClose]}
                onPress={() => setModalVisible(false)}
              >
                <Text style={styles.textStyle}>OK</Text>
              </Pressable>
            </View>
          </View>
        </Modal>
      </View>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  backgroundImage: {
flex:1,

  },
  container: {
    flex: 1,
    padding: 16,
  },
  div: {
    height: 450,
    width: 350,
    padding: 16,
    borderRadius: 8,
    alignSelf: 'center', // Center the div horizontally
    marginTop: 30,
    backgroundColor: '#f0f0f0',
    borderBlockColor:'#007bff',
    borderWidth:4,
    borderEndColor:'#ffc107'
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginVertical: 16,
    textAlign: 'center',
    color: '#f0f0f0', // Light white text color
  },
  input: {
    height: 40,
    borderColor: '#a9a9a9', // Dark gray border color
    borderWidth: 1,
    marginBottom: 12,
    paddingHorizontal: 8,
    borderRadius: 4,
    backgroundColor: '#f5f5f5', // Light white background color for input
    color: '#333', // Dark text color for input
  },
  imagePicker: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 10,
    borderRadius: 50,
    borderWidth: 1,
    borderColor: '#a9a9a9', // Dark gray border color
    marginBottom: 15,
    width: 100,
    height: 100,
    overflow: 'hidden',
    alignSelf: 'center',
  },
  imagePickerError: {
    borderColor: '#f00', // Red border color for error
  },
  image: {
    width: '100%',
    height: '100%',
    borderRadius: 50,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)', 
  },
  modalContent: {
    backgroundColor: '#333', // Dark gray background color for modal
    padding: 20,
    borderRadius: 8,
    width: '80%',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 5,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#f0f0f0', // Light white text color for modal
  },
  modalImage: {
    width: 100,
    height: 100,
    marginVertical: 10,
    borderRadius: 1,
  },
  button: {
    borderRadius: 4,
    padding: 10,
    alignItems: 'center',
    marginTop: 20,
  },
  buttonClose: {
    backgroundColor: '#007bff', // Blue background color for button
  },
  textStyle: {
    color: '#f0f0f0', // Light white text color for button
    textAlign: 'center',
  },
});

export default AddClinic;
