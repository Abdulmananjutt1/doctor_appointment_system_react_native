import React, { useState, useEffect, useRef } from 'react';
import { View, Text, TextInput, Button, FlatList, StyleSheet, Image, ScrollView, Animated, TouchableOpacity, Modal, TouchableWithoutFeedback } from 'react-native';

const ViewDoctor = () => {
  const [doctors, setDoctors] = useState([]);
  const [searchId, setSearchId] = useState('');
  const [selectedDoctor, setSelectedDoctor] = useState(null);
  const [error, setError] = useState('');
  const [viewAll, setViewAll] = useState(true);
  const [highlightedRow, setHighlightedRow] = useState(null);
  const [isModalVisible, setIsModalVisible] = useState(false); // Modal visibility state

  // Animation
  const fadeAnim = useRef(new Animated.Value(1)).current;
  const scaleAnim = useRef(new Animated.Value(1)).current;
  const imageScaleAnim = useRef(new Animated.Value(1)).current; // Animation for image

  useEffect(() => {
    fetchAllDoctors();
  }, []);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 500,
      useNativeDriver: true,
    }).start();
  }, [doctors, selectedDoctor, error, viewAll]);

  useEffect(() => {
    // Image scaling animation
    Animated.loop(
      Animated.sequence([
        Animated.timing(imageScaleAnim, {
          toValue: 1.1,
          duration: 1500,
          useNativeDriver: true,
        }),
        Animated.timing(imageScaleAnim, {
          toValue: 1,
          duration: 1500,
          useNativeDriver: true,
        }),
      ])
    ).start();
  }, []);

  const fetchAllDoctors = async () => {
    try {
      const response = await fetch('https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Doctors.json');
      const data = await response.json();
      console.log('Fetched doctors data:', data); // Debugging line

      // Ensure data structure is an array of objects
      const doctorsList = Object.keys(data).map(key => ({
        ID: key,
        ...data[key],
      }));

      // Remove duplicate IDs
      const uniqueDoctors = Array.from(new Set(doctorsList.map(doctor => doctor.ID)))
        .map(id => doctorsList.find(doctor => doctor.ID === id));

      console.log('Processed doctors list:', uniqueDoctors); // Debugging line
      setDoctors(uniqueDoctors);
    } catch (error) {
      setError('Failed to fetch doctors. Please try again.');
    }
  };

  const handleSearch = () => {
    const doctor = doctors.find(doc => doc.ID === searchId);
    if (doctor) {
      setSelectedDoctor(doctor);
      setError('');
    } else {
      setSelectedDoctor(null);
      setError('Doctor not found. Please check the ID.');
    }
  };

  const handleRowPress = (id) => {
    setHighlightedRow(id);
    Animated.timing(scaleAnim, {
      toValue: 1.05,
      duration: 200,
      useNativeDriver: true,
    }).start(() => {
      Animated.timing(scaleAnim, {
        toValue: 1,
        duration: 200,
        useNativeDriver: true,
      }).start();
    });
  };

  const openModal = () => {
    setIsModalVisible(true);
  };

  const closeModal = () => {
    setIsModalVisible(false);
  };

  const renderDoctorRow = ({ item }) => {
    const isHighlighted = highlightedRow === item.ID;
    return (
      <TouchableOpacity onPress={() => handleRowPress(item.ID)}>
        <Animated.View style={[
          styles.row,
          { opacity: fadeAnim, transform: [{ scale: isHighlighted ? scaleAnim : 1 }] },
          isHighlighted ? styles.highlightedRow : null
        ]}>
          <Text style={styles.cell}>{item.ID}</Text>
          <Text style={styles.cell}>{item.Name}</Text>
          <Text style={styles.cell}>{item.Specialization}</Text>
          <Text style={styles.cell}>{item.Contact}</Text>
          <Text style={styles.cell}>{item.Fees}</Text>
          <Text style={styles.cell}>{item.Email}</Text>
          <Text style={styles.cell}>{item.Password}</Text>
        </Animated.View>
      </TouchableOpacity>
    );
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>View Doctor Profiles</Text>
      <View style={styles.switchContainer}>
        <Button
          title="View All Doctors"
          onPress={() => setViewAll(true)}
          color={viewAll ? '#007bff' : '#ccc'}
        />
        <Button
          title="Search Doctor by ID"
          onPress={() => setViewAll(false)}
          color={!viewAll ? '#007bff' : '#ccc'}
        />
      </View>

      {!viewAll && (
        <>
          <TextInput
            style={styles.input}
            placeholder="Enter Doctor ID"
            value={searchId}
            onChangeText={setSearchId}
          />
          <Button title="Search" onPress={handleSearch} />
        </>
      )}

      {error ? <Text style={styles.error}>{error}</Text> : null}

      {selectedDoctor && !viewAll ? (
        <ScrollView style={styles.container}>
          <View style={styles.imageContainer}>
            <TouchableOpacity onPress={openModal}>
              <Animated.Image
                source={{ uri: selectedDoctor.Image }}
                style={[styles.image, { transform: [{ scale: imageScaleAnim }] }]}
              />
            </TouchableOpacity>
          </View>
          <View style={styles.detailsContainer}>
            <View style={styles.detailItem}>
              <Text style={styles.label}>Name</Text>
              <Text style={styles.value}>{selectedDoctor.Name}</Text>
            </View>
            <View style={styles.detailItem}>
              <Text style={styles.label}>ID</Text>
              <Text style={styles.value}>{selectedDoctor.ID}</Text>
            </View>
            <View style={styles.detailItem}>
              <Text style={styles.label}>Specialization</Text>
              <Text style={styles.value}>{selectedDoctor.Specialization}</Text>
            </View>
            <View style={styles.detailItem}>
              <Text style={styles.label}>Contact</Text>
              <Text style={styles.value}>{selectedDoctor.Contact}</Text>
            </View>
            <View style={styles.detailItem}>
              <Text style={styles.label}>Fees</Text>
              <Text style={styles.value}>{selectedDoctor.Fees}</Text>
            </View>
            <View style={styles.detailItem}>
              <Text style={styles.label}>Email</Text>
              <Text style={styles.value}>{selectedDoctor.Email}</Text>
            </View>
            <View style={styles.detailItem}>
              <Text style={styles.label}>Password</Text>
              <Text style={styles.value}>{selectedDoctor.Password}</Text>
            </View>
          </View>
        </ScrollView>
      ) : null}

      {viewAll && (
        <ScrollView horizontal>
          <View style={styles.table}>
            <View style={styles.headerRow}>
              <Text style={styles.headerCell}>ID</Text>
              <Text style={styles.headerCell}>Name</Text>
              <Text style={styles.headerCell}>Specialization</Text>
              <Text style={styles.headerCell}>Contact</Text>
              <Text style={styles.headerCell}>Fees</Text>
              <Text style={styles.headerCell}>Email</Text>
              <Text style={styles.headerCell}>Password</Text>
            </View>
            <FlatList
              data={doctors}
              keyExtractor={(item) => item.ID ? item.ID.toString() : 'unknown'}
              renderItem={renderDoctorRow}
            />
          </View>
        </ScrollView>
      )}

      <Modal visible={isModalVisible} transparent={true} animationType="fade">
        <TouchableWithoutFeedback onPress={closeModal}>
          <View style={styles.modalBackground}>
            <View style={styles.modalContainer}>
              {selectedDoctor && (
                <Image
                  source={{ uri: selectedDoctor.Image }}
                  style={styles.modalImage}
                />
              )}
            </View>
          </View>
        </TouchableWithoutFeedback>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 16,
    textAlign: 'center',
  },
  switchContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginBottom: 16,
  },
  input: {
    height: 40,
    borderColor: '#ddd',
    borderWidth: 1,
    marginBottom: 12,
    paddingHorizontal: 8,
    borderRadius: 4,
  },
  error: {
    color: 'red',
    textAlign: 'center',
    marginBottom: 16,
  },
  image: {
    width: 100,
    height: 100,
    borderRadius: 50,
    borderWidth: 3, // Add border width
    borderColor: '#ddd', // Add border color
  },
  imageContainer: {
    alignItems: 'center',
    marginBottom: 20,
  },
  detailsContainer: {
    backgroundColor: 'white',
    borderRadius: 25,
    padding: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 5,
  },
  detailItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
    paddingVertical: 10,
  },
  label: {
    fontWeight: 'bold',
    fontSize: 16,
  },
  value: {
    fontSize: 16,
    color: '#555',
  },
  table: {
    borderWidth: 12,
    borderColor: '#ddd',
    borderRadius: 28,
    overflow: 'hidden',
    width: 1200,
    backgroundColor: '#fff',
  },
  headerRow: {
    flexDirection: 'row',
    backgroundColor: '#007bff',
    borderBottomWidth: 12,
    borderBottomColor: '#ddd',
  },
  headerCell: {
    flex: 1,
    padding: 10,
    color: '#fff',
    fontWeight: 'bold',
    textAlign: 'center',
    borderRightWidth: 1,
    borderRightColor: '#ddd',
  },
  row: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
  },
  highlightedRow: {
    backgroundColor: '#e0f7fa',
  },
  cell: {
    flex: 1,
    padding: 2,
    textAlign: 'center',
    borderRightWidth: 1,
    borderRightColor: '#ddd',
  },
  modalBackground: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContainer: {
    width: '80%',
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 10,
    alignItems: 'center',
  },
  modalImage: {
    width: '100%',
    height: 400,
    resizeMode: 'contain',
  },
});

export default ViewDoctor;
