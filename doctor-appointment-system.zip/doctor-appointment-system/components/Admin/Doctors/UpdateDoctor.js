import  { useState, useEffect, useRef } from 'react';
import { ScrollView,View, Text, Button, StyleSheet, Modal, Pressable, Image, TextInput, FlatList, Animated, TouchableOpacity, Picker} from 'react-native';
import * as ImagePicker from 'expo-image-picker'; 
import Ionicons from 'react-native-vector-icons/Ionicons'; 
const UpdateDoctor = () => {
  const [doctors, setDoctors] = useState([]);
  const [filteredDoctors, setFilteredDoctors] = useState([]);
  const [searchText, setSearchText] = useState('');
  const [modalVisible, setModalVisible] = useState(false);
  const [errorModalVisible, setErrorModalVisible] = useState(false);
  const [successModalVisible, setSuccessModalVisible] = useState(false); 
  const [confirmCancelModalVisible, setConfirmCancelModalVisible] = useState(false); 
  const [errorMessage, setErrorMessage] = useState('');
  const [selectedDoctor, setSelectedDoctor] = useState(null);
  const [name, setName] = useState('');
  const [specialization, setSpecialization] = useState('');
  const [fees, setFees] = useState('');
  const [image, setImage] = useState('');
  const [contact, setContact] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isPickerVisible, setIsPickerVisible] = useState(false);
  const colorAnim = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const colorAnimation = Animated.loop(
      Animated.sequence([
        Animated.timing(colorAnim, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: false,
        }),
        Animated.timing(colorAnim, {
          toValue: 0,
          duration: 1000,
          useNativeDriver: false,
        }),
      ])
    );
    colorAnimation.start();
    fetchDoctors();
    return () => {
      colorAnimation.stop();
    };
  }, [colorAnim]);
  const fetchDoctors = async () => {
    try {
      const response = await fetch('https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Doctors.json');
      if (!response.ok) throw new Error('Failed to fetch doctors');
      const data = await response.json();
      const doctorsArray = Object.keys(data).map(key => ({
        ID: key,
        ...data[key]
      }));
      setDoctors(doctorsArray);
      setFilteredDoctors(doctorsArray);
    } catch (error) {
      setErrorMessage(error.message);
      setErrorModalVisible(true);
    }
  };
  const handleSearch = (text) => {
    setSearchText(text);
    if (text === '') {
      setFilteredDoctors(doctors);
    } else {
      const filtered = doctors.filter(doctor => doctor.ID === text);
      setFilteredDoctors(filtered);
    }
  };
  const validateUniqueFields = async (doctorId) => {
    try {
      const response = await fetch('https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Doctors.json');
      if (!response.ok) throw new Error('Failed to fetch doctors');
      const data = await response.json();
      const existingDoctors = Object.keys(data).map(key => ({
        ID: key,
        ...data[key]
      }));
      const isEmailUnique = !existingDoctors.some(doctor => doctor.Email === email && doctor.ID !== doctorId);
      const isContactUnique = !existingDoctors.some(doctor => doctor.Contact === contact && doctor.ID !== doctorId);
      const isPasswordUnique = !existingDoctors.some(doctor => doctor.Password === password && doctor.ID !== doctorId);
      if (!isEmailUnique) {
        throw new Error('Email is already in use');
      }
      if (!isContactUnique) {
        throw new Error('Contact is already in use');
      }
      if (!isPasswordUnique) {
        throw new Error('Password is already in use');
      }
      return true;
    } catch (error) {
      setErrorMessage(error.message);
      setErrorModalVisible(true);
      return false;
    }
  };
  const handleUpdateDoctor = async () => {
    const isValid = await validateUniqueFields(selectedDoctor.ID);
    if (!isValid) return;
    const updatedDoctor = {
      Name: name,
      Specialization: specialization,
      Fees: fees,
      Image: image,
      Contact: contact,
      Email: email,
      Password: password,
    };
    try {
      const response = await fetch(`https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Doctors/${selectedDoctor.ID}.json`, {
        method: 'PATCH',
        body: JSON.stringify(updatedDoctor),
      });
      if (!response.ok) throw new Error('Failed to update doctor');
      fetchDoctors();
      setModalVisible(false);
      setSuccessModalVisible(true);
    } catch (error) {
      setErrorMessage(error.message);
      setErrorModalVisible(true);
    }
  };
  const pickImage = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      quality: 1,
    });
    if (!result.canceled) {
      setImage(result.uri);
    }
  };
  const handleCancel = () => {
    setConfirmCancelModalVisible(true);
  };
  const confirmCancel = (confirm) => {
    if (confirm) {
      setModalVisible(false);
    }
    setConfirmCancelModalVisible(false);
  };
  const renderItem = ({ item }) => (
    <View style={styles.doctorContainer}>
      <Text style={styles.doctorName}>{item.Name}</Text>
      <Text style={styles.doctorSpecialization}>{item.Specialization}</Text>
      <Text style={styles.doctorFees}>Rs.{item.Fees}</Text>
      <Image source={{ uri: item.Image }} style={styles.doctorImage} />
      <Button
        title="Edit"
        onPress={() => {
          setSelectedDoctor(item);
          setName(item.Name);
          setSpecialization(item.Specialization);
          setFees(item.Fees);
          setImage(item.Image);
          setContact(item.Contact);
          setEmail(item.Email || '');
          setPassword(item.Password || '');
          setModalVisible(true);
        }}
      />
    </View>
  );
  const animatedColors = colorAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['#ff0000', '#0000ff'],
  });
  return (
    <ScrollView style={styles.container}>
      <Animated.Text style={[styles.title, { color: animatedColors }]}>
        Update Doctor
      </Animated.Text>
      <View style={styles.searchContainer}>
        <TextInput
          style={styles.searchBar}
          placeholder="Search by ID"
          value={searchText}
          onChangeText={setSearchText}
        />
        <Button title="Search" onPress={() => handleSearch(searchText)} />
      </View>
      <FlatList
        data={filteredDoctors}
        renderItem={renderItem}
        keyExtractor={item => item.ID}
      />
      <Modal
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => handleCancel()}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Update Doctor</Text>      
            <TouchableOpacity
              onPress={pickImage}
              style={[styles.imagePicker, !image && styles.imagePickerError]}
            >
              {image ? (
                <Image source={{ uri: image }} style={styles.image} />
              ) : (
                <Ionicons name="image-outline" size={40} color="#007bff" />
              )}
            </TouchableOpacity>
            <TextInput
              style={styles.input}
              placeholder="Name"
              value={name}
              onChangeText={setName}
            />
            <TextInput
              style={styles.input}
              placeholder="Specialization"
              value={specialization}
              onChangeText={setSpecialization}
            />
            <Button
              title="Enter Manually Specialization"
              onPress={() => setIsPickerVisible(true)}
            />
            {isPickerVisible && (
              <Picker
                selectedValue={specialization}
                style={styles.picker}
                onValueChange={(itemValue) => setSpecialization(itemValue)}
              >
                <Picker.Item label="Select Specialization" value="" />
                <Picker.Item label="Cardiology" value="Cardiology" />
                <Picker.Item label="Dermatology" value="Dermatology" />
                <Picker.Item label="Neurology" value="Neurology" />
                <Picker.Item label="Pediatrics" value="Pediatrics" />
              </Picker>
            )}
            <TextInput
              style={styles.input}
              placeholder="Fees"
              value={fees}
              onChangeText={setFees}
              keyboardType="numeric"
            />
            <TextInput
              style={styles.input}
              placeholder="Contact"
              value={contact}
              onChangeText={setContact}
              keyboardType="phone-pad"
            />
            <TextInput
              style={styles.input}
              placeholder="Email"
              value={email}
              onChangeText={setEmail}
            />
            <TextInput
              style={styles.input}
              placeholder="Password"
              value={password}
              onChangeText={setPassword}
              secureTextEntry
            />
            <View style={styles.modalButtonContainer}>
              <Pressable
                style={[styles.modalButton, { backgroundColor: 'green' }]}
                onPress={() => handleUpdateDoctor()}
              >
                <Text style={styles.modalButtonText}>Save</Text>
              </Pressable>
              <Pressable
                style={[styles.modalButton, { backgroundColor: 'red' }]}
                onPress={() => handleCancel()}
              >
                <Text style={styles.modalButtonText}>Cancel</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
      <Modal
        transparent={true}
        visible={confirmCancelModalVisible}
        onRequestClose={() => setConfirmCancelModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Confirm Cancellation</Text>
            <Text style={styles.modalText}>Are you sure you want to cancel? Unsaved changes will be lost.</Text>
            <View style={styles.modalButtonContainer}>
              <Pressable
                style={[styles.modalButton, { backgroundColor: 'green' }]}
                onPress={() => confirmCancel(true)}
              >
                <Text style={styles.modalButtonText}>Yes</Text>
              </Pressable>
              <Pressable
                style={[styles.modalButton, { backgroundColor: 'red' }]}
                onPress={() => confirmCancel(false)}
              >
                <Text style={styles.modalButtonText}>No</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
      <Modal
        transparent={true}
        visible={successModalVisible}
        onRequestClose={() => setSuccessModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Success</Text>
            <Text style={styles.modalText}>Doctor information has been successfully updated.</Text>
            <Pressable
              style={[styles.modalButton, { backgroundColor: 'green' }]}
              onPress={() => setSuccessModalVisible(false)}
            >
              <Text style={styles.modalButtonText}>Close</Text>
            </Pressable>
          </View>
        </View>
      </Modal>
      <Modal
        transparent={true}
        visible={errorModalVisible}
        onRequestClose={() => setErrorModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Error</Text>
            <Text style={styles.modalText}>{errorMessage}</Text>
            <Pressable
              style={[styles.modalButton, { backgroundColor: 'red' }]}
              onPress={() => setErrorModalVisible(false)}
            >
              <Text style={styles.modalButtonText}>Close</Text>
            </Pressable>
          </View>
        </View>
      </Modal>
      </ScrollView>
   
  );
};
const styles = StyleSheet.create({
container: {
    flex: 0,
    backgroundColor: '#f2f2f2',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginVertical: 16,
    textAlign: 'center',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  searchBar: {
    flex: 1,
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 5,
    paddingHorizontal: 8,
  },
  doctorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
    paddingVertical: 10,
  },
  doctorName: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  doctorSpecialization: {
    fontSize: 16,
  },
  doctorFees: {
    fontSize: 16,
    color: '#007bff',
  },
  doctorImage: {
    width: 50,
    height: 50,
    borderRadius: 25,
  },
  modalOverlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    width: '80%',
    padding: 20,
    backgroundColor: '#fff',
    borderRadius: 10,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
    elevation: 10,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  modalText: {
    fontSize: 18,
    marginBottom: 20,
  },
  input: {
    width: '100%',
    padding: 10,
    marginVertical: 5,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
  },
  picker: {
    width: '100%',
    height: 50,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 5,
  },
  imagePicker: {
    width: 100,
    height: 100,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#ccc',
    justifyContent: 'center',
    alignItems: 'center',
    marginVertical: 10,
  },
  imagePickerError: {
    borderColor: 'red',
  },
  image: {
    width: '100%',
    height: '100%',
    borderRadius: 35,
  },
  modalButtonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '100%',
  },
  modalButton: {
    padding: 10,
    borderRadius: 5,
    elevation: 2,
    minWidth: '30%',
    alignItems: 'center',
  },
  modalButtonText: {
    color: '#fff',
    fontSize: 16,
  },
});
export default UpdateDoctor;