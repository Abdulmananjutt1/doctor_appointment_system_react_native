import React, { useState, useEffect, useRef } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Modal, Pressable, Image, TouchableOpacity, Animated } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { Picker } from '@react-native-picker/picker';
import Ionicons from 'react-native-vector-icons/Ionicons';

const AddDoctor = () => {
  const [id, setId] = useState('');
  const [name, setName] = useState('');
  const [specialization, setSpecialization] = useState('');
  const [contact, setContact] = useState('');
  const [fees, setFees] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [image, setImage] = useState(null);
  const [contactError, setContactError] = useState(false);
  const [feesError, setFeesError] = useState(false);
  const [emailError, setEmailError] = useState(false);
  const [passwordError, setPasswordError] = useState(false);
  const [idError, setIdError] = useState(false);
  const [fieldError, setFieldError] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [modalMessage, setModalMessage] = useState('');
  const [modalImage, setModalImage] = useState(null);
  const [modalName, setModalName] = useState('');
  const [isPickerVisible, setIsPickerVisible] = useState(true);
  const colorAnim = useRef(new Animated.Value(0)).current;
  const shadowAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const colorAnimation = Animated.loop(
      Animated.sequence([
        Animated.timing(colorAnim, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: false,
        }),
        Animated.timing(colorAnim, {
          toValue: 0,
          duration: 1000,
          useNativeDriver: false,
        }),
      ])
    );
    colorAnimation.start();

    const shadowAnimation = Animated.loop(
      Animated.sequence([
        Animated.timing(shadowAnim, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: false,
        }),
        Animated.timing(shadowAnim, {
          toValue: 0,
          duration: 1000,
          useNativeDriver: false,
        }),
      ])
    );
    shadowAnimation.start();

    return () => {
      colorAnimation.stop();
      shadowAnimation.stop();
    };
  }, [colorAnim, shadowAnim]);

  const pickImage = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });
    if (!result.canceled) {
      setImage(result.assets[0].uri);
    }
  };

  const validateFields = () => {
    let valid = true;
    setContactError(false);
    setFeesError(false);
    setEmailError(false);
    setPasswordError(false);
    setIdError(false);
    setFieldError(false);

    if (!id || !name || !specialization || !contact || !fees || !email || !password || !image) {
      setFieldError(true);
      valid = false;
    }

    // Validate ID: starts with 19 and is exactly 6 digits
    if (!/^(19\d{4})$/.test(id)) {
      setIdError(true);
      valid = false;
    }

    if (contact && contact.length !== 11) {
      setContactError(true);
      valid = false;
    }

    const feesNumber = parseFloat(fees);
    if (isNaN(feesNumber) || feesNumber <= 0 || feesNumber >= 7000) {
      setFeesError(true);
      valid = false;
    }

    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setEmailError(true);
      valid = false;
    }

    // Validate password: must contain both letters and numbers
    if (!/(?=.*[a-zA-Z])(?=.*\d)/.test(password)) {
      setPasswordError(true);
      valid = false;
    }

    return valid;
  };

  const handleAddDoctor = async () => {
    if (!validateFields()) return;

    try {
      const checkResponse = await fetch('https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Doctors.json');
      const existingDoctors = await checkResponse.json();
      const phoneNumberExists = Object.values(existingDoctors).some(doctor => doctor.Contact === contact);
      const emailExists = Object.values(existingDoctors).some(doctor => doctor.Email === email);
      const idExists = Object.values(existingDoctors).some(doctor => doctor.ID === id);

      if (phoneNumberExists) {
        setModalMessage('Existing phone number. Please enter a unique phone number.');
        setModalVisible(true);
        return;
      }
      if (emailExists) {
        setModalMessage('Existing email address. Please enter a unique email address.');
        setModalVisible(true);
        return;
      }
      if (idExists) {
        setModalMessage('Existing ID. Please enter a unique ID.');
        setModalVisible(true);
        return;
      }

      const response = await fetch('https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Doctors.json', {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ID: id,
          Name: name,
          Specialization: specialization,
          Contact: contact,
          Fees: isNaN(parseFloat(fees)) ? 0 : parseFloat(fees),
          Email: email,
          Password: password,
          Image: image,
        }),
      });

      if (response.ok) {
        setModalName(name);
        setModalImage(image);
        setModalMessage('Doctor added successfully!');
      } else {
        setModalMessage('Failed to add doctor. Please try again.');
      }
    } catch (error) {
      setModalMessage('An error occurred. Please try again.');
    } finally {
      setModalVisible(true);
      setId('');
      setName('');
      setSpecialization('');
      setContact('');
      setFees('');
      setEmail('');
      setPassword('');
      setImage(null);
    }
  };

  const shadowInterpolation = shadowAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['rgba(0, 0, 0, 0.2)', 'rgba(255, 255, 255, 0.8)'],
  });

  const animatedColors = colorAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['#ff0000', '#0000ff'],
  });

  return (
    <View style={styles.container}>
      <Animated.Text style={[styles.title, { color: animatedColors }]}>
        Add New Doctor
      </Animated.Text>
      <TouchableOpacity
        onPress={pickImage}
        style={[styles.imagePicker, !image && styles.imagePickerError]}
      >
        {image ? (
          <Image source={{ uri: image }} style={styles.image} />
        ) : (
          <Ionicons name="image-outline" size={40} color="#007bff" />
        )}
      </TouchableOpacity>
      <TextInput
        style={[styles.input, fieldError && !id ? styles.errorInput : null, idError ? styles.errorInput : null]}
        placeholder="Enter ID for this doctor (start from 19 and exactly 6 digits)"
        value={id}
        onChangeText={setId}
        keyboardType="numeric"
      />
      <TextInput
        style={[styles.input, fieldError && !name ? styles.errorInput : null]}
        placeholder="Name"
        value={name}
        onChangeText={setName}
      />
      {isPickerVisible ? (
        <>
        
          <Button title="Enter Manually Specialization" onPress={() => setIsPickerVisible(false)} />
          <Picker
            selectedValue={specialization}
            style={[styles.input, fieldError && !specialization ? styles.errorInput : null]}
            onValueChange={(itemValue) => setSpecialization(itemValue)}
          >
            <Picker.Item label="Select Specialization" value="" />
            <Picker.Item label="Cardiology" value="Cardiology" />
            <Picker.Item label="Dermatology" value="Dermatology" />
            <Picker.Item label="Neurology" value="Neurology" />
            <Picker.Item label="Pediatrics" value="Pediatrics" />
          </Picker>
        </>
      ) : (
        <>
          <TextInput
            style={[styles.input, fieldError && !specialization ? styles.errorInput : null]}
            placeholder="Specialization"
            value={specialization}
            onChangeText={setSpecialization}
          />
          <Button title="Select Specialization from List" onPress={() => setIsPickerVisible(true)} />
        </>
      )}
      <TextInput
        style={[styles.input, fieldError && !contact ? styles.errorInput : null, contactError ? styles.errorInput : null]}
        placeholder="Contact"
        value={contact}
        onChangeText={setContact}
        keyboardType="numeric"
      />
      <TextInput
        style={[styles.input, fieldError && !fees ? styles.errorInput : null, feesError ? styles.errorInput : null]}
        placeholder="Fees"
        value={fees}
        onChangeText={setFees}
        keyboardType="numeric"
      />
      <TextInput
        style={[styles.input, fieldError && !email ? styles.errorInput : null, emailError ? styles.errorInput : null]}
        placeholder="Email"
        value={email}
        onChangeText={setEmail}
      />
      <TextInput
        style={[styles.input, fieldError && !password ? styles.errorInput : null, passwordError ? styles.errorInput : null]}
        placeholder="Password"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
      />
      <View style={styles.btn} >
      <Button title="Add Doctor" onPress={handleAddDoctor} /></View>
      <Modal
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>{modalMessage}</Text>
            {modalName ? <Text style={styles.modalSubtitle}>Name: {modalName}</Text> : null}
            {modalImage ? <Image source={{ uri: modalImage }} style={styles.modalImage} /> : null}
            <Pressable
              style={[styles.button, styles.buttonClose]}
              onPress={() => setModalVisible(false)}
            >
              <Text style={styles.textStyle}>OK</Text>
            </Pressable>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginVertical: 16,
    textAlign: 'center',
  },
  input: {
    height: 40,
    borderColor: '#ddd',
    borderWidth: 1,
    marginBottom: 12,
    paddingHorizontal: 8,
    borderRadius: 4,
  },
  errorInput: {
    borderColor: '#ff0000',
  },
  imagePicker: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 10,
    borderRadius: 50,
    borderWidth: 1,
    borderColor: '#ccc',
    marginBottom: 15,
    width: 100,
    height: 100,
    overflow: 'hidden',
    alignSelf: 'center',
  },
  imagePickerError: {
    borderColor: 'blue',
  },
  image: {
    width: '100%',
    height: '100%',
    borderRadius: 50,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  modalContent: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 8,
    width: '80%',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 5,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  modalSubtitle: {
    marginTop: 10,
    fontSize: 16,
  },
  modalImage: {
    width: 100,
    height: 100,
    borderRadius: 8,
    marginVertical: 10,
  },
      btn: {
    borderRadius: 240,
    padding: 10,
    marginTop: 2,
    width: 200,
    alignSelf: 'center', // Center horizontally within its parent
    justifyContent: 'center',
    alignItems: 'center', // Center content within the button
  },
  button: {
    borderRadius: 4,
    padding: 10,
    marginTop: 20,
  },
  buttonClose: {
    backgroundColor: '#007bff',
  },
  textStyle: {
    color: '#fff',
    textAlign: 'center',
  },

  
});

export default AddDoctor;
