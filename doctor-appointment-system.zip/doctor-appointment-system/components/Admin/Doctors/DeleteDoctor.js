import React, { useState, useEffect, useRef } from 'react';
import { View, Text, Button, StyleSheet, Modal, Pressable, Image, TextInput, Animated, FlatList } from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';

const DeleteDoctor = () => {
  const [doctors, setDoctors] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredDoctors, setFilteredDoctors] = useState([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [modalMessage, setModalMessage] = useState('');
  const [selectedDoctor, setSelectedDoctor] = useState(null);

  const colorAnim = useRef(new Animated.Value(0)).current;
  const shadowAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const colorAnimation = Animated.loop(
      Animated.sequence([
        Animated.timing(colorAnim, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: false,
        }),
        Animated.timing(colorAnim, {
          toValue: 0,
          duration: 1000,
          useNativeDriver: false,
        }),
      ])
    );
    colorAnimation.start();

    const shadowAnimation = Animated.loop(
      Animated.sequence([
        Animated.timing(shadowAnim, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: false,
        }),
        Animated.timing(shadowAnim, {
          toValue: 0,
          duration: 1000,
          useNativeDriver: false,
        }),
      ])
    );
    shadowAnimation.start();

    // Fetch doctors from the database
    fetchDoctors();

    return () => {
      colorAnimation.stop();
      shadowAnimation.stop();
    };
  }, [colorAnim, shadowAnim]);

  useEffect(() => {
    if (searchQuery === '') {
      setFilteredDoctors(doctors);
    } else {
      const filtered = doctors.filter(doctor => 
        doctor.id.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setFilteredDoctors(filtered);
    }
  }, [searchQuery, doctors]);

  const fetchDoctors = async () => {
    try {
      const response = await fetch('https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Doctors.json');
      const data = await response.json();
      const doctorsArray = Object.keys(data).map(key => ({
        id: key,
        ...data[key]
      }));
      setDoctors(doctorsArray);
      setFilteredDoctors(doctorsArray);
    } catch (error) {
      console.error('Error fetching doctors:', error);
    }
  };

  const handleDeleteDoctor = async (doctorId) => {
    try {
      await fetch(`https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Doctors/${doctorId}.json`, {
        method: 'DELETE',
      });
      setModalMessage('Doctor deleted successfully!');
      fetchDoctors();
    } catch (error) {
      setModalMessage('Failed to delete doctor. Please try again.');
      console.error('Error deleting doctor:', error);
    } finally {
      setModalVisible(false);
    }
  };

  const shadowInterpolation = shadowAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['rgba(0, 0, 0, 0.2)', 'rgba(255, 255, 255, 0.8)'],
  });

  const animatedColors = colorAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['#ff0000', '#0000ff'],
  });

  const renderItem = ({ item }) => (
    <View style={styles.doctorContainer}>
      <Text style={styles.doctorName}>{item.Name}</Text>
      <Text style={styles.doctorSpecialization}>{item.Specialization}</Text>
      <Text style={styles.doctorFees}>Rs.{item.Fees}</Text>
      <Image source={{ uri: item.Image }} style={styles.doctorImage} />
      <Button
        title="Remove"
        onPress={() => {
          setSelectedDoctor(item);
          setModalMessage(`Are you sure you want to delete Dr. ${item.Name}?`);
          setModalVisible(true);
        }}
      />
    </View>
  );

  return (
    <View style={styles.container}>
      <Animated.Text style={[styles.title, { color: animatedColors }]}>
        Delete Doctor
      </Animated.Text>
      <TextInput
        style={styles.searchBar}
        placeholder="Search by Doctor ID"
        value={searchQuery}
        onChangeText={setSearchQuery}
      />
      <FlatList
        data={filteredDoctors}
        renderItem={renderItem}
        keyExtractor={item => item.id}
      />
      <Modal
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Delete Confirmation</Text>
            <Text style={styles.modalText}>{modalMessage}</Text>
            {selectedDoctor && (
              <Image source={{ uri: selectedDoctor.Image }} style={styles.modalImage} />
            )}
            <View style={styles.modalButtonContainer}>
              <Pressable
                style={[styles.modalButton, { backgroundColor: 'red' }]}
                onPress={() => handleDeleteDoctor(selectedDoctor.id)}
              >
                <Text style={styles.modalButtonText}>Yes</Text>
              </Pressable>
              <Pressable
                style={[styles.modalButton, { backgroundColor: 'green' }]}
                onPress={() => setModalVisible(false)}
              >
                <Text style={styles.modalButtonText}>No</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginVertical: 16,
    textAlign: 'center',
  },
  searchBar: {
    height: 40,
    borderColor: '#ddd',
    borderWidth: 1,
    borderRadius: 5,
    paddingHorizontal: 10,
    marginBottom: 20,
  },
  doctorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
    paddingVertical: 10,
  },
  doctorName: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  doctorSpecialization: {
    fontSize: 16,
  },
  doctorFees: {
    fontSize: 16,
    color: '#007bff',
  },
  doctorImage: {
    width: 80,
    height: 80,
    borderRadius: 15,
  },
  modalOverlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    width: '80%',
    padding: 20,
    backgroundColor: '#fff',
    borderRadius: 10,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
    elevation: 10,
  },
  modalImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: 10,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  modalText: {
    fontSize: 18,
    marginBottom: 20,
  },
  modalButtonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '100%',
  },
  modalButton: {
    padding: 10,
    borderRadius: 5,
    elevation: 2,
    minWidth: '30%',
    alignItems: 'center',
  },
  modalButtonText: {
    color: '#fff',
    fontSize: 16,
  },
});

export default DeleteDoctor;
