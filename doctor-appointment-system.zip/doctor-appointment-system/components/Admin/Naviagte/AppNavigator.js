import { createDrawerNavigator } from '@react-navigation/drawer';
import { NavigationContainer } from '@react-navigation/native';
import Dashboard from '../HomeScreen/Dashboard'; 
import AddDoctor from '../Doctors/AddDoctor';
import UpdateDoctor from '../Doctors/UpdateDoctor';
import ViewDoctor from '../Doctors/ViewDoctor';
import DeleteDoctor from '../Doctors/DeleteDoctor';
import AddClinic from '../Clinic_Information/AddClinic';
import UpdateClinic from '../Clinic_Information/UpdateClinic';
import ViewClinic from '../Clinic_Information/ViewClinic';
import Users from '../Addtional/Users';
import Medication from '../Addtional/Medications';
import Sidebar from '../HomeScreen/Sidebar'; 
import LoginScreen from '../Authentication/Login'; 
const Drawer = createDrawerNavigator();
const AppNavigator = () => {
  return (
    <NavigationContainer>
      <Drawer.Navigator  drawerContent={(props) => <Sidebar {...props} />} initialRouteName="" 
      screenOptions={{
          headerShown: false,
        }}
      >
        <Drawer.Screen name="Login" component={LoginScreen} />
        <Drawer.Screen name="Dashboard" component={Dashboard} />
        <Drawer.Screen name="AddDoctor" component={AddDoctor} />
        <Drawer.Screen name="UpdateDoctor" component={UpdateDoctor} />
        <Drawer.Screen name="ViewDoctor" component={ViewDoctor} />
        <Drawer.Screen name="DeleteDoctor" component={DeleteDoctor} />
        <Drawer.Screen name="AddClinic" component={AddClinic} />
        <Drawer.Screen name="UpdateClinic" component={UpdateClinic} />
        <Drawer.Screen name="ViewClinic" component={ViewClinic} />
        <Drawer.Screen name="Users" component={Users} />
        <Drawer.Screen name="Medication" component={Medication} />
      </Drawer.Navigator>
    </NavigationContainer>
  );
};
export default AppNavigator;
