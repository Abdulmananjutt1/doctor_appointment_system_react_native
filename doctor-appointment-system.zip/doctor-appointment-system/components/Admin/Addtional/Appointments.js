import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, ScrollView, TouchableOpacity, ImageBackground, Alert, Modal, TextInput, Button } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const Users = () => {
  const [appointments, setAppointments] = useState([]);
  const [error, setError] = useState(null);
  const [isModalVisible, setModalVisible] = useState(false);
  const [updatedUsername, setUpdatedUsername] = useState('');
  const [updatedEmail, setUpdatedEmail] = useState('');
  const [updatedPassword, setUpdatedPassword] = useState('');
  const [updatedConfirmPassword, setUpdatedConfirmPassword] = useState('');

  useEffect(() => {
    const fetchAppointments = async () => {
      try {
        const response = await fetch('https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Appointments.json');
        if (!response.ok) {
          throw new Error('Failed to fetch Appointments.');
        }
        const data = await response.json();
        const appointmentArray = Object.keys(data).map(key => ({
          id: key,
          ...data[key]
        }));
        setAppointments(appointmentArray);
      } catch (error) {
        setError(error.message);
      }
    };

    fetchAppointments();
  }, []);

  const handleUpdate = () => {
    if (updatedPassword !== updatedConfirmPassword) {
      Alert.alert('Error', 'Passwords do not match');
      return;
    }

    // Handle the update logic here. For now, just close the modal
    Alert.alert('Success', 'User information updated successfully');
    setModalVisible(false);
  };

  const renderUserItem = ({ item, index }) => (
    <View style={[styles.row, index % 2 === 0 && styles.highlightedRow]}>

      <Text style={styles.cell}>{item.TokenId}</Text>
      <Text style={styles.cell}>{item.Name}</Text>
      <Text style={styles.cell}>{item.Birth}</Text>
      <Text style={styles.cell}>{item.Age}</Text>
      <Text style={styles.cell}>{item.Email}</Text>
      <Text style={styles.cell}>{item.Contact}</Text>
      <Text style={styles.cell}>{item.DoctorName}</Text>
      <Text style={styles.cell}>{item.Specialization}</Text>
      <Text style={styles.cell}>{item.Fees}</Text>
      <Text style={styles.cell}>{item.AppointmentDate}</Text>
      <Text style={styles.cell}>{item.AppointmentTime}</Text>
      <Text style={styles.cell}>{item.AccountName}</Text>
      <Text style={styles.cell}>{item.AccountNumber}</Text>
    </View>
  );

  const colors = ['#FF5733', '#33FF57', '#3357FF', '#FF33A6', '#FFBD33', '#A633FF', '#33FFFC', '#FF5733'];
  
  const renderTitle = () => {
    const titleText = "Appointments";
    return titleText.split('').map((letter, index) => (
      <Text key={index} style={[styles.titleLetter, { color: colors[index % colors.length] }]}>
        {letter}
      </Text>
    ));
  };

  return (
    <View style={styles.image}>
      <ImageBackground
        source={{ uri: 'https://engage.healthtrustjobs.com/hubfs/Images/Blog/MCCHildrens-exterior.jpg' }}
        style={styles.backgroundImage}
      >
        <View style={styles.container}>
          <View style={styles.mainContent}>
            <View style={styles.total}>
              <View style={styles.titleContainer}>
                {renderTitle()}
              </View>
              <Text style={styles.total1}>Total: {appointments.length}</Text>
            </View>
            <ScrollView horizontal>
              <View>
                <View style={styles.headerRow}>
                  <Text style={styles.headerCell}>Token No.</Text>
                  <Text style={styles.headerCell}>Name</Text>
                  <Text style={styles.headerCell}>Date-of-Birth</Text>
                  <Text style={styles.headerCell}>Age</Text>
                  <Text style={styles.headerCell}>Email</Text>
                  <Text style={styles.headerCell}>Contact</Text>
                  <Text style={styles.headerCell}>Doctor Name</Text>
                  <Text style={styles.headerCell}>Specialization</Text>
                  <Text style={styles.headerCell}>Fees</Text>
                  <Text style={styles.headerCell}>Appointment Date</Text>
                  <Text style={styles.headerCell}>Appointment Time</Text>
                  <Text style={styles.headerCell}>Account Name</Text>
                  <Text style={styles.headerCell}>Account Number</Text>
                </View>
                <FlatList
                  data={appointments}
                  renderItem={renderUserItem}
                  keyExtractor={item => item.id}
                />
              </View>
            </ScrollView>
          </View>
        </View>
      </ImageBackground>
      <Modal
        visible={isModalVisible}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Edit User</Text>
            <TextInput
              style={styles.input}
              placeholder="Username"
              value={updatedUsername}
              onChangeText={setUpdatedUsername}
            />
            <TextInput
              style={styles.input}
              placeholder="Email"
              value={updatedEmail}
              onChangeText={setUpdatedEmail}
            />
            <TextInput
              style={styles.input}
              placeholder="Password"
              secureTextEntry
              value={updatedPassword}
              onChangeText={setUpdatedPassword}
            />
            <TextInput
              style={styles.input}
              placeholder="Confirm Password"
              secureTextEntry
              value={updatedConfirmPassword}
              onChangeText={setUpdatedConfirmPassword}
            />
            <View style={styles.modalButtons}>
              <Button title="Update" onPress={handleUpdate} />
              <Button title="Cancel" onPress={() => setModalVisible(false)} color="red" />
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
  },
  image: {
    height: 635,
  },
  mainContent: {
    flex: 1,
    backgroundColor: '#ffffff',
    borderRadius: 8,
    overflow: 'hidden',
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.2,
    shadowRadius: 10,
    borderColor: '#ddd',
    borderWidth: 1,
    padding: 15,
  },
  titleContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: 15,
  },
  titleLetter: {
    fontSize: 26,
    fontWeight: 'bold',
  },
  total: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#007bff',
    marginBottom: 15,
    textAlign: 'right',
    backgroundColor: '#e0f7fa',
    padding: 10,
    borderRadius: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  backgroundImage: {
    flex: 1,
    resizeMode: 'cover',
  },
  total1: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#007bff',
  },
  headerRow: {
    flexDirection: 'row',
    backgroundColor: '#007bff',
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
    paddingVertical: 10,
    width: 1140,
  },
  headerCell: {
    flex: 1,
    color: '#fff',
    fontWeight: 'bold',
    textAlign: 'center',
    padding: 2,
    borderRightWidth: 1,
    borderRightColor: '#ddd',
  },
  row: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
    paddingVertical: 0,
  },
  highlightedRow: {
    backgroundColor: '#e8f0fe',
  },
  cell: {
    flex: 1,
    textAlign: 'center',
    padding: 10,
    borderRightWidth: 1,
    borderRightColor: '#ddd',
  },
  actionCell: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 10,
  },
  actionButton: {
    marginHorizontal: 5,
    padding: 5,
    borderRadius: 5,
    backgroundColor: '#f1f1f1',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    width: '80%',
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 20,
    elevation: 5,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 15,
  },
  input: {
    height: 40,
    borderColor: '#ddd',
    borderWidth: 1,
    marginBottom: 10,
    paddingHorizontal: 10,
    borderRadius: 5,
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
});

export default Users;
