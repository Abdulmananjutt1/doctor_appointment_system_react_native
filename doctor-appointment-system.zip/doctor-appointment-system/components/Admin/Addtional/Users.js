import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, ScrollView, TouchableOpacity, ImageBackground, Alert, Modal, TextInput, Button } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const Users = () => {
  const [users, setUsers] = useState([]);
  const [error, setError] = useState(null);
  const [isModalVisible, setModalVisible] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [updatedUsername, setUpdatedUsername] = useState('');
  const [updatedEmail, setUpdatedEmail] = useState('');
  const [updatedPassword, setUpdatedPassword] = useState('');
  const [updatedConfirmPassword, setUpdatedConfirmPassword] = useState('');
 useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await fetch('https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/PatientAccountsInfo.json');
        if (!response.ok) {
          throw new Error('Failed to fetch users.');
        }
        const data = await response.json();
        const usersArray = Object.keys(data).map(key => ({
          id: key,
          ...data[key]
        }));
        setUsers(usersArray);
      } catch (error) {
        setError(error.message);
      }
    };

    fetchUsers();
  }, []);

  const handleEdit = (user) => {
    setEditingUser(user);
    setUpdatedUsername(user.username);
    setUpdatedEmail(user.email);
    setUpdatedPassword(user.password);
    setUpdatedConfirmPassword(user.confirmPassword);
    setModalVisible(true);
  };

  const handleDelete = (userId) => {
    setUserToDelete(userId);
    setDeleteModalVisible(true);
  };

  const confirmDelete = async () => {
    try {
      const response = await fetch(`https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/PatientAccountsInfo/${userToDelete}.json`, {
        method: 'DELETE',
      });
      if (!response.ok) {
        throw new Error('Failed to delete user.');
      }
      setUsers(users.filter(user => user.id !== userToDelete));
      setDeleteModalVisible(false);
    } catch (error) {
      setError(error.message);
    }
  };

  const handleUpdate = async () => {
    if (updatedPassword !== updatedConfirmPassword) {
      setErrorMessage('Passwords do not match.');
      setErrorModalVisible(true);
      return;
    }

    try {
      const response = await fetch(`https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/PatientAccountsInfo/${editingUser.id}.json`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: updatedUsername,
          email: updatedEmail,
          password: updatedPassword,
          confirmPassword: updatedConfirmPassword
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to update user.');
      }

      const updatedUser = {
        id: editingUser.id,
        username: updatedUsername,
        email: updatedEmail,
        password: updatedPassword,
        confirmPassword: updatedConfirmPassword
      };

      setUsers(users.map(user => (user.id === editingUser.id ? updatedUser : user)));
      setModalVisible(false);
    } catch (error) {
      setError(error.message);
      setErrorModalVisible(true);
    }
  };
  const renderUserItem = ({ item, index }) => (
    <View style={[styles.row, index % 2 === 0 && styles.highlightedRow]}>
      <Text style={styles.cell}>{index + 1}</Text>
      <Text style={styles.cell}>{item.username}</Text>
      <Text style={styles.cell}>{item.email}</Text>
      <Text style={styles.cell}>{item.password}</Text>
      <Text style={styles.cell}>{item.confirmPassword}</Text>
      <View style={styles.actionCell}>
        <TouchableOpacity style={styles.actionButton} onPress={() => handleEdit(item)}>
          <Ionicons name="pencil" size={20} color="#007bff" />
        </TouchableOpacity>
        
      </View>
    </View>
  );
  const colors = ['#FF5733', '#33FF57', '#3357FF', '#FF33A6', '#FFBD33', '#A633FF', '#33FFFC', '#FF5733'];
  const renderTitle = () => {
    const titleText = "Users";
    return titleText.split('').map((letter, index) => (
      <Text key={index} style={[styles.titleLetter, { color: colors[index % colors.length] }]}>
        {letter}
      </Text>
    ));
  };

  return (
    <View style={styles.image}> 
      <ImageBackground
        source={{ uri: 'https://engage.healthtrustjobs.com/hubfs/Images/Blog/MCCHildrens-exterior.jpg' }}
        style={styles.backgroundImage}
      >
        <View>
          <View style={styles.container}>
            <View style={styles.mainContent}>
              <View style={styles.total}>
                <View style={styles.titleContainer}>
                  {renderTitle()}
                </View>
                <Text style={styles.total1}>Total: {users.length}</Text>
              </View>
              <ScrollView horizontal>
                <View>
                  <View style={styles.headerRow}>
                    <Text style={styles.headerCell}>SR No.</Text>
                    <Text style={styles.headerCell}>Username</Text>
                    <Text style={styles.headerCell}>Email</Text>
                    <Text style={styles.headerCell}>Password</Text>
                    <Text style={styles.headerCell}>Confirm Password</Text>
                    <Text style={styles.headerCell}>Action</Text>
                  </View>
                  <FlatList
                    data={users}
                    renderItem={renderUserItem}
                    keyExtractor={item => item.id}
                  />
                </View>
              </ScrollView>
            </View>
          </View>
        </View>
      </ImageBackground>
      <Modal
        visible={isModalVisible}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Edit User</Text>
            <TextInput
              style={styles.input}
              placeholder="Username"
              value={updatedUsername}
              onChangeText={setUpdatedUsername}
            />
            <TextInput
              style={styles.input}
              placeholder="Email"
              value={updatedEmail}
              onChangeText={setUpdatedEmail}
            />
            <TextInput
              style={styles.input}
              placeholder="Password"
              secureTextEntry
              value={updatedPassword}
              onChangeText={setUpdatedPassword}
            />
            <TextInput
              style={styles.input}
              placeholder="Confirm Password"
              secureTextEntry
              value={updatedConfirmPassword}
              onChangeText={setUpdatedConfirmPassword}
            />
            
            <View style={styles.modalButtons}>
              <Button title="Update" onPress={handleUpdate} />
              <Button title="Cancel" onPress={() => setModalVisible(false)} color="red" />
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
  },
  image: {
    height: 635,
  },
  mainContent: {
    flex: 1,
    backgroundColor: '#ffffff',
    borderRadius: 8,
    overflow: 'hidden',
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.2,
    shadowRadius: 10,
    borderColor: '#ddd',
    borderWidth: 1,
    padding: 15,
  },
  titleContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: 15,
  },
  titleLetter: {
    fontSize: 26,
    fontWeight: 'bold',
  },
  total: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#007bff',
    marginBottom: 15,
    textAlign: 'right',
    backgroundColor: '#e0f7fa',
    padding: 10,
    borderRadius: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  backgroundImage: {
    flex: 1,
    resizeMode: 'cover',
  },
  total1: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#007bff',
  },
  headerRow: {
    flexDirection: 'row',
    backgroundColor: '#007bff',
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
    paddingVertical: 10,
    width: 1140,
  },
  headerCell: {
    flex: 1,
    color: '#fff',
    fontWeight: 'bold',
    textAlign: 'center',
    padding: 2,
    borderRightWidth: 1,
    borderRightColor: '#ddd',
  },
  row: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
    paddingVertical: 0,
  },
  highlightedRow: {
    backgroundColor: '#e8f0fe',
  },
  cell: {
width:190,
    textAlign: 'center',
    padding: 10,
    borderRightWidth: 1,
    borderRightColor: '#ddd',
  },
  actionCell: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 10,
  },
  actionButton: {
    marginHorizontal: 5,
    padding: 5,
    borderRadius: 5,
    backgroundColor: '#f1f1f1',
    justifyContent:'center',
    alignContent:'center',
    textAlign:'center'
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    width: '80%',
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 20,
    elevation: 5,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 15,
  },
  input: {
    height: 40,
    borderColor: '#ddd',
    borderWidth: 1,
    marginBottom: 10,
    paddingHorizontal: 10,
    borderRadius: 5,
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
});

export default Users;
