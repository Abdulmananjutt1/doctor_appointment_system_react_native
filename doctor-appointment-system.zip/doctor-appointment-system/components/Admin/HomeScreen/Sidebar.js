import React, { useState, useEffect } from 'react';
import { ScrollView, View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { useNavigation } from '@react-navigation/native'; 

const Sidebar = ({ selectedOption, setSelectedOption }) => {
  const colors = [
  '#3498db', 
  
  '#f39c12', 
  '#e67e22', 

  '#7f8c8d', 
   '#3498db', 
  
];
  const [sidebarColor, setSidebarColor] = useState(colors[0]);

  useEffect(() => {
    let colorIndex = 1;
    const changeColor = () => {
      if (colorIndex < colors.length) {
        setSidebarColor(colors[colorIndex]);
        colorIndex++;
      }
    };
    const initialTimeout = setTimeout(() => {
      changeColor();
      const interval = setInterval(changeColor, 5000);
      setTimeout(() => clearInterval(interval), 250000);
    }, 2000);

    return () => clearTimeout(initialTimeout);
  }, []);

  const navigation = useNavigation();

  const handleLogout = () => {
    navigation.navigate('Login'); 
  };

  return (
    <View style={[styles.sidebar, { backgroundColor: sidebarColor }]}>
      <View style={styles.sidebarTitle}>
        <SidebarTitleComponent />
      </View>
      <ScrollView style={styles.sidebarList}>
        {menuItems.map((item) => (
          <TouchableOpacity
            key={item.key}
            style={[
              styles.sidebarItem,
              selectedOption === item.key && styles.sidebarItemSelected,
            ]}
            onPress={() => {
              if (item.key === 'logout') {
                handleLogout();
              } else {
                setSelectedOption(item.key);
              }
            }}
            accessible
            accessibilityLabel={item.label}
          >
            <Text style={styles.sidebarLink}>
              {item.label}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );
};

const SidebarTitleComponent = () => {
  const colorMapping = {
    A: 'white',
    t: 'white',
    m: 'white',
    S: 'white',
    y: 'white',
    p: 'green',
    o: 'cream',
    e: 'pink',
    n: 'pink',
    i: 'blue',
  };

  const title = 'Appointment System';
  return (
    <View style={styles.titleContainer}>
      {title.split('').map((letter, index) => (
        <Text
          key={index}
          style={{ color: colorMapping[letter] || 'white', fontSize: 24 }}
        >
          {letter}
        </Text>
      ))}
    </View>
  );
};

const menuItems = [
  { key: null, label: 'Home' },
  { key: 'manageDoctors', label: 'Manage Doctors' },
  { key: 'medication', label: 'Medical Record' },
  { key: 'Users', label: 'Users' },
   { key: 'Applications', label: 'Applications' },
  { key: 'Appointments', label: 'Appointment' },
  { key: 'manageClinicInfo', label: 'Manage Clinic' },
  { key: 'logout', label: 'Logout' }, 
];

const styles = StyleSheet.create({
  sidebar: {
    width: 280,
    padding: 20,
    flexDirection: 'column',
    shadowColor: 'rgba(0, 0, 0, 0.2)',
    shadowOffset: { width: 2, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 10,
  },
  sidebarTitle: {
    marginBottom: 20,
  },
  titleContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  sidebarList: {
    padding: 0,
    margin: 0,
  },
  sidebarItem: {
    marginVertical: 5,
    paddingVertical: 10,
    paddingHorizontal: 15,
  },
  sidebarLink: {
    color: 'white',
    fontSize: 18,
  },
  sidebarItemSelected: {
    fontSize: 18,
    color: '#353839',
    backgroundColor: '#3B3B3B',
    borderRadius: 10,
    borderColor: 'white',
    borderWidth: 2,
  },
});

export default Sidebar;
