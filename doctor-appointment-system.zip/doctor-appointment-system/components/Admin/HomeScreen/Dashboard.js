import React, { useState, useEffect } from 'react';
import { ScrollView, View, Text, Dimensions, StyleSheet, Animated, Image, ImageBackground, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import { LineChart } from 'react-native-chart-kit';
import AddDoctor from '../Doctors/AddDoctor';
import UpdateDoctor from '../Doctors/UpdateDoctor';
import ViewDoctor from '../Doctors/ViewDoctor';
import DeleteDoctor from '../Doctors/DeleteDoctor';
import AddClinic from '../Clinic_Information/AddClinic';
import UpdateClinic from '../Clinic_Information/UpdateClinic';
import ViewClinic from '../Clinic_Information/ViewClinic';
import Users from '../Addtional/Users';
import Medication from '../Addtional/Medications';
import Sidebar from './Sidebar'; 
import Applications from '../Addtional/Applications'
import Appointment from '../Addtional/Appointments';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation } from '@react-navigation/native';

const styles = StyleSheet.create({
  dashboardContainer: {
    flex: 1,
    flexDirection: 'row',
    backgroundColor: 'transparent',
  },
  mainContent: {
    flex: 1,
    backgroundColor: '#ecf0f1',
    padding: 20,
  },
  header: {
    backgroundColor: '#3498db',
    color: 'white',
    paddingVertical: 15,
    paddingHorizontal: 20,
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderRadius: 10,
    marginBottom: 20,
    shadowColor: 'rgba(0, 0, 0, 0.2)',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.5,
    shadowRadius: 5,
  },
  mainContentContainer: {
    flex: 1,
  },
  mainContentTitle: {
    fontSize: 24,
    marginBottom: 10,
  },
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: 20,
  },
  statCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    padding: 15,
    width: (Dimensions.get('window').width - 60) / 3,
    marginHorizontal: 5,
    borderRadius: 10,
    shadowColor: 'rgba(0, 0, 0, 0.2)',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.5,
    shadowRadius: 5,
  },
  statIcon: {
    fontSize: 24,
    marginRight: 10,
  },
  statText: {
    fontSize: 18,
  },
  statText1: {
    fontSize: 18,
    color: 'blue',
    fontWeight: 'bold',
  },
  appointmentRequest: {
    marginBottom: 20,
    padding: 10,
    borderRadius: 10,
    backgroundColor: '#fff',
    shadowColor: 'rgba(0, 0, 0, 0.2)',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.5,
    shadowRadius: 5,
  },
  appointmentRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginVertical: 10,
  },
  appointmentDetails: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  appointmentText: {
    fontSize: 16,
    marginRight: 10,
    fontWeight: 'bold',
    color: 'black',
  },
  appointmentImage: {
    width: 60,
    height: 60,
    borderRadius: 30,
    marginRight: 10,
  },
  buttonsContainer: {
    flexDirection: 'row',
    justifyContent: 'flex-end', // Align buttons to the end
    alignItems: 'center',
  },
  button: {
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 5,
    elevation: 3,
    marginHorizontal: 5,
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
  },
  graphContainer: {
    marginVertical: 20,
    padding: 10,
    backgroundColor: '#fff',
    borderRadius: 10,
    shadowColor: 'rgba(0, 0, 0, 0.2)',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.5,
    shadowRadius: 5,
  },
  animatedGraph: {
    borderRadius: 10,
    width: 100,
  },
  button1: {
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 10,
    shadowColor: 'red',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 5,
    elevation: 3,
    marginHorizontal: 5,
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonText1: {
    color: 'white',
    fontSize: 16,
  },
  manageDoctorsBackgroundImage: {
    flex: 1,
    resizeMode: 'cover',
    justifyContent: 'center',
    borderRadius: 10,
  },
  manageDoctorsOption: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'black',
    marginVertical: 10,
  },
  manageClinicContainer: {
    marginVertical: 10,
    padding: 40,
    backgroundColor: '#eaf4f4',
    borderRadius: 10,
    shadowColor: 'rgba(0, 0, 255, 0.2)',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.5,
    shadowRadius: 5,
    width: 250,
    height: 600,
    margin: 15,
  },
  manageClinicHeader: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  tableContainer: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 10,
    marginBottom: 20,
    shadowColor: 'rgba(0, 0, 0, 0.2)',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.5,
    shadowRadius: 5,
  },
  tableHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
    paddingBottom: 10,
    marginBottom: 10,
  },
  tableCell: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  tableRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 10,
  },
  tableData: {
    fontSize: 16,
    color: '#333',
  },
});


const CustomButton = ({ title, color, onPress }) => (
  <TouchableOpacity
    style={[styles.button, { backgroundColor: color }]}
    onPress={onPress}
  >
    <Text style={styles.buttonText}>{title}</Text>
  </TouchableOpacity>
);

const ApplicationTable = ({ totalApplications }) => (
  <View style={styles.tableContainer}>
    <View style={styles.tableHeader}>
      <Text style={styles.tableCell}>Leave Applications </Text>
      <Text style={styles.tableCell}>Count</Text>
    </View>
    <View style={styles.tableRow}>
      <Text style={styles.tableData}>Total Applications</Text>
      <Text style={styles.tableData}>{totalApplications}</Text>
    </View>
  </View>
);

const Dashboard = () => {
  const navigation = useNavigation();
  const [selectedOption, setSelectedOption] = useState(null);
  const [totalDoctors, setTotalDoctors] = useState(null);
  const [totalUsers, setTotalUsers] = useState(null);
  const [totalApplications, setTotalApplications] = useState(null);
  const [totalAppointments, setTotalAppointments] = useState(null);
  const [loadingDoctors, setLoadingDoctors] = useState(true);
  const [loadingUsers, setLoadingUsers] = useState(true);
  const animatedValue = new Animated.Value(0);

  const handleLogout = async () => {
    await AsyncStorage.removeItem('userToken');
    navigation.navigate('Login');
  };

  useEffect(() => {
    Animated.timing(animatedValue, {
      toValue: 1,
      duration: 2000,
      useNativeDriver: true,
    }).start();
    
    fetch('https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Doctors.json')
      .then(response => response.json())
      .then(data => {
        const doctorCount = Array.isArray(data) ? data.length : Object.keys(data).length;
        setTotalDoctors(doctorCount);
        setLoadingDoctors(false);
      })
      .catch(error => {
        console.error('Error fetching total doctors:', error);
        setLoadingDoctors(false);
      });

    fetch('https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/PatientAccountsInfo.json')
      .then(response => response.json())
      .then(data => {
        const userCount = Array.isArray(data) ? data.length : Object.keys(data).length;
        setTotalUsers(userCount);
        setLoadingUsers(false);
      })
      .catch(error => {
        console.error('Error fetching total users:', error);
        setLoadingUsers(false);
      });

    fetch('https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Appointments.json')
      .then(response => response.json())
      .then(data => {
        const appointmentCount = Array.isArray(data) ? data.length : Object.keys(data).length;
        setTotalAppointments(appointmentCount);
        setLoadingUsers(false);
      })
      .catch(error => {
        console.error('Error fetching total appointments:', error);
        setLoadingUsers(false);
      });

    fetch('https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Applications.json')
      .then(response => response.json())
      .then(data => {
        const applicationCount = Array.isArray(data) ? data.length : Object.keys(data).length;
        setTotalApplications(applicationCount);
        setLoadingUsers(false);
      })
      .catch(error => {
        console.error('Error fetching total applications:', error);
        setLoadingUsers(false);
      });
  }, []);

  return (
    <View style={styles.dashboardContainer}>
      <Sidebar selectedOption={selectedOption} setSelectedOption={setSelectedOption} />
      <View style={styles.mainContent}>
        <View style={styles.header}>
          <Text style={{ color: 'white', fontSize: 24 }}>Dashboard</Text>
          <TouchableOpacity onPress={handleLogout}>
            <Icon name="sign-out" size={24} color="white" />
          </TouchableOpacity>
        </View>
        <ScrollView style={styles.mainContentContainer}>
          {selectedOption === null && (
            <>
              <View style={styles.statsRow}>
                <View style={styles.statCard}>
                  <Icon name="calendar" style={styles.statIcon} />
                  <View>
                    <Text style={styles.statText}>Appointments</Text>
                    <Text style={styles.statText1}>{loadingUsers ? 'Loading...' : totalAppointments}</Text>
                  </View>
                </View>
                <View style={styles.statCard}>
                  <Icon name="user-md" style={styles.statIcon} />
                  <View>
                    <Text style={styles.statText}>Total Doctors</Text>
                    <Text style={styles.statText1}>{loadingDoctors ? 'Loading...' : totalDoctors}</Text>
                  </View>
                </View>
                <View style={styles.statCard}>
                  <Icon name="hospital-o" style={styles.statIcon} />
                  <View>
                    <Text style={styles.statText}>Total Users</Text>
                    <Text style={styles.statText1}>{loadingUsers ? 'Loading...' : totalUsers}</Text>
                  </View>
                </View>
              </View>
              <View style={styles.graphContainer}>
                <Animated.View style={styles.animatedGraph}>
                  <LineChart
                    data={{
                      labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                      datasets: [{ data: [20, 45, 28, 80, 99, 43] }],
                    }}
                    width={1200}
                    height={220}
                    chartConfig={{
                      backgroundColor: '#e26a00',
                      backgroundGradientFrom: '#fb8c00',
                      backgroundGradientTo: '#ffa726',
                      decimalPlaces: 2,
                      color: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`,
                      style: { borderRadius: 16 },
                    }}
                    style={{ marginVertical: 8, borderRadius: 16 }}
                  />
                </Animated.View>
              </View>
             
              <ApplicationTable totalApplications={totalApplications} />
            </>
          )}
          {selectedOption === 'manageDoctors' && (
            <ImageBackground
              source={{ uri: 'https://engage.healthtrustjobs.com/hubfs/Images/Blog/MCCHildrens-exterior.jpg' }}
              style={styles.manageDoctorsBackgroundImage}
            >
              <View style={styles.manageClinicContainer}>
                <Text style={styles.manageDoctorsOption} onPress={() => setSelectedOption('addDoctor')}>
                  Add Doctor
                </Text>
                <Text style={styles.manageDoctorsOption} onPress={() => setSelectedOption('viewDoctor')}>
                  View Doctor
                </Text>
                <Text style={styles.manageDoctorsOption} onPress={() => setSelectedOption('updateDoctor')}>
                  Update Doctor
                </Text>
                <Text style={styles.manageDoctorsOption} onPress={() => setSelectedOption('deleteDoctor')}>
                  Delete Doctor
                </Text>
              </View>
            </ImageBackground>
          )}
          {selectedOption === 'medication' && <Medication />}
          {selectedOption === 'Users' && <Users />}
           {selectedOption === 'Applications' && <Applications />}
          {selectedOption === 'Appointments' && <Appointment />}
          {selectedOption === 'manageClinicInfo' && (
            <ImageBackground
              source={{ uri: 'https://engage.healthtrustjobs.com/hubfs/Images/Blog/MCCHildrens-exterior.jpg' }}
              style={styles.manageDoctorsBackgroundImage}
            >
              <View style={styles.manageClinicContainer}>
                <Text style={styles.manageClinicHeader} onPress={() => setSelectedOption('addClinic')}>
                  Add Clinic
                </Text>
                <Text style={styles.manageClinicHeader} onPress={() => setSelectedOption('viewClinic')}>
                  View Clinic
                </Text>
                <Text style={styles.manageClinicHeader} onPress={() => setSelectedOption('updateClinic')}>
                  Update Clinic
                </Text>
              </View>
            </ImageBackground>
          )}
          {selectedOption === 'addDoctor' && <AddDoctor />}
          {selectedOption === 'viewDoctor' && <ViewDoctor />}
          {selectedOption === 'updateDoctor' && <UpdateDoctor />}
          {selectedOption === 'deleteDoctor' && <DeleteDoctor />}
          {selectedOption === 'addClinic' && <AddClinic />}
          {selectedOption === 'viewClinic' && <ViewClinic />}
          {selectedOption === 'updateClinic' && <UpdateClinic />}
        </ScrollView>
      </View>
    </View>
  );
};

export default Dashboard;
