import React, { useState, useEffect } from 'react';
import { View, Image, StyleSheet, TextInput, Text, TouchableOpacity, FlatList, Modal, ScrollView } from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import AsyncStorage from '@react-native-async-storage/async-storage';
import img5 from '../../../assets/pic7.jpg';

const Data = [
  { title: "Doctors Info", iconName: "info", screen: "Doctors Information" },
  { title: "Clinic Info", iconName: "building", screen: "Clinic Information" },
  { title: "Booking", iconName: "calendar", screen: "BookingAppointment" },
  { title: "History", iconName: "clock-o", screen: "History" },
  { title: "Fee Schedule", iconName: "dollar", screen: "Fee Schedule" },
  { title: "Medical Record", iconName: "file", screen: "MedicalRecord" },
];

const DoctorItem = ({ doctor }) => (
  <View style={styles.doctorItem}>
    <Image source={{ uri: doctor.Image || 'https://via.placeholder.com/60' }} style={styles.doctorImage} />
    <View style={styles.doctorInfo}>
      <Text style={styles.doctorName}>{doctor.Name}</Text>
      <Text style={styles.doctorSpecialty}>Specialty: {doctor.Specialization}</Text>
      <Text style={styles.doctorFees}>Fees: {doctor.Fees}</Text>
    </View>
  </View>
);

const renderItem = ({ item, navigation }) => (
  <View style={styles.flatList}>
    <TouchableOpacity onPress={() => navigation.navigate(item.screen)} style={styles.container}>
      <Icon name={item.iconName} style={styles.icon} />
      <Text style={styles.itemTitle}>{item.title}</Text>
    </TouchableOpacity>
  </View>
);

export default function Display({ navigation }) {
  const [doctors, setDoctors] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);
  const [profile, setProfile] = useState(null); 
  const [email, setEmail] = useState('');
 

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch doctors
        const response = await fetch('https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Doctors.json');
        if (!response.ok) {
          throw new Error('Network response was not ok: ' + response.statusText);
        }
        const doctorData = await response.json();
        const doctorArray = doctorData ? Object.values(doctorData) : [];
        setDoctors(doctorArray);
              const storedEmail1 = await AsyncStorage.getItem('userEmail1');  
              setStat(storedEmail1)    
        // Fetch categories
        const categoryResponse = await fetch('https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Doctors.json');
        if (!categoryResponse.ok) {
          throw new Error('Network response was not ok: ' + categoryResponse.statusText);
        }
        const categoryData = await categoryResponse.json();
        const categoryArray = categoryData ? Object.values(categoryData) : [];
        const allCategories = categoryArray.flatMap(doctor => doctor.Specialization || []);
        const uniqueCategories = [...new Set(allCategories)];
        setCategories(uniqueCategories);

        // Fetch profile
        const storedEmail = await AsyncStorage.getItem('userEmail');
        if (storedEmail) {
          setEmail(storedEmail);
          const profileResponse = await fetch('https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Profiles.json');
          if (!profileResponse.ok) {
            throw new Error('Network response was not ok: ' + profileResponse.statusText);
          }
          const profileData = await profileResponse.json();
          const userProfile = Object.values(profileData).find(profile => profile.email === storedEmail);
          if (userProfile) {
            setProfile({
              profileImage: userProfile.profileImage,
              name: userProfile.name,
            });
          } else {
            setProfile(null);
          }
        }
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, []);

  const handleSearch = (text) => {
    setSearchQuery(text);
  };

  const filteredDoctors = doctors.filter((doctor) => {
    if (searchQuery === '') {
      return true;
    } else {
      return doctor.Name.toLowerCase().startsWith(searchQuery.toLowerCase());
    }
  });

  const filteredItems = Data.filter(item => {
    if (searchQuery === '') {
      return true;
    } else {
      return item.title.toLowerCase().includes(searchQuery.toLowerCase());
    }
  });

  const filteredCategories = categories.filter(category => {
    if (searchQuery === '') {
      return true;
    } else {
      return category.toLowerCase().includes(searchQuery.toLowerCase());
    }
  });

  const handleCategoryPress = (category) => {
    setSelectedCategory(category);
    setModalVisible(true);
  };

  const closeModal = () => {
    setModalVisible(false);
    setSelectedCategory(null);
  };

  const modalDoctors = doctors.filter(doctor => doctor.Specialization === selectedCategory);

  return (
    <ScrollView>
      <View style={{ flex: 1 }}>
        <View style={styles.header}>
          <Text style={styles.headerText}>Find your desired{"\n"} Doctor Right Now!</Text>
          <View style={styles.searchBar}>
            <Icon name="search" size={20} color="#aaa" style={styles.searchIcon} />
            <TextInput
              placeholder="Search Doctors."
              placeholderTextColor="#aaa"
              style={styles.searchInput}
              onChangeText={handleSearch}
              value={searchQuery}
            />
          </View>
         
        </View>

        <FlatList
          data={filteredItems}
          renderItem={({ item }) => renderItem({ item, navigation })}
          keyExtractor={(item) => item.title}
          numColumns={2}
          style={styles.flatlist}
        />

        <View style={styles.categories}>
          <Text style={styles.categoriesText}>Categories</Text>
          <View style={styles.categoriesRow}>
            {filteredCategories.map((category, index) => (
              <TouchableOpacity key={index} onPress={() => handleCategoryPress(category)}>
                <Text style={styles.categoryItem}>{category}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        <View>
          <Text style={{ fontWeight: "bold", fontSize: 20, marginTop: 8 }}>Available Doctors</Text>
        </View>

        <FlatList
          data={filteredDoctors}
          renderItem={({ item }) => <DoctorItem doctor={item} />}
          keyExtractor={(item) => item.id}
          style={styles.doctorsList}
        />

        <Modal
          visible={modalVisible}
          transparent={true}
          animationType="slide"
          onRequestClose={closeModal}
        >
          <View style={styles.modalContainer}>
            <View style={styles.modalContent}>
              <Text style={styles.modalTitle}>{selectedCategory}</Text>
              <FlatList
                data={modalDoctors}
                renderItem={({ item }) => <DoctorItem doctor={item} />}
                keyExtractor={(item) => item.id}
                style={styles.modalList}
              />
              <TouchableOpacity style={styles.closeButton} onPress={closeModal}>
                <Text style={styles.closeButtonText}>Close</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  header: {
    backgroundColor: '#4285f4',
    padding: 20,
  },
  headerText: {
    fontSize: 20,
    color: '#fff',
    fontWeight: 'bold',
    marginBottom: 10,
  },
  searchBar: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 25,
    paddingHorizontal: 15,
    paddingVertical: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 5,
    elevation: 5,
    marginRight: 10,
    marginTop: 25,
    width: 350,
  },
  searchIcon: {
    marginRight: 10,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: '#333',
  },
  profileImage: {
    width: 70,
    height: 70,
    borderRadius: 85,
    marginBottom: 0,
    borderWidth: 2,
    borderColor: '#fff',
  },
  profileText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  addButton: {
    backgroundColor: '#4caf50',
    borderRadius: 10,
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  addButtonText: {
    color: '#fff',
    fontSize: 12,
  },
  profile: {
    position: 'absolute',
    right: 20,
    top: 10,
    alignItems: 'center',
    marginTop: 5,
  },
  flatlist: {
    paddingHorizontal: 20,
  },
  flatList: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#4285f4',
    borderRadius: 15,
    paddingHorizontal: 10,
    paddingVertical: 10,
    margin: 7,
  },
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  icon: {
    color: '#fff',
    fontSize: 24,
    marginBottom: 5,
  },
  itemTitle: {
    color: '#fff',
    fontWeight: 'bold',
    textAlign: 'center',
    fontSize: 15,
  },
  categories: {
    marginTop: 30,
    alignItems: 'center',
    backgroundColor: "lightblue",
    padding: 10,
  },
  categoriesText: {
    fontWeight: 'bold',
    fontSize: 19,
    marginBottom: 10,
  },
  categoriesRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center', // Center items horizontally
    alignItems: 'center', // Center items vertically
  },
  categoryItem: {
    padding: 15, // Increase padding for better touch area
    backgroundColor: '#4285f4',
    borderRadius: 15,
    marginBottom: 15, // Add margin between items
    marginHorizontal: 10, // Space between items on the same row
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 14,
    textAlign: 'center', // Center text within the category item
  },
  doctorItem: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    padding: 10,
    borderRadius: 5,
    marginVertical: 5,
    elevation: 2,
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  doctorImage: {
    width: 60,
    height: 60,
    borderRadius: 30,
    objectFit: 'contain',
  },
  doctorInfo: {
    flex: 1,
    marginLeft: 10,
    justifyContent: 'center',
  },
  doctorName: {
    fontWeight: 'bold',
    fontSize: 16,
  },
  doctorSpecialty: {
    fontSize: 14,
  },
  doctorFees: {
    fontSize: 14,
  },
  bookButton: {
    backgroundColor: '#4285f4',
    borderRadius: 5,
    paddingVertical: 5,
    paddingHorizontal: 10,
  },
  bookButtonText: {
    color: '#fff',
    textAlign: 'center',
  },
  doctorsList: {
    marginTop: 20,
    paddingHorizontal: 10,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    width: '90%',
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 10,
    alignItems: 'center',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  modalList: {
    width: '100%',
  },
  closeButton: {
    backgroundColor: '#4285f4',
    borderRadius: 5,
    paddingVertical: 10,
    paddingHorizontal: 20,
    marginTop: 20,
  },
  closeButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
});
