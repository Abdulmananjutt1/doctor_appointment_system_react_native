import React, { useState, useEffect } from 'react';
import {
  View,
  Image,
  StyleSheet,
  TextInput,
  ScrollView,
  Text,
  TouchableOpacity,
  Modal,
  FlatList,
} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import AsyncStorage from '@react-native-async-storage/async-storage';

function BookingAppointment({ navigation }) {
  const [name, setName] = useState('');
  const [age, setAge] = useState('');
  const [birth, setBirth] = useState('');
  const [date, setDate] = useState('');
  const [contact, setContact] = useState('');
  const [email, setEmail] = useState('');
  const [doctorModalVisible, setDoctorModalVisible] = useState(false);
  const [timeSlotModalVisible, setTimeSlotModalVisible] = useState(false);
  const [feedbackModalVisible, setFeedbackModalVisible] = useState(false);
  const [feedbackMessage, setFeedbackMessage] = useState('');
  const [doctors, setDoctors] = useState([]);
  const [selectedDoctor, setSelectedDoctor] = useState(null);
  const [availableTimes, setAvailableTimes] = useState([]);
  const [selectedTime, setSelectedTime] = useState('');
  const [profile, setProfile] = useState(null);
  const [profileExists, setProfileExists] = useState(false);
const [AccountName,setAccountName]=useState('')
const [AccountNumber,setAccountNumber]=useState('')
 useEffect(() => {
  const initializeTokenId = async () => {
    let tokenId = await AsyncStorage.getItem('lastTokenId');
    if (!tokenId) {
      await AsyncStorage.setItem('lastTokenId', '0');
    }
  };

  initializeTokenId();
  fetchProfile();
  fetchDoctors();
}, []);


  const fetchProfile = async () => {
    try {
      const storedEmail = await AsyncStorage.getItem('userEmail');
      if (storedEmail) {
        const response = await fetch(
          'https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Profiles.json'
        );
        const profiles = await response.json();
        const userProfile = Object.entries(profiles).find(
          ([key, profile]) => profile.email === storedEmail
        );
        if (userProfile) {
          const [profileId, profileData] = userProfile;
          setProfile({ ...profileData, id: profileId });
          setProfileExists(true);
          setEmail(storedEmail);
        } else {
          setProfileExists(false);
        }
      }
    } catch (error) {
      console.error('Error fetching profile:', error);
      setProfileExists(false);
    }
  };

  const fetchDoctors = async () => {
    try {
      const response = await fetch(
        'https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Doctors.json'
      );
      const data = await response.json();
      const doctorsArray = Object.keys(data).map((key) => ({
        id: key,
        ...data[key],
      }));
      setDoctors(doctorsArray);
    } catch (error) {
      console.error('Error fetching doctors:', error);
    }
  };

const fetchAppointments = async (doctorId) => {
  try {
    const response = await fetch(
      'https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Appointments.json'
    );
    const data = await response.json();
    const appointments = Object.values(data).filter(
      (appointment) => appointment.DoctorId === doctorId
    );
    return appointments;
  } catch (error) {
    console.error('Error fetching appointments:', error);
    return [];
  }
};
const generateAvailableTimes = async () => {
  const start = 8;
  const end = 12;
  const interval = 30;
  const times = [];
  
  for (let hour = start; hour < end; hour++) {
    for (let min = 0; min < 60; min += interval) {
      const startTime = `${hour}:${min < 10 ? '0' : ''}${min}`;
      const endTime = `${hour}:${min + interval < 10 ? '0' : ''}${min + interval}`;
      times.push(`${startTime} - ${endTime}`);
    }
  }
  
  const bookedAppointments = await fetchAppointments(selectedDoctor?.id);
  const bookedTimes = bookedAppointments.map(
    (appointment) => appointment.AppointmentTime
  );
  
  const filteredTimes = times.filter(
    (time) => !bookedTimes.includes(time)
  );
  
  setAvailableTimes(filteredTimes);
  setTimeSlotModalVisible(true);
};

const todayDate = () => {
  const today = new Date();
  const year = today.getFullYear();
  const month = String(today.getMonth() + 1).padStart(2, '0'); // Months are 0-based
  const day = String(today.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};
  const validateForm = () => {
    if (!name.trim() || !contact.trim()) {
      setFeedbackMessage('Please fill all the fields.');
      setFeedbackModalVisible(true);
      return false;
    }

    if (contact.length !== 11) {
      setFeedbackMessage('Contact number must be 11 digits.');
      setFeedbackModalVisible(true);
      return false;
    }

    return true;
  };const handleButton = async () => {
  if (!validateForm()) return;

  // Retrieve and increment TokenId
  let tokenId = await AsyncStorage.getItem('lastTokenId');
  tokenId = tokenId ? parseInt(tokenId) + 1 : 1;

  // Save the new TokenId
  await AsyncStorage.setItem('lastTokenId', tokenId.toString());

  const email = await AsyncStorage.getItem('userEmail');

  const appointment = {
    TokenId: 1,
    Name: name,
    Birth: birth,
    Contact: contact,
    AppointmentDate: todayDate(),
    AppointmentTime: selectedTime,
    Fees: selectedDoctor?.Fees,
    DoctorName: selectedDoctor?.Name,
    Specialization: selectedDoctor?.Specialization,
    Email: email,
    AccountNumber: AccountNumber,
    AccountName: AccountName,
    Age: age,
  };

  try {
    const response = await fetch(
      'https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Appointments.json',
      {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(appointment),
      }
    );

    if (response.ok) {
      setFeedbackMessage('Appointment booked successfully!');
    } else {
      setFeedbackMessage('Failed to book appointment. Please try again.');
    }
  } catch (error) {
    setFeedbackMessage('An error occurred. Please try again.');
    console.error('Error adding appointment:', error);
  } finally {
    setFeedbackModalVisible(true);
    // Reset form fields
    setName('');
    setAge('');
    setBirth('');
    setContact('');
    setSelectedDoctor(null);
    setSelectedTime('');
    setAccountNumber('');
    setAccountName('');
  }
};

  const handleSelectDoctor = (doctor) => {
    setSelectedDoctor(doctor);
    setDoctorModalVisible(false);
    generateAvailableTimes();
  };

  return (
    <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
      <View style={styles.container}>
        <View style={styles.header}>
          {profile && profile.profileImage ? (
            <Image
              style={styles.profileImage}
              source={{ uri: profile.profileImage }}
            />
          ) : (
            <Image
              style={styles.profileImage}
              source={require('../../../assets/profile_dummy.jpg')}
            />
          )}
          <Text style={styles.profileText}>Booking Appointment</Text>
        </View>

        <View style={styles.patientDetail}>
          <Text style={styles.patientDetailText}>Patient Detail</Text>
        </View>
        <View style={styles.formView}>
          <View style={styles.inputContainer}>
            <Icon name="user" size={20} style={styles.icon} />
            <TextInput
              style={styles.input}
              placeholder="Enter Your Name"
              value={name}
              onChangeText={setName}
              autoCapitalize="none"
              placeholderTextColor="#9e9e9e"
            />
          </View>
          <View style={styles.inputContainer}>
            <Icon name="calendar" size={20} style={styles.icon} />
            <TextInput
              style={styles.input}
              placeholder="Enter Your Age"
              value={age}
              onChangeText={setAge}
              autoCapitalize="none"
              placeholderTextColor="#9e9e9e"
              keyboardType="numeric"
            />
          </View>
          <View style={styles.inputContainer}>
            <Icon name="birthday-cake" size={20} style={styles.icon} />
            <TextInput
              style={styles.input}
              placeholder="Enter Your Birth Date"
              value={birth}
              onChangeText={setBirth}
              autoCapitalize="none"
              placeholderTextColor="#9e9e9e"
            />
          </View>
          <View style={styles.inputContainer}>
            <Icon name="phone" size={20} style={styles.icon} />
            <TextInput
              style={styles.input}
              placeholder="Enter Contact Number"
              value={contact}
              onChangeText={setContact}
              autoCapitalize="none"
              placeholderTextColor="#9e9e9e"
              keyboardType="phone-pad"
            />
          </View>
          <View style={styles.patientDetail}>
            <Text style={styles.patientDetailText}>Doctor Detail</Text>
          </View>
           <View style={styles.inputContainer}>
            <Icon name="user-md" size={40} style={styles.icon} />
            <TouchableOpacity onPress={() => setDoctorModalVisible(true)}>
              <Text style={styles.doctorText}>
                {selectedDoctor ? selectedDoctor.Name : 'Select Doctor Name'}
              </Text>
            </TouchableOpacity>
          </View>
          {selectedDoctor && (
            <View style={styles.doctorDetails}>
              <Text style={styles.doctorDetailTitle}>Doctor Details</Text>
              <View style={styles.table}>
                <View style={styles.tableRow}>
                  <Text style={styles.tableHeader}>Name:</Text>
                  <Text style={styles.tableCell}>{selectedDoctor.Name}</Text>
                  
                </View>
                <View style={styles.tableRow}>
                  <Text style={styles.tableHeader}>Fees:</Text>
                  <Text style={styles.tableCell}>{selectedDoctor.Fees}</Text>
                 
                </View>
                <View style={styles.tableRow}>
                  <Text style={styles.tableHeader}>Specialization:</Text>
                  <Text style={styles.tableCell}>
                   {selectedDoctor.Specialization}
                  </Text>
                 
                </View>
              </View>
            </View>
          )}
          <View style={styles.patientDetail}>
            <Text style={styles.patientDetailText}>Appointment Detail</Text>
          </View>
          <View style={styles.inputContainer}>
            <Icon name="calendar" size={40} style={styles.icon} />
            <TouchableOpacity onPress={() => setTimeSlotModalVisible(true)}>
              <Text style={styles.doctorText}>
                {selectedTime ? selectedTime : 'Select Your Appointment Time'}
              </Text>
            </TouchableOpacity>
          </View>
          <View style={styles.patientDetail}>
            <Text style={styles.patientDetailText}>Payment Detail</Text>
          </View>
             <View style={styles.inputContainer}>
            <Icon name="phone" size={20} style={styles.icon} />
            <TextInput
              style={styles.input}
              placeholder="Enter Account Number"
              value={AccountNumber}
              onChangeText={setAccountNumber}
              autoCapitalize="none"
              placeholderTextColor="#9e9e9e"
              keyboardType="phone-pad"
            />
          </View>
         
          <View style={styles.inputContainer}>
            <Icon name="user" size={20} style={styles.icon} />
            <TextInput
              style={styles.input}
              placeholder="Enter Account Name"
              value={AccountName}
              onChangeText={setAccountName}
              autoCapitalize="none"
              placeholderTextColor="#9e9e9e"
            />
          </View> 
          <View style={styles.buttonContainer}>
            <TouchableOpacity
            style={styles.bookButton}
            onPress={handleButton}
          >
            <Icon name="check-circle" size={20} style={styles.bookIcon} />
            <Text style={styles.buttonText}>Book</Text>
            
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.cancelButton}
            onPress={() => navigation.goBack()}
          >
            <Icon name="times-circle" size={20} style={styles.cancelIcon} />
            <Text style={styles.buttonText}>Cancel</Text>
          </TouchableOpacity>
          </View>
        </View>

        <Modal
          animationType="slide"
          transparent={true}
          visible={doctorModalVisible}
          onRequestClose={() => setDoctorModalVisible(false)}>
          <View style={styles.modalOverlay}>
            <View style={styles.modalView}>
              <Text style={styles.modalText}>Select a Doctor</Text>
              <FlatList
                data={doctors}
                keyExtractor={(item) => item.id}
                renderItem={({ item }) => (
                  <TouchableOpacity
                    style={styles.doctorButton}
                    onPress={() => handleSelectDoctor(item)}>
                    <Text style={styles.doctorButtonText}>{item.Name}</Text>
                  </TouchableOpacity>
                )}
              />
              <TouchableOpacity
                style={styles.closeButton}
                onPress={() => setDoctorModalVisible(false)}>
                <Text style={styles.closeButtonText}>Close</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>

        <Modal
          animationType="slide"
          transparent={true}
          visible={timeSlotModalVisible}
          onRequestClose={() => setTimeSlotModalVisible(false)}>
          <View style={styles.modalOverlay}>
            <View style={styles.modalView}>
              <Text style={styles.modalText} >Select an Appointment Time</Text>
              <FlatList
              
                data={availableTimes}
                keyExtractor={(item, index) => index.toString()}
                renderItem={({ item }) => (
                  <TouchableOpacity
                    style={styles.doctorButton}
                    onPress={() => {
                      setSelectedTime(item);
                      setTimeSlotModalVisible(false);
                    }}>
                    <Text style={styles.doctorButtonText}>{item}</Text>
                  </TouchableOpacity>
                )}
              />
              <TouchableOpacity
                style={styles.closeButton}
                onPress={() => setTimeSlotModalVisible(false)}>
                <Text style={styles.closeButtonText}>Close</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>

        <Modal
          animationType="slide"
          transparent={true}
          visible={feedbackModalVisible}
          onRequestClose={() => setFeedbackModalVisible(false)}>
          <View style={styles.modalOverlay}>
            <View style={styles.modalView}>
          
              <Text style={styles.modalText}>{feedbackMessage}</Text>
              <TouchableOpacity
                style={styles.closeButton}
                onPress={() => setFeedbackModalVisible(false)}>
                <Text style={styles.closeButtonText}>Close</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      </View>
    </ScrollView>
  );
}

export default BookingAppointment;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f4f4f4',
  },
  header: {
    backgroundColor: '#4285f4',
    padding: 20,
    alignItems: 'center',
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
  },
  
  profileImage: {
    width: 120,
    height: 120,
    borderRadius: 60,
    borderWidth: 3,
    borderColor: '#3498db',
  },
  profileText: {
    color: '#ecf0f1',
    fontWeight: 'bold',
    fontSize: 24,
    textAlign: 'center',
    marginTop: 10,
  },
  
  patientDetail: {
    borderBottomColor: 'yellow',
    borderBottomWidth: 6,
    marginVertical: 15,
    alignItems: 'center',
  },
  patientDetailText: {
    fontWeight: 'bold',
    fontSize: 24,
    color: '#4285f4',
  },
  formView: {
    paddingHorizontal: 20,
    flex: 1,
  },
   buttonText: {
    color: '#fff',
    fontSize: 16,
  },
  bookButton: {
    flexDirection: 'row',
    backgroundColor: '#28a745',
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
    textAlign:'center',
    marginBottom: 10,
    
    justifyContent:'center'
  },
  cancelButton: {
    flexDirection: 'row',
    backgroundColor: '#dc3545',
    padding: 10,
    borderRadius: 5,
    justifyContent:'center',
    alignItems: 'left',
    textAlign:'left'
  },
  bookIcon: {
    marginRight: 10,
    color: '#fff',
  },
  cancelIcon: {
    marginRight: 10,
    color: '#fff',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderBottomWidth: 2,
    borderBottomColor: '#3498db',
    marginBottom: 15,
    paddingHorizontal: 10,
    backgroundColor: '#fff',
    borderRadius: 10,
  },
  input: {
    flex: 1,
    height: 50,
    paddingHorizontal: 10,
    fontSize: 16,
    color: '#333',
  },
  icon: {
    color: '#3498db',
    marginRight: 10,
  },
  doctorText: {
    fontSize: 16,
    color: '#333',
    textAlign: 'center',
  },
  buttonContainer: {
    marginTop: 20,
    marginBottom: 30,
  },

  modalOverlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalView: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.3,
    shadowRadius: 6,
    elevation: 10,
    width: '80%',
    alignItems: 'center',
  },
  modalText: {
    marginBottom: 20,
    fontSize: 22,
    fontWeight: 'bold',
    color: '#3498db',
  },
  doctorButton: {
    backgroundColor: '#3498db',
    borderRadius: 20,
    paddingVertical: 10,
    paddingHorizontal: 20,
    marginVertical: 8,
    width: '100%',
    alignItems: 'center',
  },
  doctorButtonText: {
    color: 'white',
    fontSize: 18,
  },
  closeButton: {
    backgroundColor: '#e74c3c',
    borderRadius: 20,
    paddingVertical: 10,
    paddingHorizontal: 20,
    marginVertical: 10,
    width: '100%',
    alignItems: 'center',
  },
  closeButtonText: {
    color: 'white',
    fontSize: 18,
  },

  doctorDetails: {
    marginVertical: 15,
    padding: 15,
    borderWidth: 1,
    borderColor: '#3498db',
    borderRadius: 10,
    backgroundColor: '#ffffff',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 4,
  },
  doctorDetailTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 10,
    textAlign: 'center',
  },
  table: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 5,
    overflow: 'hidden',
  },
  tableRow: {
    flexDirection: 'row',
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
    alignItems: 'center',
  },
  tableHeader: {
    flex: 1,
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  tableCell: {
    flex: 2,
    fontSize: 16,
    color: '#555',
    textAlign:'right'
  },
});

