import React, { useEffect, useState } from 'react';
import { View, Text, Image, StyleSheet, FlatList, TouchableOpacity, ScrollView } from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import img5 from '../../../assets/pic7.jpg';

const DoctorDetails = ({ route, navigation }) => {
  const { doctor } = route.params;
  const [suggestedDoctors, setSuggestedDoctors] = useState([]);

  useEffect(() => {
    const fetchSuggestedDoctors = async () => {
      try {
        const response = await fetch('https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Doctors.json');
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        const doctorData = await response.json();
        const doctorArray = doctorData ? Object.values(doctorData) : [];
        setSuggestedDoctors(doctorArray.filter(d => d.id !== doctor.id));
      } catch (error) {
        console.error(error);
      }
    };

    fetchSuggestedDoctors();
  }, [doctor.id]);

  const renderDoctorItem = ({ item }) => (
    <View style={styles.suggestedDoctorItem}>
      <Image source={{ uri: item.Image || 'https://via.placeholder.com/60' }} style={styles.doctorImage} />
      <View style={styles.doctorInfo}>
        <Text style={styles.doctorName}>{item.Name}</Text>
        <Text style={styles.doctorSpecialty}>Speciality: {item.Specialization}</Text>
        <TouchableOpacity style={styles.bookButton} onPress={() => navigation.navigate('BookingAppointment')}>
          <Text style={styles.bookButtonText}>View Details</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
  const handleSearch = (text) => {
    setSearchQuery(text);
  };

  
  const filteredDoctors = doctors.filter((doctor) => {
    if (searchQuery === '') {
      return true;
    } else {
      return doctor.Name.toLowerCase().startsWith(searchQuery.toLowerCase());
    }
  });

  return (
    <ScrollView style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.headerText}>Find your desired{"\n"} Doctor Right Now!</Text>
          <View style={styles.searchBar}>
            <Icon name="search" size={20} color="#aaa" style={styles.searchIcon} />
            <TextInput
              placeholder="Search..."
              placeholderTextColor="#aaa"
              style={styles.searchInput}
              onChangeText={handleSearch}
              value={searchQuery}
            />
          </View>
          <View style={styles.profile}>
            <Image source={img5} style={styles.profileImage} />
            <Text style={styles.profileText}>Profile</Text>
            <TouchableOpacity style={styles.bookButton} onPress={() => navigation.navigate('DoctorDetails', { doctor })}>
          <Text style={styles.bookButtonText}>Make Appointment</Text>
        </TouchableOpacity>
          </View>
        </View>
      <View style={styles.doctorDetail}>
        <Image source={{ uri: doctor.Image || 'https://via.placeholder.com/150' }} style={styles.doctorDetailImage} />
        <Text style={styles.doctorDetailName}>{doctor.Name}</Text>
        <Text style={styles.doctorDetailSpecialty}>Speciality: {doctor.Specialization}</Text>
        <Text style={styles.doctorDetailInfo}>Fees: {doctor.Fees}</Text>
        <Text style={styles.doctorDetailInfo}>Experience: {doctor.Experience} years</Text>
        <Text style={styles.doctorDetailInfo}>Contact: {doctor.Contact}</Text>
      </View>
      <View style={styles.suggestedDoctors}>
        <Text style={styles.suggestedTitle}>Suggested Doctors</Text>
        <FlatList
          data={suggestedDoctors}
          renderItem={renderDoctorItem}
          keyExtractor={(item) => item.id}
        />
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  bookButton: {
    marginTop: 15,
    backgroundColor: '#4285f4',
    borderRadius: 15,
    paddingVertical: 5,
    paddingHorizontal: 10,
    alignSelf: 'flex-start',
    paddingLeft: 65,
    paddingRight: 65
  },
  bookButtonText: {
    color: '#fff',
  },
  doctorDetail: {
    alignItems: 'center',
    marginBottom: 20,
  },
  doctorDetailImage: {
    width: 150,
    height: 150,
    borderRadius: 75,
  },
  doctorDetailName: {
    fontSize: 24,
    fontWeight: 'bold',
    marginTop: 10,
  },
  doctorDetailSpecialty: {
    fontSize: 18,
    color: 'gray',
    marginVertical: 5,
  },
  doctorDetailInfo: {
    fontSize: 16,
    marginVertical: 2,
  },
  suggestedDoctors: {
    marginTop: 20,
  },
  suggestedTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  suggestedDoctorItem: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    padding: 10,
    borderRadius: 5,
    marginVertical: 5,
    elevation: 2,
  },
  doctorImage: {
    width: 60,
    height: 60,
    borderRadius: 30,
  },
  doctorInfo: {
    marginLeft: 10,
    justifyContent: 'center',
  },
  doctorName: {
    fontWeight: 'bold',
    fontSize: 16,
  },
  doctorSpecialty: {
    fontSize: 14,
  },
  header: {
    backgroundColor: '#4285f4',
    padding: 45,
  },
  headerText: {
    fontSize: 20,
    color: '#fff',
    fontWeight: 'bold',
    marginBottom: 10,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 25,
    paddingHorizontal: 15,
    paddingVertical: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 5,
    elevation: 5,
    width: '90%',
    alignSelf: 'center',
    marginVertical: 10,
    marginTop:10,
    marginRight:90
  },
  searchIcon: {
    marginRight: 10,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: '#333',
  },
  profile: {
    position: 'absolute',
    right: 20,
    top: 10,
    alignItems: 'center',
  },
  profileImage: {
    width: 100,
    height: 100,
    borderRadius: 100,
  },
  profileText: {
    color: 'aqua',
    fontWeight: 'bold',
    fontSize: 19,
  },
  bookButton: {
    marginTop: 5,
    backgroundColor: '#4285f4',
    borderRadius: 5,
    paddingVertical: 5,
    paddingHorizontal: 10,
    alignSelf: 'flex-start',
  },
  bookButtonText: {
    color: '#fff',
  },
});

export default DoctorDetails;
