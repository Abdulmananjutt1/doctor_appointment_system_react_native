import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Modal,
  ScrollView,
  Animated,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

function MedicalRecord({ navigation }) {
  const [medicalRecords, setMedicalRecords] = useState([]);
  const [selectedRecord, setSelectedRecord] = useState(null);
  const [recordModalVisible, setRecordModalVisible] = useState(false);

  useEffect(() => {
    const fetchMedicalRecords = async () => {
      try {
        const storedEmail = await AsyncStorage.getItem('userEmail');
        if (storedEmail) {
          const response = await fetch(
            'https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/MedicalRecords.json'
          );
          const data = await response.json();
          const userRecords = Object.entries(data).filter(
            ([key, record]) => record.email === storedEmail
          ).map(([key, record]) => ({ id: key, ...record }));
          setMedicalRecords(userRecords);
        }
      } catch (error) {
        console.error('Error fetching medical records:', error);
      }
    };

    fetchMedicalRecords();
  }, []);

  const handleRecordPress = (record) => {
    setSelectedRecord(record);
    setRecordModalVisible(true);
  };

  const animatedValue = new Animated.Value(0);

  useEffect(() => {
    if (recordModalVisible) {
      Animated.timing(animatedValue, {
        toValue: 1,
        duration: 300,
        useNativeDriver: true,
      }).start();
    } else {
      Animated.timing(animatedValue, {
        toValue: 0,
        duration: 300,
        useNativeDriver: true,
      }).start();
    }
  }, [recordModalVisible]);

  const modalOpacity = animatedValue.interpolate({
    inputRange: [0, 1],
    outputRange: [0, 1],
  });

  return (
    <ScrollView contentContainerStyle={styles.scrollView}>
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.headerText}>Your Medical Records</Text>
        </View>

        <FlatList
          data={medicalRecords}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={styles.recordItem}
              onPress={() => handleRecordPress(item)}
            >
              <Text style={styles.recordText}>Patient Name: {item.patientName}</Text>
              <Text style={styles.recordText}>Date of Birth: {item.dateOfBirth}</Text>
              <Text style={styles.recordText}>Blood Pressure: {item.bloodPressure}</Text>
            </TouchableOpacity>
          )}
        />

        {selectedRecord && (
          <Modal
            animationType="slide"
            transparent={true}
            visible={recordModalVisible}
            onRequestClose={() => setRecordModalVisible(false)}
          >
            <Animated.View style={[styles.modalOverlay, { opacity: modalOpacity }]}>
              <View style={styles.modalView}>
                <Text style={styles.modalTitle}>Medical Record Details</Text>
                <View style={styles.table}>
                  <View style={styles.tableRow}>
                    <View style={[styles.tableCell, styles.tableHeaderCell]}>
                      <Text style={styles.tableHeaderText}>Field</Text>
                    </View>
                    <View style={[styles.tableCell, styles.tableHeaderCell]}>
                      <Text style={styles.tableHeaderText}>Value</Text>
                    </View>
                  </View>
                  {[
                    { field: 'Patient Name', value: selectedRecord.patientName },
                    { field: 'Date of Birth', value: selectedRecord.dateOfBirth },
                    { field: 'Blood Pressure', value: selectedRecord.bloodPressure },
                    { field: 'Pulse Rate', value: selectedRecord.pulseRate },
                    { field: 'Diagnosed With', value: selectedRecord.diagnosedWith },
                    { field: 'Drug', value: selectedRecord.drug },
                    { field: 'Dosage', value: selectedRecord.dosage },
                    { field: 'Things to Follow', value: selectedRecord.thingsToFollow },
                    { field: 'Physician', value: selectedRecord.physiciansName }
                  ].map(({ field, value }, index) => (
                    <View key={index} style={styles.tableRow}>
                      <View style={styles.tableCell}>
                        <Text style={styles.tableFieldText}>{field}:</Text>
                      </View>
                      <View style={styles.tableCell}>
                        <Text style={styles.tableValueText}>{value}</Text>
                      </View>
                    </View>
                  ))}
                </View>
                <TouchableOpacity
                  style={styles.closeButton}
                  onPress={() => setRecordModalVisible(false)}
                >
                  <Text style={styles.closeButtonText}>Close</Text>
                </TouchableOpacity>
              </View>
            </Animated.View>
          </Modal>
        )}
      </View>
    </ScrollView>
  );
}

export default MedicalRecord;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#e3f2fd', // Light blue background
  },
  scrollView: {
    flexGrow: 1,
  },
  header: {
    backgroundColor: '#0288d1', // Darker blue
    padding: 20,
    alignItems: 'center',
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 5,
  },
  headerText: {
    color: '#ffffff',
    fontWeight: 'bold',
    fontSize: 24,
  },
  recordItem: {
    backgroundColor: '#ffffff',
    borderRadius: 10,
    padding: 15,
    marginVertical: 10,
    marginHorizontal: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
  },
  recordText: {
    fontSize: 16,
    color: '#333',
    marginBottom: 5,
  },
  modalOverlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalView: {
    backgroundColor: '#ffffff',
    padding: 20,
    borderRadius: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
    elevation: 8,
    width: '85%',
  },
  modalTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#0288d1', // Darker blue
    marginBottom: 15,
  },
  table: {
    width: '100%',
    borderWidth: 1,
    borderColor: '#0288d1', // Darker blue
    borderRadius: 10,
    overflow: 'hidden',
    shadowColor: '#0288d1', // Darker blue
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 10,
    elevation: 5,
  },
  tableRow: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: '#0288d1', // Darker blue
  },
  tableCell: {
    flex: 1,
    padding: 10,
    borderRightWidth: 1,
    borderRightColor: '#0288d1', 
    justifyContent: 'center',
  },
  tableHeaderCell: {
    backgroundColor: '#01579b', 
  },
  tableHeaderText: {
    fontWeight: 'bold',
    color: '#ffffff',
  },
  tableFieldText: {
    fontWeight: 'bold',
    color: '#000000',
  },
  tableValueText: {
    fontSize: 18,
    color: '#333333',
  },
  closeButton: {
    backgroundColor: '#0288d1',
    borderRadius: 20,
    paddingVertical: 12,
    paddingHorizontal: 25,
    marginTop: 20,
    width: '100%',
    alignItems: 'center',
  },
  closeButtonText: {
    color: '#ffffff',
    fontSize: 18,
  },
});
