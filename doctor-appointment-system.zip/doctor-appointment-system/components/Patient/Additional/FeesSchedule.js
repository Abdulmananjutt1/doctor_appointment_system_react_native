import { useState, useEffect } from 'react';
import { View, Text, FlatList, StyleSheet, ScrollView, Animated, LayoutAnimation, Platform, UIManager,ImageBackground } from 'react-native';

const FeesSchedule = () => {
  const [doctors, setDoctors] = useState([]);
  const [error, setError] = useState('');
  const animatedValue = useState(new Animated.Value(0))[0];

  useEffect(() => {
    fetchDoctors();
  }, []);

  if (Platform.OS === 'android') {
    if (UIManager.setLayoutAnimationEnabledExperimental) {
      UIManager.setLayoutAnimationEnabledExperimental(true);
    }
  }

  const fetchDoctors = async () => {
    try {
      const response = await fetch('https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Doctors.json');
      const data = await response.json();
      console.log('Fetched doctors data:', data); 
      const doctorsList = Object.keys(data).map(key => ({
        ID: key,
        ...data[key],
      }));
      const uniqueDoctors = Array.from(new Set(doctorsList.map(doctor => doctor.ID)))
        .map(id => doctorsList.find(doctor => doctor.ID === id));

      console.log('Processed doctors list:', uniqueDoctors); 
      setDoctors(uniqueDoctors);

      LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
      Animated.timing(animatedValue, {
        toValue: 1,
        duration: 500,
        useNativeDriver: true,
      }).start();
    } catch (error) {
      setError('Failed to fetch doctors. Please try again.');
    }
  };

  const renderDoctor = ({ item, index }) => (
    <Animated.View 
      style={[
        styles.doctorContainer, 
        { 
          opacity: animatedValue,
          backgroundColor: index % 2 === 0 ? '#e9f7ef' : '#fce8f1' // Alternating background colors
        }
      ]}
    >
      <Text style={styles.doctorName}>{item.Name}</Text>
      <Text style={styles.doctorFees}>Fees: {item.Fees}</Text>
      <Text style={styles.doctorAvailability}>
        Availability: Monday to Saturday, 10 AM to 4 PM
      </Text>
    </Animated.View>
  );

  return (
     <ImageBackground
      source={{ uri: 'https://engage.healthtrustjobs.com/hubfs/Images/Blog/MCCHildrens-exterior.jpg' }}
      style={styles.backgroundImage}
      resizeMode="cover"
    >
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Doctor Fee Schedule</Text>
      {error ? <Text style={styles.error}>{error}</Text> : null}
      <FlatList
        data={doctors}
        keyExtractor={item => item.ID ? item.ID.toString() : 'unknown'}
        renderItem={renderDoctor}
        ListEmptyComponent={<Text style={styles.emptyMessage}>Loading..............</Text>}
      />
    </ScrollView>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
    backgroundImage: {
flex:1,

  },
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#f8f9fa', // Light background for a clean look
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
    color: '#343a40', // Darker color for the title
  },
  doctorContainer: {
    padding: 16,
    marginVertical: 8,
    borderRadius: 10,
    backgroundColor: '#fff', // Default white background (will be overridden by alternating colors)
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
  },
  doctorName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#212529', // Slightly darker text for the doctor's name
  },
  doctorFees: {
    fontSize: 16,
    color: '#495057', // Medium color for fees
    marginVertical: 4,
  },
  doctorAvailability: {
    fontSize: 14,
    color: '#6c757d', // Lighter color for availability
  },
  error: {
    color: '#dc3545', // Red color for error messages
    textAlign: 'center',
    marginBottom: 20,
  },
  emptyMessage: {
    textAlign: 'center',
    fontSize: 16,
    color: '#6c757d', // Lighter color for empty message
    marginVertical: 20,
  },
});

export default FeesSchedule;
