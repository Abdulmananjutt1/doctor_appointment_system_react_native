import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image, ImageBackground } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons'; 
import img1 from '../../../assets/pic1.png';
import img2 from '../../../assets/pic2.png';
import img3 from '../../../assets/pic3.png';
import img4 from '../../../assets/pic4.png';
import img5 from '../../../assets/pic5.jpg'

const Firstpage = ({ navigation }) => {
  return (
    <ImageBackground source={img5} style={styles.background}>
      <View style={styles.img1view}>
        <Image style={styles.img1} source={img1} />
        <View style={styles.img2view}>
          <Image style={styles.img1} source={img2} />
        </View>
      </View>
      <View style={styles.img3view}>
        <Image style={styles.img1} source={img3} />
        <View style={styles.img4view}>
          <Image style={styles.img1} source={img4} />
        </View>
      </View>
      <View style={styles.secondview}>
        <View style={{ justifyContent: "center", alignItems: "center", textAlign: "center" }}>
          <Text style={{ fontWeight: 'bold', fontSize: 29, color: "aqua" }}>Find a Doctor!</Text>
          <View style={styles.underline}></View>
        </View>
        <View>
          <Text style={{ color: 'aqua', fontSize: 20 }}>
            Your Health Hub <Icon name="volunteer-activism" size={20} style={{ color: "pink" }} />{'\n'} Get Appointments here
          </Text>
        </View>
        <View>
          <TouchableOpacity style={styles.btn} onPress={() => navigation.navigate('login')}>
            <Text style={styles.btn1}>Login</Text>
          </TouchableOpacity>
        </View>
        <View>
          <TouchableOpacity style={styles.btn2} onPress={()=>navigation.navigate('CreateAccount')}>
            <Text style={{ color: "aqua",fontSize:16 }}>Create an account</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    height: '100%',
    width: '100%',
  },
  secondview: {
    alignItems: "center",
    paddingTop: 60,
  },
  btn: {
    marginTop: 16,
    borderRadius: 21,
    marginVertical: 5,
    backgroundColor: "aqua",
  },
  btn1: {
    borderColor: "aqua",
    fontSize: 26,
    textAlign: 'center',
    borderRadius: 1,
    paddingRight: 60,
    paddingLeft: 60,
    paddingBottom: 1,
    paddingTop: 1.5,
    fontWeight: "bold",
  },
  btn2: {
    alignItems: "center",
    justifyContent: "center",
    marginTop: 9,
    borderWidth: 4,
    textAlign: 'center',
    borderColor: "aqua",
    color: "aqua",
    borderRadius: 15,
    paddingRight: 25,
    paddingLeft: 25,
    paddingTop: 1.5,
  },
  underline: {
    width: 135,
    height: 1,
    alignContent: "center",
    backgroundColor: "aqua",
    marginLeft: 21,
    marginBottom: 3,
    marginTop: 0,
  },
  img1view: {
    marginLeft: 30,
    marginBottom: 40,
    flexDirection: "row",
  },
  img2view: {
    marginLeft: 90,
    marginTop: 50,
    flexDirection: "row",
  },
  img3view: {
    flexDirection: "row",
  },
  img4view: {
    marginLeft: 140,
    marginTop: 50,
    flexDirection: "row",
  },
  img1: {
    width: 150,
    height: 150,
    borderRadius: 75,
    resizeMode: 'cover',
  },
});

export default Firstpage;
