import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Modal,
  ScrollView,
  Animated,
  ActivityIndicator,
  TextInput,
  Alert,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

function ViewAppointment({ navigation }) {
  const [appointments, setAppointments] = useState([]);
  const [selectedAppointment, setSelectedAppointment] = useState(null);
  const [appointmentModalVisible, setAppointmentModalVisible] = useState(false);
  const [updateModalVisible, setUpdateModalVisible] = useState(false);
  const [loading, setLoading] = useState(true);
  const [doctorName, setDoctorName] = useState('');
  const [appointmentDate, setAppointmentDate] = useState('');
  const [appointmentTime, setAppointmentTime] = useState('');

  useEffect(() => {
    const fetchAppointments = async () => {
      try {
        setLoading(true);
        const storedEmail = await AsyncStorage.getItem('userEmail');
        if (storedEmail) {
          const response = await fetch(
            'https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Appointments.json'
          );
          const data = await response.json();
          const userAppointments = Object.entries(data)
            .filter(([key, appointment]) => appointment.Email === storedEmail)
            .map(([key, appointment]) => ({ id: key, ...appointment }));
          setAppointments(userAppointments);
        }
      } catch (error) {
        console.error('Error fetching appointments:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchAppointments();
  }, []);

  const handleAppointmentPress = (appointment) => {
    setSelectedAppointment(appointment);
    setAppointmentModalVisible(true);
  };

  const handleUpdatePress = (appointment) => {
    setSelectedAppointment(appointment);
    setDoctorName(appointment.DoctorName);
    setAppointmentDate(appointment.AppointmentDate);
    setAppointmentTime(appointment.AppointmentTime);
    setUpdateModalVisible(true);
  };

  const handleDeletePress = (appointment) => {
    Alert.alert(
      'Confirm Delete',
      'Are you sure you want to delete this appointment?',
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        {
          text: 'Delete',
          onPress: async () => {
            try {
              await fetch(
                `https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Appointments/${appointment.id}.json`,
                {
                  method: 'DELETE',
                }
              );
              setAppointments((prevAppointments) =>
                prevAppointments.filter((appt) => appt.id !== appointment.id)
              );
              Alert.alert('Deleted', 'Appointment deleted successfully.');
            } catch (error) {
              console.error('Error deleting appointment:', error);
            }
          },
          style: 'destructive',
        },
      ]
    );
  };

  const handleSaveUpdate = async () => {
    try {
      await fetch(
        `https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Appointments/${selectedAppointment.id}.json`,
        {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            DoctorName: doctorName,
            AppointmentDate: appointmentDate,
            AppointmentTime: appointmentTime,
          }),
        }
      );

      setAppointments((prevAppointments) =>
        prevAppointments.map((appt) =>
          appt.id === selectedAppointment.id
            ? { ...appt, DoctorName: doctorName, AppointmentDate: appointmentDate, AppointmentTime: appointmentTime }
            : appt
        )
      );

      setUpdateModalVisible(false);
      Alert.alert('Updated', 'Appointment updated successfully.');
    } catch (error) {
      console.error('Error updating appointment:', error);
    }
  };

  const animatedValue = new Animated.Value(0);

  useEffect(() => {
    if (appointmentModalVisible || updateModalVisible) {
      Animated.timing(animatedValue, {
        toValue: 1,
        duration: 300,
        useNativeDriver: true,
      }).start();
    } else {
      Animated.timing(animatedValue, {
        toValue: 0,
        duration: 300,
        useNativeDriver: true,
      }).start();
    }
  }, [appointmentModalVisible, updateModalVisible]);

  const modalOpacity = animatedValue.interpolate({
    inputRange: [0, 1],
    outputRange: [0, 1],
  });

  return (
    <ScrollView contentContainerStyle={styles.scrollView}>
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.headerText}>Your Appointments</Text>
        </View>

        {loading ? (
          <View style={styles.loaderContainer}>
            <Animated.View style={[styles.loaderOverlay, { opacity: modalOpacity }]}>
              <ActivityIndicator size="large" color="#00796b" />
              <Text style={styles.loaderText}>Loading...</Text>
            </Animated.View>
          </View>
        ) : (
          <FlatList
            data={appointments}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <View style={styles.appointmentItem}>
                <Text style={styles.appointmentText}>Doctor: {item.DoctorName}</Text>
                <Text style={styles.appointmentText}>Date: {item.AppointmentDate}</Text>
                <Text style={styles.appointmentText}>Time: {item.AppointmentTime}</Text>
                <View style={styles.buttonContainer}>
                  <TouchableOpacity
                    style={[styles.button, styles.viewButton]}
                    onPress={() => handleAppointmentPress(item)}
                  >
                    <Text style={styles.buttonText}>View</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={[styles.button, styles.updateButton]}
                    onPress={() => handleUpdatePress(item)}
                  >
                    <Text style={styles.buttonText}>Update</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={[styles.button, styles.deleteButton]}
                    onPress={() => handleDeletePress(item)}
                  >
                    <Text style={styles.buttonText}>Delete</Text>
                  </TouchableOpacity>
                </View>
              </View>
            )}
          />
        )}

        {selectedAppointment && (
          <>
            <Modal
              animationType="slide"
              transparent={true}
              visible={appointmentModalVisible}
              onRequestClose={() => setAppointmentModalVisible(false)}
            >
              <Animated.View style={[styles.modalOverlay, { opacity: modalOpacity }]}>
                <View style={styles.modalView}>
                  <Text style={styles.modalTitle}>Appointment Details</Text>
                  <View style={styles.table}>
                    <View style={styles.tableRow}>
                      <View style={[styles.tableCell, styles.tableHeaderCell]}>
                        <Text style={styles.tableHeaderText}>Field</Text>
                      </View>
                      <View style={[styles.tableCell, styles.tableHeaderCell]}>
                        <Text style={styles.tableHeaderText}>Value</Text>
                      </View>
                    </View>
                    {[
                      { field: 'Doctor', value: selectedAppointment.DoctorName },
                      { field: 'Date', value: selectedAppointment.AppointmentDate },
                      { field: 'Time', value: selectedAppointment.AppointmentTime },
                      { field: 'Fees', value: selectedAppointment.Fees },
                      { field: 'Specialization', value: selectedAppointment.Specialization },
                      { field: 'Contact', value: selectedAppointment.Contact }
                    ].map(({ field, value }, index) => (
                      <View key={index} style={styles.tableRow}>
                        <View style={styles.tableCell}>
                          <Text style={styles.tableFieldText}>{field}:</Text>
                        </View>
                        <View style={styles.tableCell}>
                          <Text style={styles.tableValueText}>{value}</Text>
                        </View>
                      </View>
                    ))}
                  </View>
                  <TouchableOpacity
                    style={styles.closeButton}
                    onPress={() => setAppointmentModalVisible(false)}
                  >
                    <Text style={styles.closeButtonText}>Close</Text>
                  </TouchableOpacity>
                </View>
              </Animated.View>
            </Modal>

            <Modal
              animationType="slide"
              transparent={true}
              visible={updateModalVisible}
              onRequestClose={() => setUpdateModalVisible(false)}
            >
              <Animated.View style={[styles.modalOverlay, { opacity: modalOpacity }]}>
                <View style={styles.modalView}>
                  <Text style={styles.modalTitle}>Update Appointment</Text>
                  <TextInput
                    style={styles.input}
                    value={doctorName}
                    onChangeText={setDoctorName}
                    placeholder="Doctor Name"
                  />
                  <TextInput
                    style={styles.input}
                    value={appointmentDate}
                    onChangeText={setAppointmentDate}
                    placeholder="Appointment Date"
                  />
                  <TextInput
                    style={styles.input}
                    value={appointmentTime}
                    onChangeText={setAppointmentTime}
                    placeholder="Appointment Time"
                  />
                  <View style={styles.modalButtonContainer}>
                    <TouchableOpacity
                      style={[styles.modalButton, styles.saveButton]}
                      onPress={handleSaveUpdate}
                    >
                      <Text style={styles.buttonText}>Save</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={[styles.modalButton, styles.cancelButton]}
                      onPress={() => setUpdateModalVisible(false)}
                    >
                      <Text style={styles.buttonText}>Cancel</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </Animated.View>
            </Modal>
          </>
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f0f0',
  },
  header: {
    backgroundColor: '#00796b',
    paddingVertical: 15,
    paddingHorizontal: 20,
  },
  headerText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  scrollView: {
    flexGrow: 1,
  },
  loaderContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 50,
  },
  loaderOverlay: {
    flexDirection: 'column',
    alignItems: 'center',
  },
  loaderText: {
    marginTop: 15,
    fontSize: 16,
    color: '#00796b',
  },
  appointmentItem: {
    backgroundColor: '#ffffff',
    marginHorizontal: 15,
    marginVertical: 10,
    padding: 15,
    borderRadius: 10,
    borderColor: '#00796b',
    borderWidth: 1,
  },
  appointmentText: {
    fontSize: 16,
    color: '#333333',
    marginBottom: 5,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  button: {
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
  },
  viewButton: {
    backgroundColor: '#00796b',
  },
  updateButton: {
    backgroundColor: '#ffc107',
  },
  deleteButton: {
    backgroundColor: '#f44336',
  },
  buttonText: {
    fontSize: 16,
    color: '#ffffff',
    textAlign: 'center',
  },
  modalOverlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalView: {
    backgroundColor: '#ffffff',
    padding: 20,
    borderRadius: 10,
    width: '90%',
    alignItems: 'center',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
  },
  table: {
    width: '100%',
    marginBottom: 15,
  },
  tableRow: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderColor: '#ddd',
    paddingVertical: 5,
  },
  tableCell: {
    flex: 1,
  },
  tableHeaderCell: {
    backgroundColor: '#f0f0f0',
    paddingVertical: 8,
  },
  tableHeaderText: {
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  tableFieldText: {
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'left',
    color: '#00796b',
  },
  tableValueText: {
    fontSize: 16,
    textAlign: 'left',
  },
  closeButton: {
    backgroundColor: '#00796b',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
  },
  closeButtonText: {
    fontSize: 16,
    color: '#ffffff',
    textAlign: 'center',
  },
  input: {
    width: '100%',
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 5,
    borderColor: '#00796b',
    borderWidth: 1,
    marginBottom: 15,
  },
  modalButtonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
  },
  modalButton: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 5,
    marginHorizontal: 5,
  },
  saveButton: {
    backgroundColor: '#00796b',
  },
  cancelButton: {
    backgroundColor: '#f44336',
  },
});

export default ViewAppointment;
