import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, Image, TouchableOpacity, Modal, Pressable, ImageBackground } from 'react-native';

const ViewClinic = () => {
  const [clinics, setClinics] = useState([]);
  const [error, setError] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);
  const [modalImage, setModalImage] = useState(null);

  useEffect(() => {
    const fetchClinics = async () => {
      try {
        const response = await fetch('https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Clinics.json');
        if (!response.ok) {
          throw new Error('Failed to fetch clinics.');
        }
        const data = await response.json();
        const clinicsArray = Object.keys(data).map(key => ({
          id: key,
          ...data[key]
        }));
        setClinics(clinicsArray);
      } catch (error) {
        setError(error.message);
      }
    };

    fetchClinics();
  }, []);

  const renderClinicItem = ({ item }) => (
    <View style={styles.clinicItem}>
      <Text style={styles.title}>Clinic Information</Text>
      <TouchableOpacity
        style={styles.imageContainer}
        onPress={() => {
          setModalImage(item.Image);
          setModalVisible(true);
        }}
      >
        {item.Image ? (
          <Image source={{ uri: item.Image }} style={styles.image} />
        ) : (
          <View style={styles.imagePlaceholder} />
        )}
      </TouchableOpacity>
      <View style={styles.detailsContainer}>
        <View style={styles.detailItem}>
          <Text style={styles.label}>Name:</Text>
          <Text style={styles.value}>{item.Name}</Text>
        </View>
        <View style={styles.detailItem}>
          <Text style={styles.label}>Location:</Text>
          <Text style={styles.value}>{item.Location}</Text>
        </View>
        <View style={styles.detailItem}>
          <Text style={styles.label}>Contact:</Text>
          <Text style={styles.value}>{item.Contact}</Text>
        </View>
      </View>
    </View>
  );

  return (
    <ImageBackground
      source={{ uri: 'https://engage.healthtrustjobs.com/hubfs/Images/Blog/MCCHildrens-exterior.jpg' }}
      style={styles.backgroundImage}
      resizeMode="cover"
    >
      <View style={styles.contentContainer}>
        {error ? (
          <Text style={styles.error}>{error}</Text>
        ) : (
          <FlatList
            data={clinics}
            renderItem={renderClinicItem}
            keyExtractor={item => item.id}
            contentContainerStyle={{ paddingBottom: 150 }} // Ensures padding at the bottom of the list
          />
        )}
        <Modal
          transparent={true}
          visible={modalVisible}
          onRequestClose={() => setModalVisible(false)}
        >
          <View style={styles.modalBackground}>
            <View style={styles.modalContainer}>
              {modalImage && (
                <Image source={{ uri: modalImage }} style={styles.modalImage} />
              )}
              <Pressable
                style={styles.buttonClose}
                onPress={() => setModalVisible(false)}
              >
                <Text style={styles.textStyle}>Close</Text>
              </Pressable>
            </View>
          </View>
        </Modal>
      </View>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  backgroundImage: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  contentContainer: {
    flex: 1,
    width: '100%',
    padding: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 16,
    textAlign: 'center',
    color: '#333',
  },
  error: {
    color: 'red',
    textAlign: 'center',
    marginBottom: 16,
  },
  clinicItem: {
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 16,
    marginBottom: 120, // Adjusted marginBottom here to 20
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 5,
  },
  image: {
    width: '40%',
    height: 80,
    borderRadius: 10,
    marginBottom: 16,
    borderRadius: 550,
  },
  imageContainer: {
    marginBottom: 10,
    alignItems: 'center',
  },
  detailsContainer: {
    padding: 16,
  },
  detailItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
    paddingVertical: 10,
  },
  label: {
    fontWeight: 'bold',
    fontSize: 16,
  },
  value: {
    fontSize: 16,
    color: '#555',
  },
  buttonClose: {
    backgroundColor: '#007bff',
    borderRadius: 4,
    padding: 10,
    marginTop: 20,
  },
  textStyle: {
    color: '#fff',
    textAlign: 'center',
  },
  modalBackground: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContainer: {
    width: '80%',
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 10,
    alignItems: 'center',
  },
  modalImage: {
    width: '100%',
    height: 400,
    resizeMode: 'contain',
  },
});

export default ViewClinic;
