import React, { useState } from 'react';
import { View, ImageBackground, StyleSheet, Image, TextInput, Text, TouchableOpacity } from 'react-native';
import img5 from '../../../assets/pic5.jpg';
import img6 from '../../../assets/pic6.jpg';
import Icon from 'react-native-vector-icons/FontAwesome';
import CustomModal from '../Modal/CustomModal';
import AsyncStorage from '@react-native-async-storage/async-storage'; 

function Login({ navigation }) {
  const [email, setEmail] = useState(''); 
  const [password, setPassword] = useState('');
  const [modalVisible, setModalVisible] = useState(false);
  const [modalMessage, setModalMessage] = useState('');

  const handleform = async () => {
    if (email.trim() === '' || password.trim() === '') {
      setModalMessage('You have to fill both fields first');
      setModalVisible(true);
      return;
    }
    try {
      const response = await fetch('https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/PatientAccountsInfo.json', {
        method: 'GET',
      });

      if (!response.ok) {
        throw new Error("Network Issue");
      }

      const data = await response.json();
      const authentication = Object.values(data).some(
        account => account.email === email && account.password === password 
      );

      if (authentication) {
        
        await AsyncStorage.setItem('userEmail', email);
      
        navigation.navigate('Home', { screen: 'Display' });
      } else {
        setModalMessage('Invalid email or password');
        setModalVisible(true);
      }
    } catch (error) {
      console.error("Error:", error);
      setModalMessage(`Error: ${error.message}`);
      setModalVisible(true);
    }
  };

  return (
    <ImageBackground source={img5} style={styles.background}>
      <View>
        <CustomModal
          visible={modalVisible}
          message={modalMessage}
          onClose={() => setModalVisible(false)}
        />
       
        <View style={styles.formview}>
        
          <Image style={styles.img6} source={img6} />
        
          <Text style={styles.title}>Login</Text>
          <View style={styles.inputContainer}>
            <Icon name='envelope' size={24} style={styles.icon} /> 
            <TextInput
              style={styles.input}
              placeholder="Email"
              value={email}
              onChangeText={setEmail}
              keyboardType="email-address"
              autoCapitalize="none"
              placeholderTextColor="lightgray"
            />
          </View>
          <View style={styles.inputContainer}>
            <Icon name='lock' size={24} style={styles.icon} />
            <TextInput
              style={styles.input}
              placeholder="Password"
              value={password}
              onChangeText={setPassword}
              placeholderTextColor="lightgray"
              secureTextEntry
            />
          </View>
          <TouchableOpacity style={styles.btn} onPress={handleform}>
            <Text style={styles.Signin}>Sign in</Text>
          </TouchableOpacity>
        </View>
       
          <Text style={styles.signupText}>
            Don't have an Account?
            <TouchableOpacity onPress={() => navigation.navigate('CreateAccount')}>
              <Text style={styles.SignUp}> Sign Up</Text>
            </TouchableOpacity>
          </Text>
        </View>
   
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    alignItems: 'center',
    height: '100%',
    width: '100%',
    backgroundColor: '#333', 
  },
  img6: {
    height: 120,
    width: 120,
    borderRadius: 120,
    resizeMode: 'cover',
  },
  formview: {
    borderWidth: 2,
    textAlign: 'center',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 120,
    width: 380,
    backgroundColor: '#000',
    height:450,
    borderRadius: 30,
    borderColor: '#00FFFF',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.5,
    shadowRadius: 10,
    elevation: 10,
  },
  title: {
    fontWeight: 'bold',
    fontSize: 30,
    color: '#00FFFF', 
    marginBottom: 20,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#00FFFF', 
    marginTop: 20,
    paddingBottom: 5,
  },
  input: {
    flex: 1,
    fontSize: 16,
    fontWeight: 'bold',
    color: 'lightgray', 
    paddingLeft: 10,
  },
  icon: {
    color: 'lightgray', 
    marginRight: 10,
  },
  btn: {
    marginTop: 30,
    backgroundColor: '#00FFFF', 
    paddingVertical: 10,
    paddingHorizontal: 40,
    borderRadius: 20,
  },
  Signin: {
    color: '#000', 
    fontWeight: 'bold',
    fontSize: 18,
  },
  signupText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'lightgray',
    marginTop: 15,
    textAlign: 'center',
  },
  SignUp: {
    color: 'aqua',
    fontWeight: 'bold',
    fontSize: 16,
    textDecorationLine: 'underline',
  },
});

export default Login;
