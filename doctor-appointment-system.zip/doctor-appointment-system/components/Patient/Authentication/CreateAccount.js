import React, { useState } from 'react';
import { Image, View, Text, TextInput, TouchableOpacity, StyleSheet, ImageBackground, ScrollView } from 'react-native';
import backgroundImage from '../../../assets/pic5.jpg';
import img7 from "../../../assets/pic7.jpg";
import Icon from 'react-native-vector-icons/FontAwesome';
import CustomModal from '../Modal/CustomModal';
const CreateAccount = ({ navigation }) => {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [modalVisible, setModalVisible] = useState(false);
  const [modalMessage, setModalMessage] = useState('');

  const handleCreateAccount = async () => {
    if (username.trim() === '' || email.trim() === '' || password.trim() === '' || confirmPassword.trim() === '') {
      setModalMessage('Please fill all the fields first');
      setModalVisible(true);
      return;
    }

    if (password !== confirmPassword) {
      setModalMessage('Password and confirm password do not match');
      setModalVisible(true);
      return;
    }

    try {
      const checkResponse = await fetch('https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/PatientAccountsInfo.json', {
        method: 'GET',
      });

      if (!checkResponse.ok) {
        const errorData = await checkResponse.json();
        console.error('Error:', errorData);
        setModalMessage(errorData.message || 'Something went wrong!');
        setModalVisible(true);
        return;
      }

      const existingAccounts = await checkResponse.json();
      const usernameExists = Object.values(existingAccounts).some(account => account.username === username);
      const emailExists = Object.values(existingAccounts).some(account => account.email === email);
      const passwordExists = Object.values(existingAccounts).some(account => account.password === password);

      if (usernameExists) {
        setModalMessage('Username is Already Taken Use Another One');
        setModalVisible(true);
        return;
      }

      if (emailExists) {
        setModalMessage('Email is already registered');
        setModalVisible(true);
        return;
      }

      if (passwordExists) {
        setModalMessage('Please Change Password because it is already taken');
        setModalVisible(true);
        return;
      }

      const response = await fetch('https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/PatientAccountsInfo.json', {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          username: username,
          email: email,
          password: password,
          confirmPassword: confirmPassword,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        console.error('Error:', errorData);
        setModalMessage(errorData.message || 'Something went wrong!');
        setModalVisible(true);
        return;
      }

      setModalMessage('Account created successfully!');
      setModalVisible(true);

      setTimeout(() => {
        setModalVisible(false);
        navigation.navigate('login');
      }, 2000);  
      
    } catch (error) {
      console.error('Network error:', error);
      setModalMessage(error.message || 'Something went wrong!');
      setModalVisible(true);
    }
  };

  return (
    <ImageBackground source={backgroundImage} style={styles.background}>
      <ScrollView contentContainerStyle={styles.container}>
        <View>
          <CustomModal
            visible={modalVisible}
            message={modalMessage}
            onClose={() => setModalVisible(false)}
          />
          <View style={styles.img7view}>
            <Image style={styles.img7} source={img7} />
          </View>
          <View style={styles.formView}>
            <Text style={styles.title}>Create Account</Text>
            <View style={styles.inputContainer}>
              <Icon name='user' size={24} style={styles.icon} />
              <TextInput
                style={styles.input}
                placeholder="Username"
                value={username}
                onChangeText={setUsername}
                keyboardType="default"
                autoCapitalize="none"
                placeholderTextColor="white"
              />
            </View>
            <View style={styles.inputContainer}>
              <Icon name='envelope' size={24} style={styles.icon} />
              <TextInput
                style={styles.input}
                placeholder="Email"
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
                autoCapitalize="none"
                placeholderTextColor="white"
              />
            </View>
            <View style={styles.inputContainer}>
              <Icon name='lock' size={24} style={styles.icon} />
              <TextInput
                style={styles.input}
                placeholder="Password"
                value={password}
                onChangeText={setPassword}
                placeholderTextColor="white"
                secureTextEntry
              />
            </View>
            <View style={styles.inputContainer}>
              <Icon name='lock' size={24} style={styles.icon} />
              <TextInput
                style={styles.input}
                placeholder="Confirm Password"
                value={confirmPassword}
                onChangeText={setConfirmPassword}
                placeholderTextColor="white"
                secureTextEntry
              />
            </View>
            <TouchableOpacity style={styles.btn} onPress={handleCreateAccount}>
              <Text style={styles.Signin}>Sign Up</Text>
            </TouchableOpacity>
            <View style={styles.signupContainer}>
              <TouchableOpacity onPress={() => navigation.navigate('login')}>
                <Text style={styles.SignUp}>Already have an Account? Sign In</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </ScrollView>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  background: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  container: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  btn: {
    backgroundColor: 'aqua',
    paddingVertical: 10,
    borderRadius: 5,
    marginTop: 10,
  },
  Signin: {
    textAlign: 'center',
    color: 'black',
    fontSize: 18,
    fontWeight: 'bold',
  },
  signupContainer: {
    alignItems: 'center',
    marginTop: 10,
  },
  signupText: {
    color: 'white',
  },
  SignUp: {
    color: 'aqua',
    fontWeight: 'bold',
  },
  formView: {
    width: '80%',
    padding: 20,
    marginBottom: 90,
    borderRadius: 50,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
    marginBottom: 20,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderBottomWidth: 2,
    borderBottomColor: 'aqua',
    marginBottom: 15,
  },
  input: {
    flex: 1,
    height: 50,
    paddingHorizontal: 15,
    fontSize: 16,
    borderBottomColor: 'aqua',
    paddingTop: 18,
    color: "gray",
    fontWeight: "bold",
    fontFamily: "Roboto"
  },
  icon: {
    color: '#aaa',
    marginRight: 10,
  },
  img7view: {
    marginTop: 50,
    marginRight: 200,
    flexDirection: 'row',
    shadowColor: 'black',
    paddingBottom: 100,
  },
  img7: {
    height: 100,
    width: 100,
    borderRadius: 100,
    resizeMode: 'cover',
  },
});

export default CreateAccount;
