import React, { useState,useEffect } from 'react';
import { View, StyleSheet, Text, Pressable, Modal } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

function DeleteProfile({ route, navigation }) {
  const [id, setId] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);
  const [modalMessage, setModalMessage] = useState('');
  const { onProfileDeleted } = route.params; // Get the callback from route params

  useEffect(() => {
    const fetchID = async () => {
      try {
        const storedEmail = await AsyncStorage.getItem('userEmail');
        if (storedEmail) {
          const response = await fetch('https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Profiles.json');
          const data = await response.json();
          
          let profileId = null;
          for (const key in data) {
            if (data[key].email === storedEmail) {
              profileId = key;
              break;
            }
          }
          
          if (profileId) {
            setId(profileId);
          } else {
            setModalMessage('Profile not found.');
          }
        }
      } catch (error) {
        console.error('Error fetching email or profiles:', error);
      }
    };

    fetchID();
  }, []);

  const handleDeleteProfile = async () => {
    if (!id) {
      setModalMessage('No profile found. Please try again.');
      return;
    }
    try {
      await fetch(`https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Profiles/${id}.json`, {
        method: 'DELETE',
      });
     
      setModalMessage('Profile deleted successfully!');
      
      if (onProfileDeleted) {
        onProfileDeleted(); // Call the callback to refresh the profile
      }
      navigation.goBack(); // Navigate back to the previous screen
    } catch (error) {
      setModalMessage('Failed to delete profile. Please try again.');
      console.error('Error deleting profile:', error);
    } finally {
      setModalVisible(false);
    }
  };

  return (
    <View style={styles.container}>
      <Pressable
        style={styles.deleteButton}
        onPress={() => setModalVisible(true)}
      >
        <Text style={styles.deleteButtonText}>Are you sure you want to delete your profile?</Text>
      </Pressable>

      <Modal
        visible={modalVisible}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Confirm Deletion</Text>
            <Text style={styles.modalText}>Really! Are you sure you want to delete your profile?</Text>
            <View style={styles.modalButtonContainer}>
              <Pressable
                style={[styles.modalButton, { backgroundColor: 'red' }]}
                onPress={handleDeleteProfile}
              >
                <Text style={styles.modalButtonText}>Yes</Text>
              </Pressable>
              <Pressable
                style={[styles.modalButton, { backgroundColor: 'green' }]}
                onPress={() => setModalVisible(false)}
              >
                <Text style={styles.modalButtonText}>No</Text>
              </Pressable>
            </View>
            {modalMessage ? <Text style={styles.modalText}>{modalMessage}</Text> : null}
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  deleteButton: {
    backgroundColor: 'red',
    padding: 10,
    borderRadius: 5,
  },
  deleteButtonText: {
    color: '#fff',
    fontSize: 16,
  },
  modalOverlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    width: '80%',
    padding: 20,
    backgroundColor: '#fff',
    borderRadius: 10,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
    elevation: 10,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  modalText: {
    fontSize: 18,
    marginBottom: 20,
  },
  modalButtonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '100%',
  },
  modalButton: {
    padding: 10,
    borderRadius: 5,
    elevation: 2,
    minWidth: '30%',
    alignItems: 'center',
  },
  modalButtonText: {
    color: '#fff',
    fontSize: 16,
  },
});

export default DeleteProfile;
