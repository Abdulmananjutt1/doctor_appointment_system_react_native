import React, { useState, useCallback } from 'react';
import { View, StyleSheet, Image, Text, TouchableOpacity, Alert } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect } from '@react-navigation/native';
import CustomModal from '../Modal/CustomModal'; // Ensure this is properly imported
import img6 from '../../../assets/profile_dummy.jpg';

function ViewProfile({ navigation }) {
  const [profile, setProfile] = useState({
    id: '',
    name: '',
    email: '',
    phone: '',
    profileImage: img6,
  });
  const [modalVisible, setModalVisible] = useState(false);
  const [modalMessage, setModalMessage] = useState('');
  const [profileExists, setProfileExists] = useState(false);

  const fetchProfile = async () => {
    try {
      const storedEmail = await AsyncStorage.getItem('userEmail');
      console.log('Stored Email:', storedEmail);

      if (storedEmail) {
        const response = await fetch('https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Profiles.json');
        const profiles = await response.json();
        console.log('Fetched Profiles:', profiles);

        const userProfile = Object.entries(profiles).find(([key, profile]) => profile.email === storedEmail);
        console.log('User Profile:', userProfile);

        if (userProfile) {
          const [profileId, profileData] = userProfile;
          setProfile({ ...profileData, id: profileId });
          setProfileExists(true);
        } else {
          setProfileExists(false);
        }
      }
    } catch (error) {
      console.error('Error fetching profile:', error);
      setModalMessage('Failed to fetch profile.');
      setModalVisible(true);
    }
  };

  useFocusEffect(
    useCallback(() => {
      fetchProfile();
    }, [])
  );

  const handleEditProfile = () => {
    navigation.navigate('UpdateProfile');
  };

  const handleDeleteProfile = async () => {
    Alert.alert(
      'Confirm Deletion',
      'Are you sure you want to delete your profile?',
      [
        {
          text: 'No',
          onPress: () => console.log('Profile deletion cancelled'),
          style: 'cancel',
        },
        {
          text: 'Yes',
          onPress: async () => {
            try {
              if (!profile.id) {
                throw new Error('Profile ID is not available.');
              }

              const url = `https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Profiles/${profile.id}.json`;
              console.log('Deleting profile from:', url);

              const response = await fetch(url, {
                method: 'DELETE',
              });

              if (!response.ok) {
                throw new Error('Failed to delete profile. Status: ' + response.status);
              }

              setProfile({
                id: '',
                name: '',
                email: '',
                phone: '',
              });
              setProfileExists(false);
              setModalMessage('Profile deleted successfully!');
              setModalVisible(true);

            } catch (error) {
              setModalMessage(`Failed to delete profile. Please try again. Error: ${error.message}`);
              console.error('Error deleting profile:', error);
            } finally {
              fetchProfile();
            }
          },
        },
      ],
      { cancelable: false }
    );
  };

  const handleViewProfile = () => {
    navigation.navigate('Profile');
  };

  return (
    <View style={styles.container}>
      <View style={styles.table}>
        <View style={styles.tableRow}>
          <View style={styles.tableCell}>
            <Text style={styles.tableText}>Name:</Text>
          </View>
          <View style={styles.tableCell}>
            <Text style={styles.tableText}>{profile.name}</Text>
          </View>
        </View>
        <View style={styles.tableRow}>
          <View style={styles.tableCell}>
            <Text style={styles.tableText}>Email:</Text>
          </View>
          <View style={styles.tableCell}>
            <Text style={styles.tableText}>{profile.email}</Text>
          </View>
        </View>
        <View style={styles.tableRow}>
          <View style={styles.tableCell}>
            <Text style={styles.tableText}>Phone:</Text>
          </View>
          <View style={styles.tableCell}>
            <Text style={styles.tableText}>{profile.phone}</Text>
          </View>
        </View>
      </View>
      <TouchableOpacity style={styles.editButton} onPress={handleViewProfile}>
        <Text style={styles.buttonText}>Ok</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#333',
    alignItems: 'center',
    marginTop:200
  },
  profileImage: {
    width: 120,
    height: 120,
    borderRadius: 60,
    marginBottom: 20,
    borderWidth: 2,
    borderColor: '#00FFFF',
  },
  table: {
    width: '100%',
    borderColor: '#FFFFFF',
    borderWidth: 1,
    borderRadius: 10,
    overflow: 'hidden',
    marginBottom: 20,
  },
  tableRow: {
    flexDirection: 'row',
    borderBottomColor: '#FFFFFF',
    borderBottomWidth: 1,
    paddingHorizontal: 10,
    paddingVertical: 5,
    alignItems: 'center',
  },
  tableCell: {
    flex: 1,
  },
  tableText: {
    color: 'lightgray',
    fontSize: 18,
  },
  editButton: {
    width: '100%',
    backgroundColor: '#00FFFF',
    paddingVertical: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 20,
  },
  buttonText: {
    color: '#000',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default ViewProfile;
