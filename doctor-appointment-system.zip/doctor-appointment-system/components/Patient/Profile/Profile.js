import React, { useState, useEffect, useCallback } from 'react';
import { View, StyleSheet, Text, TouchableOpacity } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

function ViewProfile({ navigation }) {
  const [profile, setProfile] = useState(null);

  const fetchProfile = useCallback(async () => {
    const storedEmail = await AsyncStorage.getItem('userEmail');
    if (storedEmail) {
      try {
        const response = await fetch('https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Profiles.json');
        const profiles = await response.json();
        const userProfile = Object.entries(profiles).find(([key, profile]) => profile.email === storedEmail);

        if (userProfile) {
          const [, profileData] = userProfile;
          setProfile(profileData);
        } else {
          setProfile(null);
        }
      } catch (error) {
        console.error('Error fetching profile:', error);
      }
    }
  }, []);

  useEffect(() => {
    fetchProfile(); 
    const intervalId = setInterval(fetchProfile, 5000);
    return () => clearInterval(intervalId); 
  }, [fetchProfile]);

  const handleEditProfile = () => {
    navigation.navigate('UpdateProfile', { profile });
  };

  const handleDeleteProfile = () => {
    navigation.navigate('DeleteProfile', { onProfileDeleted: fetchProfile });
    setProfile(null);
  };

  const handleAddProfile = () => {
    navigation.navigate('CreateProfile');
  };

  const handleViewProfile = () => {
    navigation.navigate('ViewProfile');
  };

  return (
    <View style={styles.container}>
      {profile === null ? (
        <TouchableOpacity style={styles.editButton} onPress={handleAddProfile}>
          <Text style={styles.buttonText}>Add Profile</Text>
        </TouchableOpacity>
      ) : (
        <>
          <TouchableOpacity style={styles.editButton} onPress={handleEditProfile}>
            <Text style={styles.buttonText}>Edit</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.editButton} onPress={handleViewProfile}>
            <Text style={styles.buttonText}>View</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.deleteButton} onPress={handleDeleteProfile}>
            <Text style={styles.buttonText}>Delete</Text>
          </TouchableOpacity>
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
  },
  editButton: {
    width: '100%',
    backgroundColor: '#00FFFF',
    paddingVertical: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginVertical: 10,
  },
  deleteButton: {
    width: '100%',
    backgroundColor: '#FF6347',
    paddingVertical: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginVertical: 10,
  },
  buttonText: {
    color: '#000',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default ViewProfile;
