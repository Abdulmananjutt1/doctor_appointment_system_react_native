import React, { useState, useEffect } from 'react';
import { View, StyleSheet, TextInput, Text, TouchableOpacity } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import CustomModal from '../Modal/CustomModal';

function UpdateProfile({ navigation }) {
  const [profile, setProfile] = useState({
    name: '',
    email: '',
    phone: '',
  });
  const [modalVisible, setModalVisible] = useState(false);
  const [modalMessage, setModalMessage] = useState('');

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const storedEmail = await AsyncStorage.getItem('userEmail');
        if (storedEmail) {
          const response = await fetch('https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Profiles.json');
          const profiles = await response.json();
          const userProfile = Object.values(profiles).find(profile => profile.email === storedEmail);
          if (userProfile) {
            setProfile(userProfile);
          }
        }
      } catch (error) {
        console.error('Error fetching profile:', error);
        setModalMessage('Error fetching profile.');
        setModalVisible(true);
      }
    };

    fetchProfile();
  }, []);

  const handleSaveProfile = async () => {
    if (profile.name.trim() === '' || profile.email.trim() === '' || profile.phone.trim() === '') {
      setModalMessage('All fields are required');
      setModalVisible(true);
      return;
    }

    try {
      const storedEmail = await AsyncStorage.getItem('userEmail');
      if (storedEmail) {
        const response = await fetch('https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Profiles.json');
        const profiles = await response.json();
        const profileId = Object.keys(profiles).find(key => profiles[key].email === storedEmail);

        if (profileId) {
          await fetch(`https://doctorappointmentsystem-e097a-default-rtdb.firebaseio.com/Profiles/${profileId}.json`, {
            method: 'PUT',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(profile),
          });
          setModalMessage('Profile updated successfully');
         
          setModalVisible(true);
          navigation.navigate('Profile');
        }
      }
    } catch (error) {
      console.error('Error:', error);
      setModalMessage(`Error: ${error.message}`);
      setModalVisible(true);
    }
  };

  return (
    <View style={styles.container}>
      <CustomModal
        visible={modalVisible}
        message={modalMessage}
        onClose={() => setModalVisible(false)}
      />
      <TextInput
        style={styles.input}
        placeholder="Name"
        value={profile.name}
        onChangeText={(text) => setProfile(prevState => ({ ...prevState, name: text }))}
        placeholderTextColor="lightgray"
      />
      <TextInput
        style={styles.input}
        placeholder="Email"
        value={profile.email}
        onChangeText={(text) => setProfile(prevState => ({ ...prevState, email: text }))}
        keyboardType="email-address"
        autoCapitalize="none"
        placeholderTextColor="lightgray"
        editable={false} 
      />
      <TextInput
        style={styles.input}
        placeholder="Phone"
        value={profile.phone}
        onChangeText={(text) => setProfile(prevState => ({ ...prevState, phone: text }))}
        keyboardType="phone-pad"
        placeholderTextColor="lightgray"
      />
      <TouchableOpacity style={styles.saveButton} onPress={handleSaveProfile}>
        <Text style={styles.saveButtonText}>Save Changes</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#333',
    alignItems: 'center',
  },
  input: {
    width: '100%',
    height: 50,
    backgroundColor: '#444',
    borderRadius: 10,
    paddingHorizontal: 10,
    fontSize: 16,
    color: 'lightgray',
    marginBottom: 20,
  },
  saveButton: {
    width: '100%',
    backgroundColor: '#00FFFF',
    paddingVertical: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 20,
  },
  saveButtonText: {
    color: '#000',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default UpdateProfile;
