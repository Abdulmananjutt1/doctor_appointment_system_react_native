import React from 'react';
import { Alert, View } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { NavigationContainer, useNavigation } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createDrawerNavigator } from '@react-navigation/drawer';
import Icon from 'react-native-vector-icons/FontAwesome';
import Firstpage from '../Additional/firstpage';
import Login from '../Authentication/Login';
import CreateAccount from '../Authentication/CreateAccount';
import BookingAppointment from '../Booking/BookingAppointment';
import DisplayTabNavigator from '../HomeScreen/Display';
import ClinicInfo from '../Additional/ClinicInfo';
import DoctorDetails from '../Additional/DoctorDetails';
import DoctorsInfo from '../Additional/DoctorsInfor';
import FeesSchedule from '../Additional/FeesSchedule';
import CreateProfile from '../Profile/CreateProfile';
import ViewProfile from '../Profile/ViewProfile';
import UpdateProfile from '../Profile/UpdateProfile';
import Profile from '../Profile/Profile'
import DeleteProfile from '../Profile/DeleteProfile'
import History from '../Additional/History';
import Medical from '../Additional/MedicalRecord'
const Stack = createNativeStackNavigator();
const Drawer = createDrawerNavigator();
const Tab = createBottomTabNavigator();

function LogoutScreen() {
  const navigation = useNavigation();

  React.useEffect(() => {
    const handleLogout = async () => {
      try {
        await AsyncStorage.clear();
        Alert.alert('Logged out', 'You have been logged out.');
        navigation.reset({
          index: 0,
          routes: [{ name: 'Firstpage' }],
        });
      } catch (error) {
        console.error('Logout Error: ', error);
        Alert.alert('Error', 'There was a problem logging out.');
      }
    };

    handleLogout();
  }, [navigation]);

  return <View />;
}

function DrawerNavigator() {
  return (
    <Drawer.Navigator>
      <Drawer.Screen name="Display" component={DisplayTabNavigator} />
      <Drawer.Screen name="Book Appointments" component={BookingAppointment} />
      
      <Drawer.Screen
        name="Logout"
        component={LogoutScreen}
        options={{
          drawerLabel: 'Logout',
          drawerIcon: ({ color, size }) => (
            <Icon name="sign-out" size={size} color={color} />
          ),
        }}
      />
    </Drawer.Navigator>
  );
}

function TabNavigator() {
  return (
    <Tab.Navigator
     
    >
      <Tab.Screen name="Home" component={DrawerNavigator} />
      
      <Tab.Screen name="Appointments" component={BookingAppointment} />
      <Tab.Screen name="Profile" component={Profile} />
    </Tab.Navigator>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName='Firstpage'>
         <Stack.Screen name="Home" component={TabNavigator} options={{ headerShown: false }} />
        <Stack.Screen name="BookingAppointment" component={BookingAppointment} options={{ headerTitle: "Back" }} />
      
        <Stack.Screen name="DoctorDetails" component={DoctorDetails} options={{ headerTitle: "Back" }} />
        <Stack.Screen name="Doctors Information" component={DoctorsInfo} options={{ headerTitle: "Back" }} />
        <Stack.Screen name="Clinic Information" component={ClinicInfo} options={{ headerTitle: "Back" }} />
        <Stack.Screen name="Fee Schedule" component={FeesSchedule} options={{ headerTitle: "Back" }} />
        <Stack.Screen name="CreateProfile" component={CreateProfile} options={{ headerTitle: "Back" }} />
        <Stack.Screen name="UpdateProfile" component={UpdateProfile} options={{ headerTitle: "Back" }} />
        <Stack.Screen name="ViewProfile" component={ViewProfile} options={{ headerTitle: "Back" }} />
        <Stack.Screen name="DeleteProfile" component={DeleteProfile} options={{ headerTitle: "Back" }} />   
        <Stack.Screen name="History" component={History} options={{ headerTitle: "Back" }} />
        <Stack.Screen name="MedicalRecord" component={Medical} options={{ headerTitle: "Back" }} />
        
      </Stack.Navigator>
    </NavigationContainer>
  );
}
